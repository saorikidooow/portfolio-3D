# Images des œuvres

Le plus simple : ajoutez les images depuis l'Atelier (`admin/`), elles sont
optimisées et enregistrées ici automatiquement à la publication.

À la main : déposez l'image ici (JPG/PNG/WebP, ≤ 2000 px conseillé, nom sans espace ni
accent, ex. `serie-printemps-01.jpg`) puis, dans `content/site.json`, pour l'œuvre :

```json
"visual": "image",
"image": "assets/artworks/serie-printemps-01.jpg",
```

Ajustez `width` / `height` (mètres) aux proportions de l'œuvre.
