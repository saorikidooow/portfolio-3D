# Documents

Les documents (PDF…) ajoutés depuis l'administration sont enregistrés ici.
Vous pouvez aussi en déposer à la main puis indiquer leur chemin
(ex. `assets/documents/catalogue.pdf`) dans la fiche de l'œuvre.
