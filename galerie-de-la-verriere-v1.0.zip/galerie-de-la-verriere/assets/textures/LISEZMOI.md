# Textures

Les matériaux (parquet, plâtre, bois sombre) sont générés par le code.
Pour utiliser vos propres photos de matériaux, placez-les ici et renseignez
`TEXTURE_OVERRIDES` dans `js/config.js`.
