/**
 * Publication directe sur GitHub depuis le navigateur (API REST officielle).
 * Tous les fichiers d'une publication sont envoyés en UN seul commit
 * (API « Git Data » : blobs → arbre → commit → mise à jour de la branche).
 *
 * Le jeton (token) n'est jamais envoyé ailleurs qu'à api.github.com et reste
 * dans le navigateur de la personne qui l'a saisi.
 */
export class GitHubRepo {
  constructor({ owner, repo, branch = 'main', token, apiBase = 'https://api.github.com' }) {
    Object.assign(this, { owner: owner.trim(), repo: repo.trim(), branch: (branch || 'main').trim(), token: token.trim(), apiBase });
  }

  get base() { return `/repos/${encodeURIComponent(this.owner)}/${encodeURIComponent(this.repo)}`; }

  async req(path, { method = 'GET', body, raw = false } = {}) {
    const res = await fetch(this.apiBase + path, {
      method,
      headers: {
        Authorization: `Bearer ${this.token}`,
        Accept: raw ? 'application/vnd.github.raw+json' : 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        ...(body ? { 'Content-Type': 'application/json' } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
      cache: 'no-store',
    });
    if (!res.ok) {
      let detail = '';
      try { detail = (await res.json()).message || ''; } catch { /* vide */ }
      const msg = {
        401: 'Jeton refusé : il est invalide ou expiré.',
        403: "Accès refusé : le jeton n'a pas le droit d'écrire dans ce dépôt (permission « Contents : Read and write »).",
        404: 'Dépôt, branche ou fichier introuvable : vérifiez le propriétaire, le nom du dépôt et la branche.',
        409: 'Le dépôt est vide ou en conflit : faites d\'abord un premier envoi (voir le guide).',
        422: 'GitHub a refusé la modification.',
      }[res.status] || `Erreur GitHub ${res.status}.`;
      const err = new Error(`${msg}${detail ? ` (${detail})` : ''}`);
      err.status = res.status;
      throw err;
    }
    if (res.status === 204) return null;
    return raw ? res.text() : res.json();
  }

  /** Vérifie l'accès ; renvoie des informations utiles à afficher. */
  async check() {
    const r = await this.req(this.base);
    let pagesUrl = '';
    try { pagesUrl = (await this.req(this.base + '/pages')).html_url || ''; } catch { /* Pages pas encore activé */ }
    await this.req(`${this.base}/branches/${encodeURIComponent(this.branch)}`);
    return { fullName: r.full_name, canPush: !!r.permissions?.push, htmlUrl: r.html_url, defaultBranch: r.default_branch, pagesUrl };
  }

  async readText(path) {
    return this.req(`${this.base}/contents/${path.split('/').map(encodeURIComponent).join('/')}?ref=${encodeURIComponent(this.branch)}`, { raw: true });
  }

  /**
   * @param {{path:string, content:string|Blob}[]} files
   * @param {string} message
   * @param {(step:string)=>void} [onStep]
   */
  async commitFiles(files, message, onStep = () => {}) {
    onStep('Lecture de la branche…');
    const ref = await this.req(`${this.base}/git/ref/heads/${encodeURIComponent(this.branch)}`);
    const parentSha = ref.object.sha;
    const parent = await this.req(`${this.base}/git/commits/${parentSha}`);
    const tree = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      onStep(`Envoi des fichiers (${i + 1}/${files.length}) : ${f.path}`);
      const blob = await this.req(`${this.base}/git/blobs`, {
        method: 'POST',
        body: { content: await toBase64(f.content), encoding: 'base64' },
      });
      tree.push({ path: f.path, mode: '100644', type: 'blob', sha: blob.sha });
    }
    onStep('Création du commit…');
    const newTree = await this.req(`${this.base}/git/trees`, { method: 'POST', body: { base_tree: parent.tree.sha, tree } });
    const commit = await this.req(`${this.base}/git/commits`, {
      method: 'POST',
      body: { message, tree: newTree.sha, parents: [parentSha] },
    });
    onStep('Mise à jour de la branche…');
    await this.req(`${this.base}/git/refs/heads/${encodeURIComponent(this.branch)}`, { method: 'PATCH', body: { sha: commit.sha } });
    return { sha: commit.sha, url: commit.html_url };
  }
}

async function toBase64(content) {
  if (typeof content === 'string') {
    const bytes = new TextEncoder().encode(content);
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  }
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] || '');
    r.onerror = () => reject(r.error);
    r.readAsDataURL(content);
  });
}

/** Devine propriétaire / dépôt quand l'admin est servi par GitHub Pages. */
export function guessRepoFromLocation(loc = location) {
  const m = /^([^.]+)\.github\.io$/i.exec(loc.hostname);
  if (!m) return null;
  const first = loc.pathname.split('/').filter(Boolean)[0];
  const repo = first && first !== 'admin' ? first : `${m[1]}.github.io`;
  return { owner: m[1], repo };
}
