/**
 * Peintre procédural : compose des tableaux « à l'ancienne » (paysages,
 * marines, montagnes, nocturnes, portraits, natures mortes, abstractions)
 * puis applique une couche de touches de pinceau, un vernis et un vignettage.
 * Le résultat est déterministe : une même graine donne toujours le même tableau.
 */
import { mulberry32, clamp, makeCanvas } from './random.js';

const TAU = Math.PI * 2;

export function paintArtwork(art, maxPx = 1024) {
  const aspect = art.width / art.height;
  let w, h;
  if (aspect >= 1) { w = maxPx; h = Math.round(maxPx / aspect); }
  else { h = maxPx; w = Math.round(maxPx * aspect); }
  const c = makeCanvas(w, h);
  const ctx = c.getContext('2d', { willReadFrequently: true });
  const r = mulberry32((art.seed || 1) * 9973 + 17);
  if (art.visual === 'poster') {
    drawPoster(ctx, w, h, art);
    return c;
  }
  const style = STYLES[art.style] || STYLES.abstract;
  style.draw(ctx, w, h, r, c);
  painterly(ctx, w, h, mulberry32((art.seed || 1) * 31 + 4242), style.stroke);
  finish(ctx, w, h, mulberry32((art.seed || 1) + 77));
  return c;
}

/**
 * Affiche typographique : pour présenter un document, un lien, un texte…
 * Couleurs : art._poster = { paper, ink, accent } (fourni par le thème).
 */
function drawPoster(ctx, w, h, art) {
  const P = art._poster || { paper: '#f3ede2', ink: '#2a241d', accent: '#a5844f' };
  const U = Math.min(w, h);
  ctx.fillStyle = P.paper; ctx.fillRect(0, 0, w, h);
  const m = U * 0.07;
  ctx.strokeStyle = P.accent; ctx.lineWidth = Math.max(1, U * 0.004);
  ctx.strokeRect(m, m, w - 2 * m, h - 2 * m);
  ctx.strokeRect(m + U * 0.012, m + U * 0.012, w - 2 * m - U * 0.024, h - 2 * m - U * 0.024);
  const kind = art.document?.url ? 'Document' : art.link?.url ? 'Lien' : 'Œuvre';
  ctx.fillStyle = P.accent;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  ctx.font = `500 ${Math.round(U * 0.045)}px "Jost", Arial, sans-serif`;
  if ('letterSpacing' in ctx) ctx.letterSpacing = `${Math.round(U * 0.012)}px`;
  ctx.fillText(kind.toUpperCase(), w / 2, m + U * 0.13);
  if ('letterSpacing' in ctx) ctx.letterSpacing = '0px';
  // titre (taille adaptée à la place disponible)
  const maxW = w - 2 * m - U * 0.12;
  let size = Math.round(U * 0.13);
  const title = art.title || 'Sans titre';
  let lines;
  for (; size > U * 0.05; size -= 2) {
    ctx.font = `500 ${size}px "Cormorant Garamond", Georgia, serif`;
    lines = wrapLines(ctx, title, maxW);
    if (lines.length * size * 1.1 < h * 0.5) break;
  }
  ctx.fillStyle = P.ink;
  const y0 = h / 2 - ((lines.length - 1) * size * 1.1) / 2;
  lines.forEach((l, i) => ctx.fillText(l, w / 2, y0 + i * size * 1.1));
  ctx.font = `italic 400 ${Math.round(U * 0.06)}px "Cormorant Garamond", Georgia, serif`;
  ctx.fillStyle = P.ink;
  const sub = [art.artist, art.year].filter(Boolean).join(' · ');
  if (sub) ctx.fillText(sub, w / 2, y0 + lines.length * size * 1.1 + U * 0.04);
  ctx.fillStyle = P.accent;
  ctx.fillRect(w / 2 - U * 0.05, h - m - U * 0.16, U * 0.1, Math.max(1, U * 0.004));
  ctx.font = `500 ${Math.round(U * 0.04)}px "Jost", Arial, sans-serif`;
  ctx.fillText(art.document?.url ? 'PDF · consulter' : art.link?.url ? 'Ouvrir le lien ↗' : '', w / 2, h - m - U * 0.08);
}

function wrapLines(ctx, text, maxW) {
  const words = String(text).split(/\s+/);
  const lines = [];
  let line = '';
  for (const word of words) {
    const t = line ? line + ' ' + word : word;
    if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = word; } else line = t;
  }
  if (line) lines.push(line);
  return lines;
}

/* ---------- outils de dessin ---------- */
function blob(ctx, x, y, rx, ry, r, n = 9) {
  ctx.beginPath();
  for (let k = 0; k <= n; k++) {
    const a = (k / n) * TAU, rr = 1 + (r() - 0.5) * 0.4;
    const px = x + Math.cos(a) * rx * rr, py = y + Math.sin(a) * ry * rr;
    k ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
}

function vgrad(ctx, y0, y1, stops) {
  const g = ctx.createLinearGradient(0, y0, 0, y1);
  stops.forEach(([t, c]) => g.addColorStop(t, c));
  return g;
}

/** Ligne de crête par déplacement du point milieu. */
function ridgePoints(w, baseY, amp, r, rough = 0.55, peaks = 0) {
  let pts = [[0, baseY - amp * r() * 0.6], [w, baseY - amp * r() * 0.6]];
  if (peaks) {
    pts = [[0, baseY - amp * 0.2 * r()]];
    for (let i = 1; i <= peaks; i++) {
      pts.push([(w * (i - 0.5 + (r() - 0.5) * 0.5)) / peaks, baseY - amp * (0.55 + r() * 0.45)]);
      if (i < peaks) pts.push([(w * i) / peaks, baseY - amp * (0.15 + r() * 0.3)]);
    }
    pts.push([w, baseY - amp * 0.2 * r()]);
  }
  let disp = amp * rough;
  for (let it = 0; it < 6; it++) {
    const next = [];
    for (let i = 0; i < pts.length - 1; i++) {
      const [x0, y0] = pts[i], [x1, y1] = pts[i + 1];
      next.push(pts[i], [(x0 + x1) / 2, (y0 + y1) / 2 + (r() - 0.5) * disp]);
    }
    next.push(pts[pts.length - 1]);
    pts = next;
    disp *= 0.52;
  }
  return pts;
}
function fillRidge(ctx, pts, h, fill) {
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.moveTo(0, h);
  pts.forEach(([x, y]) => ctx.lineTo(x, y));
  ctx.lineTo(pts[pts.length - 1][0], h);
  ctx.closePath();
  ctx.fill();
}

function tree(ctx, x, baseY, height, width, pal, r, dabs = 150) {
  ctx.strokeStyle = '#2a2018';
  ctx.lineWidth = Math.max(1, width * 0.05);
  ctx.beginPath();
  ctx.moveTo(x, baseY);
  ctx.quadraticCurveTo(x + (r() - 0.5) * width * 0.2, baseY - height * 0.4, x + (r() - 0.5) * width * 0.15, baseY - height * 0.7);
  ctx.stroke();
  const cx = x, cy = baseY - height * 0.62;
  for (let k = 0; k < dabs; k++) {
    const a = r() * TAU, d = Math.sqrt(r());
    const px = cx + Math.cos(a) * d * width * 0.5;
    const py = cy + Math.sin(a) * d * height * 0.4;
    const light = 0.55 - ((px - cx) / width) * 0.9 - ((py - cy) / height) * 1.3 + (r() - 0.5) * 0.35;
    const idx = clamp(Math.round(light * (pal.length - 1)), 0, pal.length - 1);
    ctx.fillStyle = pal[idx];
    ctx.globalAlpha = 0.85;
    blob(ctx, px, py, width * 0.075 * (0.6 + r()), height * 0.05 * (0.6 + r()), r, 7);
  }
  ctx.globalAlpha = 1;
}

function reflect(ctx, c, hz, w, h, alpha) {
  ctx.save();
  ctx.beginPath(); ctx.rect(0, hz, w, h - hz); ctx.clip();
  ctx.globalAlpha = alpha;
  ctx.translate(0, 2 * hz);
  ctx.scale(1, -1);
  ctx.drawImage(c, 0, 0);
  ctx.restore();
}

function ripples(ctx, hz, w, h, r, color, n = 220) {
  for (let i = 0; i < n; i++) {
    const y = hz + Math.pow(r(), 1.6) * (h - hz);
    const len = w * (0.02 + r() * 0.08) * (0.4 + (y - hz) / (h - hz));
    ctx.strokeStyle = color(r());
    ctx.lineWidth = 1 + ((y - hz) / (h - hz)) * 2.5;
    ctx.beginPath();
    const x = r() * w;
    ctx.moveTo(x, y); ctx.lineTo(x + len, y);
    ctx.stroke();
  }
}

const GREENS = ['#1f2717', '#2d3820', '#3b4a29', '#4d5c32', '#63703f', '#7d8a52', '#9aa06a'];
const AUTUMN = ['#2a1d12', '#4a3018', '#6d441c', '#8f5b22', '#b07a33', '#c99a4c', '#ddb86a'];
const BLUEGREENS = ['#46564f', '#56665c', '#67776a', '#7a897a', '#8c9a8a', '#a3ae9c'];

/* ---------- Styles ---------- */
const STYLES = {
  landscape: {
    stroke: 'flow',
    draw(ctx, w, h, r, c) {
      const autumn = r() < 0.45;
      const hz = h * (0.5 + r() * 0.12);
      ctx.fillStyle = vgrad(ctx, 0, hz, [[0, '#6c8aa8'], [0.55, '#b7c4c9'], [1, autumn ? '#efd9b0' : '#e7e2cc']]);
      ctx.fillRect(0, 0, w, hz);
      for (let i = 0; i < 22; i++) {
        ctx.fillStyle = `rgba(250,244,232,${0.12 + r() * 0.3})`;
        blob(ctx, r() * w, r() * hz * 0.75, w * (0.04 + r() * 0.1), h * (0.015 + r() * 0.04), r, 10);
      }
      fillRidge(ctx, ridgePoints(w, hz - h * 0.03, h * 0.07, r), h, '#8d9b9e');
      fillRidge(ctx, ridgePoints(w, hz, h * 0.04, r), h, '#6f7c6a');
      for (let k = 0; k < 16; k++) {
        tree(ctx, r() * w, hz + h * 0.01, h * (0.1 + r() * 0.1), w * (0.05 + r() * 0.05), BLUEGREENS, r, 60);
      }
      const side = r() < 0.5;
      const pal = autumn ? AUTUMN : GREENS;
      for (let k = 0; k < 6; k++) {
        const x = side ? w * (0.02 + r() * 0.34) : w * (0.64 + r() * 0.34);
        tree(ctx, x, hz + h * 0.05, h * (0.42 + r() * 0.3), w * (0.16 + r() * 0.13), pal, r, 200);
      }
      // un arbre isolé de l'autre côté
      tree(ctx, side ? w * (0.75 + r() * 0.15) : w * (0.1 + r() * 0.15), hz + h * 0.03, h * 0.3, w * 0.12, pal, r, 140);
      // eau
      ctx.fillStyle = vgrad(ctx, hz, h, [[0, '#c3cac4'], [1, '#55604f']]);
      ctx.fillRect(0, hz, w, h - hz);
      reflect(ctx, c, hz, w, h, 0.5);
      ripples(ctx, hz, w, h, r, (t) => `rgba(235,232,220,${0.15 + t * 0.25})`, 160);
      // berge au premier plan
      ctx.fillStyle = autumn ? '#3c2e1b' : '#2f3520';
      ctx.beginPath();
      ctx.moveTo(0, h);
      const by = h * (0.86 + r() * 0.05);
      for (let i = 0; i <= 20; i++) {
        const x = (w * i) / 20;
        const lift = side ? Math.max(0, 1 - i / 9) : Math.max(0, (i - 11) / 9);
        ctx.lineTo(x, by - lift * (by - hz) * 0.75 + (r() - 0.5) * h * 0.015);
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();
      for (let i = 0; i < 260; i++) {
        ctx.strokeStyle = pal[2 + Math.floor(r() * 4)];
        ctx.globalAlpha = 0.6;
        ctx.lineWidth = 1 + r() * 2;
        const x = r() * w, y = by + r() * (h - by);
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (r() - 0.5) * 6, y - h * (0.01 + r() * 0.03)); ctx.stroke();
      }
      ctx.globalAlpha = 1;
    },
  },

  seascape: {
    stroke: 'h',
    draw(ctx, w, h, r) {
      const hz = h * (0.55 + r() * 0.1);
      const warm = r() < 0.7;
      ctx.fillStyle = vgrad(ctx, 0, hz, warm
        ? [[0, '#3f4f74'], [0.45, '#9b7489'], [0.75, '#e19a6e'], [1, '#f6cf92']]
        : [[0, '#6d8db0'], [0.6, '#b8c8d3'], [1, '#eae3d0']]);
      ctx.fillRect(0, 0, w, hz);
      const sx = w * (0.3 + r() * 0.4), sy = hz - h * (0.04 + r() * 0.06);
      const sg = ctx.createRadialGradient(sx, sy, 0, sx, sy, h * 0.4);
      sg.addColorStop(0, warm ? 'rgba(255,236,190,0.95)' : 'rgba(255,255,245,0.8)');
      sg.addColorStop(1, 'rgba(255,220,170,0)');
      ctx.fillStyle = sg; ctx.fillRect(0, 0, w, hz);
      ctx.fillStyle = warm ? '#fff3d6' : '#ffffff';
      ctx.beginPath(); ctx.arc(sx, sy, h * 0.03, 0, TAU); ctx.fill();
      for (let i = 0; i < 26; i++) {
        const y = r() * hz * 0.85;
        ctx.fillStyle = warm ? `rgba(${200 + r() * 55 | 0},${120 + r() * 80 | 0},${110 + r() * 50 | 0},${0.15 + r() * 0.3})` : `rgba(250,250,245,${0.2 + r() * 0.3})`;
        blob(ctx, r() * w, y, w * (0.08 + r() * 0.18), h * (0.008 + r() * 0.018), r, 12);
      }
      ctx.fillStyle = vgrad(ctx, hz, h, warm ? [[0, '#6e6a80'], [0.4, '#3d4560'], [1, '#1f2638']] : [[0, '#6f8796'], [1, '#2c3f4c']]);
      ctx.fillRect(0, hz, w, h - hz);
      // colonne de reflets
      for (let i = 0; i < 260; i++) {
        const y = hz + Math.pow(r(), 1.3) * (h - hz);
        const spread = w * 0.03 + (y - hz) * 0.35;
        const x = sx + (r() - 0.5) * spread * 2;
        ctx.strokeStyle = warm ? `rgba(255,${190 + r() * 50 | 0},${120 + r() * 60 | 0},${0.25 + r() * 0.5})` : `rgba(255,255,250,${0.2 + r() * 0.4})`;
        ctx.lineWidth = 1 + r() * 2.5;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w * (0.01 + r() * 0.04), y); ctx.stroke();
      }
      ripples(ctx, hz, w, h, r, (t) => `rgba(170,180,200,${0.08 + t * 0.2})`, 260);
      // vagues au premier plan
      for (let i = 0; i < 9; i++) {
        const y = h * (0.8 + r() * 0.18);
        ctx.strokeStyle = `rgba(240,236,225,${0.35 + r() * 0.4})`;
        ctx.lineWidth = 2 + r() * 3;
        ctx.beginPath();
        const x0 = r() * w;
        ctx.moveTo(x0, y);
        ctx.quadraticCurveTo(x0 + w * 0.08, y - h * 0.03, x0 + w * (0.15 + r() * 0.15), y + h * 0.005);
        ctx.stroke();
      }
      // falaise
      if (r() < 0.65) {
        const left = r() < 0.5;
        ctx.fillStyle = '#2f2926';
        ctx.beginPath();
        const x0 = left ? 0 : w, dir = left ? 1 : -1;
        ctx.moveTo(x0, h);
        ctx.lineTo(x0, hz - h * 0.28);
        ctx.lineTo(x0 + dir * w * 0.12, hz - h * 0.3);
        ctx.lineTo(x0 + dir * w * 0.2, hz - h * 0.2);
        ctx.lineTo(x0 + dir * w * 0.26, hz - h * 0.02);
        ctx.lineTo(x0 + dir * w * 0.3, hz + h * 0.05);
        ctx.lineTo(x0 + dir * w * 0.22, h);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = 'rgba(95,100,70,0.8)';
        ctx.fillRect(Math.min(x0, x0 + dir * w * 0.15), hz - h * 0.31, w * 0.15, h * 0.015);
      }
      // voile
      const bx = w * (0.15 + r() * 0.7), by = hz + h * 0.01;
      ctx.fillStyle = '#2a2523';
      ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + w * 0.012, by - h * 0.05); ctx.lineTo(bx + w * 0.022, by); ctx.closePath(); ctx.fill();
    },
  },

  mountains: {
    stroke: 'flow',
    draw(ctx, w, h, r, c) {
      const hz = h * (0.66 + r() * 0.06);
      ctx.fillStyle = vgrad(ctx, 0, hz, [[0, '#5f86b5'], [0.7, '#b9cbdb'], [1, '#e8e6dc']]);
      ctx.fillRect(0, 0, w, hz);
      for (let i = 0; i < 12; i++) {
        ctx.fillStyle = `rgba(255,255,255,${0.15 + r() * 0.3})`;
        blob(ctx, r() * w, r() * hz * 0.45, w * (0.05 + r() * 0.12), h * (0.015 + r() * 0.03), r, 10);
      }
      const layers = [
        { base: hz - h * 0.12, amp: h * 0.45, col: '#9aa9bd', snow: true, peaks: 3 },
        { base: hz - h * 0.04, amp: h * 0.3, col: '#75859a', snow: true, peaks: 4 },
        { base: hz, amp: h * 0.13, col: '#4c5b47', snow: false, peaks: 0 },
      ];
      for (const L of layers) {
        const pts = ridgePoints(w, L.base, L.amp, r, 0.35, L.peaks);
        fillRidge(ctx, pts, h, L.col);
        if (L.snow) {
          const snowLine = L.base - L.amp * 0.5;
          ctx.save();
          ctx.beginPath(); ctx.moveTo(0, h); pts.forEach(([x, y]) => ctx.lineTo(x, y)); ctx.lineTo(w, h); ctx.closePath();
          ctx.clip();
          ctx.fillStyle = '#f2f3f4';
          ctx.beginPath(); ctx.moveTo(0, 0);
          pts.forEach(([x, y]) => ctx.lineTo(x, Math.min(y + L.amp * (0.12 + r() * 0.08), snowLine + (r() - 0.5) * h * 0.03)));
          ctx.lineTo(w, 0); ctx.closePath(); ctx.fill();
          // ombre côté droit
          ctx.fillStyle = 'rgba(120,140,170,0.45)';
          for (let i = 1; i < pts.length - 1; i += 2) {
            const [x, y] = pts[i];
            if (y < snowLine && pts[i + 1][1] > y) {
              ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w * 0.05, y + h * 0.12); ctx.lineTo(x + w * 0.012, y + h * 0.12); ctx.closePath(); ctx.fill();
            }
          }
          ctx.restore();
        }
      }
      for (let k = 0; k < 40; k++) {
        const x = r() * w;
        ctx.fillStyle = GREENS[1 + Math.floor(r() * 2)];
        ctx.beginPath();
        const th = h * (0.03 + r() * 0.04), tw = th * 0.35;
        ctx.moveTo(x, hz - th); ctx.lineTo(x + tw, hz + h * 0.005); ctx.lineTo(x - tw, hz + h * 0.005); ctx.closePath(); ctx.fill();
      }
      ctx.fillStyle = vgrad(ctx, hz, h, [[0, '#9fb3c0'], [1, '#3b4c55']]);
      ctx.fillRect(0, hz, w, h - hz);
      reflect(ctx, c, hz, w, h, 0.55);
      ripples(ctx, hz, w, h, r, (t) => `rgba(230,236,240,${0.1 + t * 0.2})`, 140);
      ctx.fillStyle = '#3c4528';
      ctx.beginPath(); ctx.moveTo(0, h);
      for (let i = 0; i <= 16; i++) ctx.lineTo((w * i) / 16, h * 0.93 + (r() - 0.5) * h * 0.03);
      ctx.lineTo(w, h); ctx.closePath(); ctx.fill();
    },
  },

  night: {
    stroke: 'h',
    draw(ctx, w, h, r, c) {
      const hz = h * (0.58 + r() * 0.08);
      ctx.fillStyle = vgrad(ctx, 0, hz, [[0, '#0c1428'], [0.7, '#24345a'], [1, '#41527a']]);
      ctx.fillRect(0, 0, w, hz);
      for (let i = 0; i < 90; i++) {
        ctx.fillStyle = `rgba(255,250,230,${0.2 + r() * 0.6})`;
        ctx.fillRect(r() * w, r() * hz * 0.8, 1.2 + r() * 1.2, 1.2 + r() * 1.2);
      }
      const mx = w * (0.25 + r() * 0.5), my = hz * (0.25 + r() * 0.3), mr = h * 0.045;
      const g = ctx.createRadialGradient(mx, my, 0, mx, my, h * 0.35);
      g.addColorStop(0, 'rgba(240,232,200,0.55)'); g.addColorStop(1, 'rgba(240,232,200,0)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, hz);
      ctx.fillStyle = '#f3ecd3';
      ctx.beginPath(); ctx.arc(mx, my, mr, 0, TAU); ctx.fill();
      for (let i = 0; i < 10; i++) {
        ctx.fillStyle = `rgba(90,105,140,${0.2 + r() * 0.3})`;
        blob(ctx, r() * w, r() * hz * 0.8, w * (0.08 + r() * 0.15), h * (0.01 + r() * 0.02), r, 12);
      }
      fillRidge(ctx, ridgePoints(w, hz, h * 0.06, r), h, '#141c2c');
      for (let k = 0; k < 10; k++) {
        tree(ctx, r() * w, hz + h * 0.01, h * (0.12 + r() * 0.15), w * (0.05 + r() * 0.06), ['#0b1019', '#111826', '#182235', '#1f2b42'], r, 70);
      }
      const hx = w * (0.1 + r() * 0.8);
      ctx.fillStyle = '#10151f';
      ctx.fillRect(hx, hz - h * 0.05, w * 0.05, h * 0.05);
      ctx.beginPath(); ctx.moveTo(hx - w * 0.008, hz - h * 0.05); ctx.lineTo(hx + w * 0.025, hz - h * 0.085); ctx.lineTo(hx + w * 0.058, hz - h * 0.05); ctx.fill();
      ctx.fillStyle = '#ffc56a';
      ctx.fillRect(hx + w * 0.018, hz - h * 0.035, w * 0.012, h * 0.016);
      const wg = ctx.createRadialGradient(hx + w * 0.024, hz - h * 0.027, 0, hx + w * 0.024, hz - h * 0.027, h * 0.06);
      wg.addColorStop(0, 'rgba(255,190,100,0.45)'); wg.addColorStop(1, 'rgba(255,190,100,0)');
      ctx.fillStyle = wg; ctx.fillRect(hx - w * 0.05, hz - h * 0.1, w * 0.15, h * 0.15);
      ctx.fillStyle = vgrad(ctx, hz, h, [[0, '#26365a'], [1, '#080d18']]);
      ctx.fillRect(0, hz, w, h - hz);
      reflect(ctx, c, hz, w, h, 0.45);
      for (let i = 0; i < 200; i++) {
        const y = hz + Math.pow(r(), 1.2) * (h - hz);
        const x = mx + (r() - 0.5) * (w * 0.02 + (y - hz) * 0.25);
        ctx.strokeStyle = `rgba(240,232,200,${0.2 + r() * 0.5})`;
        ctx.lineWidth = 1 + r() * 2;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w * (0.01 + r() * 0.03), y); ctx.stroke();
      }
    },
  },

  portrait: {
    stroke: 'flow',
    draw(ctx, w, h, r, c) {
      const U = Math.min(w, h * 0.8);
      const cx = w * (0.5 + (r() - 0.5) * 0.05);
      const headY = h * 0.36, hrx = U * 0.155, hry = U * 0.205;
      const warmBg = r() < 0.65;
      // fond sombre, plus clair derrière la tête (côté lumière)
      const bg = ctx.createRadialGradient(cx - U * 0.18, h * 0.3, 0, cx, h * 0.45, Math.max(w, h) * 0.8);
      bg.addColorStop(0, warmBg ? '#7a6347' : '#5b625c');
      bg.addColorStop(0.45, warmBg ? '#3d2f22' : '#2e3431');
      bg.addColorStop(1, '#100c09');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);

      const skin = ['#e6c3a1', '#dcb08a', '#cf9d78', '#b07a56', '#86593e'][Math.floor(r() * 5)];
      const hair = ['#1e140d', '#3a2414', '#563820', '#14110f', '#6b4e30'][Math.floor(r() * 5)];
      const cloth = ['#1b1f28', '#3a1b1c', '#1d2a21', '#262422', '#2f3a52'][Math.floor(r() * 5)];
      const sy = headY + hry * 1.5;

      // chevelure arrière, longue
      ctx.fillStyle = hair;
      ctx.beginPath();
      ctx.moveTo(cx - hrx * 0.2, headY - hry * 1.12);
      ctx.bezierCurveTo(cx - hrx * 1.6, headY - hry * 1.1, cx - hrx * 1.5, headY + hry * 0.6, cx - hrx * 1.45, sy + U * 0.08);
      ctx.lineTo(cx + hrx * 1.45, sy + U * 0.08);
      ctx.bezierCurveTo(cx + hrx * 1.5, headY + hry * 0.6, cx + hrx * 1.6, headY - hry * 1.1, cx - hrx * 0.2, headY - hry * 1.12);
      ctx.fill();

      // buste
      const bodyG = ctx.createLinearGradient(cx - U * 0.6, 0, cx + U * 0.6, 0);
      bodyG.addColorStop(0, shade(cloth, 1.7)); bodyG.addColorStop(0.4, cloth); bodyG.addColorStop(1, shade(cloth, 0.45));
      ctx.fillStyle = bodyG;
      ctx.beginPath();
      ctx.moveTo(cx - U * 0.6, h);
      ctx.bezierCurveTo(cx - U * 0.57, sy + U * 0.16, cx - U * 0.38, sy + U * 0.02, cx - U * 0.16, sy);
      ctx.lineTo(cx + U * 0.16, sy);
      ctx.bezierCurveTo(cx + U * 0.38, sy + U * 0.02, cx + U * 0.57, sy + U * 0.16, cx + U * 0.6, h);
      ctx.closePath(); ctx.fill();
      // plis du vêtement
      ctx.strokeStyle = shade(cloth, 1.9); ctx.globalAlpha = 0.25; ctx.lineWidth = Math.max(1, U * 0.01);
      for (let i = 0; i < 6; i++) {
        const x = cx + (r() - 0.6) * U * 0.9;
        ctx.beginPath(); ctx.moveTo(x, sy + U * 0.1); ctx.quadraticCurveTo(x + U * 0.03, sy + U * 0.3, x - U * 0.02, h); ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // cou + décolleté
      const neck = ctx.createLinearGradient(cx - hrx, 0, cx + hrx, 0);
      neck.addColorStop(0, shade(skin, 0.98)); neck.addColorStop(0.55, shade(skin, 0.8)); neck.addColorStop(1, shade(skin, 0.45));
      ctx.fillStyle = neck;
      ctx.beginPath();
      ctx.moveTo(cx - hrx * 0.5, headY + hry * 0.6);
      ctx.lineTo(cx - hrx * 0.62, sy - U * 0.01);
      ctx.quadraticCurveTo(cx - U * 0.15, sy + U * 0.01, cx - U * 0.12, sy + U * 0.02);
      ctx.quadraticCurveTo(cx, sy + U * 0.17, cx + U * 0.12, sy + U * 0.02);
      ctx.quadraticCurveTo(cx + U * 0.15, sy + U * 0.01, cx + hrx * 0.62, sy - U * 0.01);
      ctx.lineTo(cx + hrx * 0.5, headY + hry * 0.6);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(40,24,14,0.14)';
      ctx.beginPath(); ctx.ellipse(cx + hrx * 0.2, headY + hry * 1.08, hrx * 0.5, hry * 0.12, 0, 0, TAU); ctx.fill();

      // visage (forme d'œuf)
      const face = new Path2D();
      face.moveTo(cx, headY - hry);
      face.bezierCurveTo(cx + hrx * 1.08, headY - hry, cx + hrx * 1.02, headY + hry * 0.42, cx + hrx * 0.16, headY + hry * 0.98);
      face.quadraticCurveTo(cx, headY + hry * 1.06, cx - hrx * 0.16, headY + hry * 0.98);
      face.bezierCurveTo(cx - hrx * 1.02, headY + hry * 0.42, cx - hrx * 1.08, headY - hry, cx, headY - hry);
      const fg = ctx.createRadialGradient(cx - hrx * 0.4, headY - hry * 0.2, hrx * 0.05, cx - hrx * 0.1, headY, hrx * 1.3);
      fg.addColorStop(0, shade(skin, 1.1)); fg.addColorStop(0.55, skin); fg.addColorStop(1, shade(skin, 0.6));
      ctx.fillStyle = fg; ctx.fill(face);
      // clair-obscur : moitié droite dans l'ombre
      ctx.save(); ctx.clip(face);
      const side = ctx.createLinearGradient(cx - hrx * 0.1, 0, cx + hrx, 0);
      side.addColorStop(0, 'rgba(45,26,14,0)'); side.addColorStop(0.5, 'rgba(45,26,14,0.28)'); side.addColorStop(1, 'rgba(30,18,10,0.6)');
      ctx.fillStyle = side; ctx.fillRect(cx - hrx * 1.2, headY - hry * 1.2, hrx * 2.4, hry * 2.4);
      // modelé : orbites, pommettes, menton
      const soft = (x, y, rx, ry, col) => {
        const g = ctx.createRadialGradient(x, y, 0, x, y, Math.max(rx, ry));
        g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, TAU); ctx.fill();
      };
      const ey = headY - hry * 0.08;
      for (const s of [-1, 1]) soft(cx + s * hrx * 0.4, ey, hrx * 0.34, hry * 0.17, 'rgba(70,40,25,0.32)');
      soft(cx - hrx * 0.45, headY + hry * 0.32, hrx * 0.32, hry * 0.18, 'rgba(210,120,100,0.16)');
      soft(cx - hrx * 0.25, headY - hry * 0.55, hrx * 0.45, hry * 0.2, 'rgba(255,240,220,0.16)');
      soft(cx, headY + hry * 0.85, hrx * 0.35, hry * 0.12, 'rgba(60,35,20,0.25)');
      ctx.restore();

      // yeux
      for (const s of [-1, 1]) {
        const ex = cx + s * hrx * 0.4;
        ctx.fillStyle = 'rgba(235,225,210,0.55)';
        ctx.beginPath(); ctx.ellipse(ex, ey, hrx * 0.15, hry * 0.04, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(45,30,22,0.85)';
        ctx.beginPath(); ctx.arc(ex + hrx * 0.015, ey, hrx * 0.055, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(40,25,18,0.55)'; ctx.lineWidth = Math.max(1, hrx * 0.03);
        ctx.beginPath(); ctx.moveTo(ex - hrx * 0.16, ey); ctx.quadraticCurveTo(ex, ey - hry * 0.06, ex + hrx * 0.16, ey - hry * 0.005); ctx.stroke();
        ctx.strokeStyle = shade(hair, 1.2); ctx.globalAlpha = 0.6; ctx.lineWidth = Math.max(1, hrx * 0.045);
        ctx.beginPath(); ctx.moveTo(ex - hrx * 0.2, ey - hry * 0.13); ctx.quadraticCurveTo(ex, ey - hry * 0.2, ex + hrx * 0.22, ey - hry * 0.12); ctx.stroke();
        ctx.globalAlpha = 1;
      }
      // nez : arête éclairée, ombre côté droit
      ctx.strokeStyle = 'rgba(255,238,215,0.22)'; ctx.lineWidth = Math.max(1, hrx * 0.05);
      ctx.beginPath(); ctx.moveTo(cx - hrx * 0.03, ey + hry * 0.04); ctx.lineTo(cx - hrx * 0.05, ey + hry * 0.32); ctx.stroke();
      ctx.fillStyle = 'rgba(60,35,22,0.35)';
      ctx.beginPath(); ctx.ellipse(cx + hrx * 0.09, ey + hry * 0.36, hrx * 0.13, hry * 0.05, 0, 0, TAU); ctx.fill();
      // bouche
      const my = headY + hry * 0.6;
      ctx.fillStyle = 'rgba(160,80,70,0.6)';
      ctx.beginPath();
      ctx.moveTo(cx - hrx * 0.24, my);
      ctx.quadraticCurveTo(cx, my - hry * 0.07, cx + hrx * 0.24, my);
      ctx.quadraticCurveTo(cx, my + hry * 0.09, cx - hrx * 0.24, my);
      ctx.fill();
      ctx.strokeStyle = 'rgba(70,30,25,0.5)'; ctx.lineWidth = Math.max(1, hrx * 0.02);
      ctx.beginPath(); ctx.moveTo(cx - hrx * 0.22, my + hry * 0.005); ctx.quadraticCurveTo(cx, my + hry * 0.02, cx + hrx * 0.22, my + hry * 0.005); ctx.stroke();

      // mèches sur le front (raie au milieu)
      ctx.fillStyle = hair;
      for (const s of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(cx + s * hrx * 0.05, headY - hry * 1.04);
        ctx.bezierCurveTo(cx + s * hrx * 0.9, headY - hry * 1.05, cx + s * hrx * 1.15, headY - hry * 0.5, cx + s * hrx * 1.05, headY + hry * 0.15);
        ctx.lineTo(cx + s * hrx * 0.92, headY + hry * 0.1);
        ctx.bezierCurveTo(cx + s * hrx * 0.9, headY - hry * 0.45, cx + s * hrx * 0.55, headY - hry * 0.78, cx + s * hrx * 0.05, headY - hry * 0.86);
        ctx.closePath(); ctx.fill();
      }
      ctx.strokeStyle = shade(hair, 2.2); ctx.globalAlpha = 0.25; ctx.lineWidth = Math.max(1, hrx * 0.03);
      for (let i = 0; i < 14; i++) {
        const s = r() < 0.5 ? -1 : 1, o = 0.3 + r() * 0.7;
        ctx.beginPath(); ctx.moveTo(cx + s * hrx * 0.1, headY - hry * 1.0);
        ctx.quadraticCurveTo(cx + s * hrx * (0.6 + o * 0.5), headY - hry * (0.95 - o * 0.2), cx + s * hrx * (0.95 + o * 0.35), headY + hry * (o * 0.9));
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // bijou
      if (r() < 0.55) {
        ctx.fillStyle = 'rgba(240,235,220,0.9)';
        for (let i = 0; i < 17; i++) {
          const t = i / 16 - 0.5;
          ctx.beginPath(); ctx.arc(cx + t * U * 0.2, sy + U * 0.02 + (0.25 - t * t) * U * 0.16, U * 0.0065, 0, TAU); ctx.fill();
        }
      }

      // sfumato : léger adoucissement d'ensemble
      if ('filter' in ctx) {
        ctx.save();
        ctx.filter = `blur(${Math.max(1, U * 0.004)}px)`;
        ctx.globalAlpha = 0.55;
        ctx.drawImage(c, 0, 0);
        ctx.restore();
      }
    },
  },

  stilllife: {
    stroke: 'flow',
    draw(ctx, w, h, r) {
      const bg = ctx.createRadialGradient(w * 0.3, h * 0.25, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.8);
      bg.addColorStop(0, '#5a4936'); bg.addColorStop(0.55, '#2c231a'); bg.addColorStop(1, '#120e0a');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
      const ty = h * (0.7 + r() * 0.06);
      ctx.fillStyle = vgrad(ctx, ty, h, [[0, '#5a3d27'], [1, '#22160d']]);
      ctx.fillRect(0, ty, w, h - ty);
      ctx.fillStyle = 'rgba(210,160,110,0.35)'; ctx.fillRect(0, ty, w, Math.max(2, h * 0.006));
      // nappe
      ctx.fillStyle = '#e6decd';
      ctx.beginPath();
      ctx.moveTo(w * 0.05, ty);
      ctx.lineTo(w * 0.55, ty);
      ctx.quadraticCurveTo(w * 0.48, ty + (h - ty) * 0.5, w * 0.6, h);
      ctx.lineTo(w * 0.12, h);
      ctx.quadraticCurveTo(w * 0.02, ty + (h - ty) * 0.4, w * 0.05, ty);
      ctx.fill();
      ctx.strokeStyle = 'rgba(150,135,110,0.5)'; ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) {
        const x = w * (0.12 + r() * 0.4);
        ctx.beginPath(); ctx.moveTo(x, ty + 2); ctx.quadraticCurveTo(x + (r() - 0.5) * w * 0.05, ty + (h - ty) * 0.5, x + (r() - 0.5) * w * 0.08, h); ctx.stroke();
      }
      // vase
      const vx = w * (0.42 + r() * 0.16), vh = h * 0.32, vw = Math.min(w * 0.14, vh * 0.42);
      const vb = ty + h * 0.01;
      const vcol = [['#25344f', '#6d86ab'], ['#5a3518', '#c48a4a'], ['#9a9488', '#efe9dc'], ['#33402e', '#7d9372']][Math.floor(r() * 4)];
      const vg = ctx.createLinearGradient(vx - vw, 0, vx + vw, 0);
      vg.addColorStop(0, vcol[0]); vg.addColorStop(0.32, vcol[1]); vg.addColorStop(0.55, vcol[0]); vg.addColorStop(1, shade(vcol[0], 0.5));
      ctx.fillStyle = vg;
      ctx.beginPath();
      ctx.moveTo(vx - vw * 0.45, vb - vh);
      ctx.bezierCurveTo(vx - vw * 0.4, vb - vh * 0.7, vx - vw * 1.1, vb - vh * 0.55, vx - vw * 0.7, vb);
      ctx.lineTo(vx + vw * 0.7, vb);
      ctx.bezierCurveTo(vx + vw * 1.1, vb - vh * 0.55, vx + vw * 0.4, vb - vh * 0.7, vx + vw * 0.45, vb - vh);
      ctx.closePath(); ctx.fill();
      // bouquet
      const fx = vx, fy = vb - vh - h * 0.12;
      const leafCols = ['#26331d', '#34452a', '#4a5c35'];
      for (let i = 0; i < 40; i++) {
        ctx.fillStyle = leafCols[Math.floor(r() * 3)];
        ctx.save();
        ctx.translate(fx + (r() - 0.5) * w * 0.36, fy + (r() - 0.3) * h * 0.26);
        ctx.rotate(r() * TAU);
        ctx.beginPath(); ctx.ellipse(0, 0, w * 0.03, w * 0.011, 0, 0, TAU); ctx.fill();
        ctx.restore();
      }
      const flowerCols = ['#f1ebdf', '#e9b7b2', '#c74a4c', '#f0d27a', '#d98a9a', '#ffffff', '#b33a3f'];
      const n = 16 + Math.floor(r() * 8);
      for (let i = 0; i < n; i++) {
        const a = r() * TAU, d = Math.sqrt(r());
        const px = fx + Math.cos(a) * d * w * 0.17, py = fy + Math.sin(a) * d * h * 0.13;
        const col = flowerCols[Math.floor(r() * flowerCols.length)];
        const pr = Math.min(w, h) * (0.025 + r() * 0.025);
        for (let p = 0; p < 7; p++) {
          const pa = (p / 7) * TAU + r() * 0.3;
          ctx.fillStyle = p % 2 ? col : shade(col, 0.82);
          ctx.beginPath(); ctx.ellipse(px + Math.cos(pa) * pr * 0.55, py + Math.sin(pa) * pr * 0.55, pr * 0.6, pr * 0.38, pa, 0, TAU); ctx.fill();
        }
        ctx.fillStyle = shade(col, 1.15);
        ctx.beginPath(); ctx.arc(px - pr * 0.1, py - pr * 0.1, pr * 0.35, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(120,80,30,0.8)';
        ctx.beginPath(); ctx.arc(px, py, pr * 0.14, 0, TAU); ctx.fill();
      }
      // fruits
      const fruits = 3 + Math.floor(r() * 4);
      for (let i = 0; i < fruits; i++) {
        const kind = r();
        const x = w * (0.15 + r() * 0.75), y = ty + (h - ty) * (0.2 + r() * 0.45);
        const rad = Math.min(w, h) * (0.035 + r() * 0.025);
        if (kind < 0.25) {
          for (let g = 0; g < 14; g++) {
            const gx = x + (r() - 0.5) * rad * 1.8, gy = y - rad + g * rad * 0.12;
            grad(ctx, gx, gy, rad * 0.32, '#5a2f5c', '#1e0f20');
          }
        } else {
          const col = kind < 0.55 ? ['#e8cf5a', '#8a6a1a'] : kind < 0.8 ? ['#c4473a', '#4a120e'] : ['#d28a3c', '#6a3510'];
          grad(ctx, x, y, rad, col[0], col[1], kind < 0.55 ? 1.25 : 1);
        }
      }
    },
  },

  abstract: {
    stroke: 'h',
    draw(ctx, w, h, r) {
      const pals = [
        ['#4b2420', '#9e452d', '#d9a35b', '#e8cf9a'],
        ['#1e2a38', '#4b6a80', '#c9b48a', '#e9dfc8'],
        ['#33321f', '#8a7a4a', '#c8c0a6', '#5f5a3a'],
        ['#3e2232', '#9b5a5a', '#e0b07a', '#d7c6a4'],
        ['#2a2a28', '#b8923e', '#e4d3a8', '#6b4a2b'],
      ];
      const p = pals[Math.floor(r() * pals.length)];
      ctx.fillStyle = p[0]; ctx.fillRect(0, 0, w, h);
      const vertical = h > w;
      const n = 2 + Math.floor(r() * 2);
      const m = Math.min(w, h) * 0.08;
      for (let i = 0; i < n; i++) {
        const col = p[1 + (i % 3)];
        let x, y, bw, bh;
        if (vertical) { x = m; bw = w - 2 * m; bh = (h - m * (n + 1)) / n * (0.8 + r() * 0.3); y = m + i * ((h - m) / n); }
        else { y = m; bh = h - 2 * m; bw = (w - m * (n + 1)) / n * (0.85 + r() * 0.25); x = m + i * ((w - m) / n); }
        for (let k = 0; k < 14; k++) {
          const e = (14 - k) * Math.min(w, h) * 0.004;
          ctx.globalAlpha = 0.09;
          ctx.fillStyle = col;
          ctx.fillRect(x - e + (r() - 0.5) * 3, y - e + (r() - 0.5) * 3, bw + 2 * e, bh + 2 * e);
        }
        ctx.globalAlpha = 0.65;
        ctx.fillRect(x, y, bw, bh);
      }
      ctx.globalAlpha = 1;
      for (let i = 0; i < 120; i++) {
        ctx.strokeStyle = `rgba(255,245,225,${0.03 + r() * 0.06})`;
        ctx.lineWidth = 2 + r() * 8;
        const x = r() * w, y = r() * h;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (r() - 0.5) * w * 0.2, y + (r() - 0.5) * h * 0.05); ctx.stroke();
      }
    },
  },
};

function grad(ctx, x, y, rad, light, dark, sy = 1) {
  const g = ctx.createRadialGradient(x - rad * 0.35, y - rad * 0.35, rad * 0.05, x, y, rad);
  g.addColorStop(0, shade(light, 1.3)); g.addColorStop(0.5, light); g.addColorStop(1, dark);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.ellipse(x, y, rad * sy, rad, 0, 0, TAU); ctx.fill();
}

function shade(hex, k) {
  const n = parseInt(hex.slice(1), 16);
  const r = clamp(((n >> 16) & 255) * k, 0, 255) | 0;
  const g = clamp(((n >> 8) & 255) * k, 0, 255) | 0;
  const b = clamp((n & 255) * k, 0, 255) | 0;
  return `rgb(${r},${g},${b})`;
}

/* ---------- Touches de pinceau ---------- */
function painterly(ctx, w, h, r, mode) {
  const data = ctx.getImageData(0, 0, w, h).data;
  const base = Math.min(w, h);
  const n = Math.floor((w * h) / 80);
  const s = Math.max(1.5, base * 0.0085);
  for (let i = 0; i < n; i++) {
    const x = r() * w, y = r() * h;
    const idx = ((y | 0) * w + (x | 0)) * 4;
    const j = (r() - 0.5) * 16;
    const cr = clamp(data[idx] + j, 0, 255) | 0;
    const cg = clamp(data[idx + 1] + j, 0, 255) | 0;
    const cb = clamp(data[idx + 2] + j * 0.8, 0, 255) | 0;
    let a;
    if (mode === 'h') a = (r() - 0.5) * 0.35;
    else a = Math.sin(x * 0.013 + y * 0.007) * 1.2 + Math.cos(y * 0.011) * 0.8 + (r() - 0.5) * 0.4;
    ctx.fillStyle = `rgba(${cr},${cg},${cb},${0.35 + r() * 0.4})`;
    ctx.beginPath();
    ctx.ellipse(x, y, s * (0.9 + r() * 1.6), s * (0.3 + r() * 0.35), a, 0, TAU);
    ctx.fill();
  }
}

/* ---------- Vernis, grain de toile, vignettage ---------- */
function finish(ctx, w, h, r) {
  ctx.globalCompositeOperation = 'multiply';
  ctx.fillStyle = 'rgba(238,220,180,0.45)';
  ctx.fillRect(0, 0, w, h);
  ctx.globalCompositeOperation = 'source-over';
  const n = (w * h) / 60;
  for (let i = 0; i < n; i++) {
    ctx.fillStyle = r() < 0.5 ? 'rgba(255,250,235,0.05)' : 'rgba(20,12,5,0.05)';
    ctx.fillRect(r() * w, r() * h, 1.5, 1.5);
  }
  const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.hypot(w, h) * 0.6);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, 'rgba(25,15,6,0.38)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}
