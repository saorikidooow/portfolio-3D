/**
 * Accrochage des œuvres : toile + cadre mouluré + ombre de contact + cartel.
 */
import * as THREE from 'three';
import { wallMatrix, wallPoint } from './museum.js';
import { paintArtwork } from './painter.js';
import { textCanvas } from './textures.js';
import { yieldFrame } from './utils.js';
import { resolveAsset } from './content.js';

const loader = new THREE.TextureLoader();

function ringGeometry(W, H, outer, inner, depth, bevel) {
  // outer / inner = demi-largeur ajoutée (+) ou retirée (−) par rapport à la toile
  const bs = bevel ? bevel.size : 0;
  const ow = W + 2 * outer - 2 * bs, oh = H + 2 * outer - 2 * bs;
  const iw = W + 2 * inner + 2 * bs, ih = H + 2 * inner + 2 * bs;
  const s = new THREE.Shape();
  s.moveTo(-ow / 2, -oh / 2); s.lineTo(ow / 2, -oh / 2); s.lineTo(ow / 2, oh / 2); s.lineTo(-ow / 2, oh / 2); s.closePath();
  const hole = new THREE.Path();
  hole.moveTo(-iw / 2, -ih / 2); hole.lineTo(-iw / 2, ih / 2); hole.lineTo(iw / 2, ih / 2); hole.lineTo(iw / 2, -ih / 2); hole.closePath();
  s.holes.push(hole);
  return new THREE.ExtrudeGeometry(s, {
    depth,
    bevelEnabled: !!bevel,
    bevelThickness: bevel ? bevel.thickness : 0,
    bevelSize: bs,
    bevelSegments: bevel ? bevel.segments || 3 : 0,
    curveSegments: 1,
  });
}

/** Cadre : renvoie { meshes, faceWidth, depth } en repère local (z = devant le mur). */
function buildFrame(art, mats) {
  const W = art.width, H = art.height, big = Math.max(W, H);
  const meshes = [];
  const add = (geo, mat, z) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.z = z;
    m.castShadow = true;
    m.receiveShadow = true;
    meshes.push(m);
    return m;
  };
  let fw, depth;
  if (art.frame === 'gilt') {
    fw = THREE.MathUtils.clamp(0.08 + big * 0.03, 0.1, 0.18);
    const mat = mats.gilt.clone(), dark = mats.giltDark.clone();
    add(ringGeometry(W, H, fw, fw * 0.42, 0.03, { thickness: 0.016, size: 0.014, segments: 3 }), mat, 0.02);
    add(ringGeometry(W, H, fw * 0.5, -0.012, 0.05, { thickness: 0.02, size: 0.016, segments: 4 }), mat, 0.024);
    add(ringGeometry(W, H, 0.02, -0.004, 0.07, null), dark, 0.0);
    depth = 0.1;
    art._frameMats = [mat, dark];
  } else {
    fw = THREE.MathUtils.clamp(0.055 + big * 0.02, 0.065, 0.12);
    const base = art.frame === 'black' ? mats.frameBlack : mats.frameWood;
    const mat = base.clone(), fillet = mats.giltDark.clone();
    add(ringGeometry(W, H, fw, -0.012, 0.035, { thickness: 0.02, size: 0.016, segments: 3 }), mat, 0.024);
    add(ringGeometry(W, H, 0.016, -0.004, 0.058, null), fillet, 0.0);
    depth = 0.08;
    art._frameMats = [mat, fillet];
  }
  return { meshes, faceWidth: fw, depth };
}

function labelTexture(art) {
  const c = textCanvas(512, 320, (ctx, w, h) => {
    ctx.fillStyle = '#f7f4ee'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#2a241d';
    ctx.font = 'italic 500 46px "Cormorant Garamond", Georgia, serif';
    wrap(ctx, art.title, 34, 78, w - 68, 50, 2);
    ctx.font = '500 26px "Jost", Arial, sans-serif';
    ctx.fillStyle = '#4a4035';
    ctx.fillText((art.artist || '').toUpperCase(), 34, 210);
    ctx.font = '400 24px "Jost", Arial, sans-serif';
    ctx.fillStyle = '#7a6f62';
    ctx.fillText([art.year, art.technique].filter(Boolean).join(' · '), 34, 252);
    ctx.fillStyle = '#a5844f';
    ctx.fillRect(34, 278, 40, 2);
  });
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

function wrap(ctx, text, x, y, maxW, lh, maxLines) {
  const words = text.split(' ');
  let line = '', n = 0;
  for (let i = 0; i < words.length; i++) {
    const test = line ? line + ' ' + words[i] : words[i];
    if (ctx.measureText(test).width > maxW && line) {
      ctx.fillText(line, x, y + n * lh);
      line = words[i];
      if (++n >= maxLines) return;
    } else line = test;
  }
  ctx.fillText(line, x, y + n * lh);
}

/** Texture de la toile : image fournie (recadrée « cover »), affiche ou peinture générée. */
function artworkTexture(art, renderer, files) {
  const aniso = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  const procedural = () => {
    const px = Math.round(THREE.MathUtils.clamp(Math.max(art.width, art.height) * 330, 384, 1024));
    const t = new THREE.CanvasTexture(paintArtwork(art, px));
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = aniso;
    return t;
  };
  if (art.visual !== 'image' || !art.image) return Promise.resolve(procedural());
  return new Promise((resolve) => {
    loader.setCrossOrigin('anonymous');
    loader.load(resolveAsset(art.image, files), (t) => {
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = aniso;
      const ia = t.image.width / t.image.height, ca = art.width / art.height;
      if (ia > ca) { t.repeat.set(ca / ia, 1); t.offset.set((1 - ca / ia) / 2, 0); }
      else { t.repeat.set(1, ia / ca); t.offset.set(0, (1 - ia / ca) / 2); }
      art._imageLoaded = true;
      resolve(t);
    }, undefined, () => {
      console.warn(`Image introuvable pour « ${art.title} » : ${art.image} — peinture générée utilisée.`);
      resolve(procedural());
    });
  });
}

export async function hangArtworks(artworks, walls, mats, renderer, onProgress, files = {}) {
  const group = new THREE.Group();
  group.name = 'artworks';
  const pickables = [];
  const shadowGeo = new THREE.PlaneGeometry(1, 1);

  for (let i = 0; i < artworks.length; i++) {
    const art = artworks[i];
    art.index = i;
    const wall = walls[art.wall];
    if (!wall) { console.warn('Mur inconnu pour', art.title, art.wall); continue; }

    const holder = new THREE.Group();
    holder.matrixAutoUpdate = false;
    holder.matrix.copy(wallMatrix(wall, art.u, art.y, 0));
    holder.userData.art = art;

    const frame = buildFrame(art, mats);
    frame.meshes.forEach((m) => { holder.add(m); m.userData.art = art; pickables.push(m); });

    const tex = await artworkTexture(art, renderer, files);
    const canvasMat = new THREE.MeshStandardMaterial({
      map: tex, roughness: 0.58, metalness: 0,
      emissive: 0xffffff, emissiveMap: tex, emissiveIntensity: 0,
    });
    const canvasMesh = new THREE.Mesh(new THREE.PlaneGeometry(art.width, art.height), canvasMat);
    canvasMesh.position.z = 0.05;
    canvasMesh.receiveShadow = true;
    canvasMesh.userData.art = art;
    holder.add(canvasMesh);
    pickables.push(canvasMesh);

    // ombre de contact douce sur le mur (le cadre ne « flotte » pas)
    const fw = frame.faceWidth;
    const sh = new THREE.Mesh(shadowGeo, mats.contactShadow);
    sh.scale.set((art.width + 2 * fw) * 1.42, (art.height + 2 * fw) * 1.42 + 0.08, 1);
    sh.position.set(0.02, -0.06, 0.003);
    sh.renderOrder = 1;
    holder.add(sh);

    // cartel
    const bottom = art.y - art.height / 2 - fw;
    if (art.label !== 'none' && art.label !== false && bottom < 2.3) {
      const lw = 0.2, lh = 0.125;
      const label = new THREE.Mesh(
        new THREE.BoxGeometry(lw, lh, 0.006),
        new THREE.MeshStandardMaterial({ map: labelTexture(art), roughness: 0.7 })
      );
      if (art.label === 'below') label.position.set(0, -art.height / 2 - fw - 0.13, 0.003);
      else {
        const ly = THREE.MathUtils.clamp(Math.max(1.42, bottom + 0.1), 1.3, 1.65) - art.y;
        label.position.set(art.width / 2 + fw + 0.24, ly, 0.003);
      }
      label.receiveShadow = true;
      holder.add(label);
    }

    holder.updateMatrixWorld(true);
    art._canvasMat = canvasMat;
    art._texture = tex;
    art._normal = wall.normal.clone();
    art._center = wallPoint(wall, art.u, art.y, 0.05);
    art._hover = 0;
    group.add(holder);

    onProgress?.(i + 1, artworks.length);
    await yieldFrame();
  }
  return { group, pickables };
}

/** Image grand format pour la fiche (régénérée en haute définition). */
export function artworkImageURL(art, files = {}) {
  if (art.visual === 'image' && art.image && art._imageLoaded) return resolveAsset(art.image, files);
  if (!art._hiRes) {
    const c = paintArtwork(art, 1400);
    art._hiRes = c.toDataURL('image/jpeg', 0.9);
  }
  return art._hiRes;
}
