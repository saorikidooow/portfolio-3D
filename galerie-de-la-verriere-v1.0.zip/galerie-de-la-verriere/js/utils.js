import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export { mulberry32, clamp, lerp, makeNoise } from './random.js';

/** Rend la main au navigateur (barre de progression fluide pendant la construction). */
export const yieldFrame = () => new Promise((r) => setTimeout(r, 0));

/**
 * UV « monde » en mètres, projetées selon l'axe dominant de la normale.
 * Garantit une densité de texture constante quelle que soit la taille des pièces.
 */
export function applyWorldUV(geo) {
  const pos = geo.attributes.position, nor = geo.attributes.normal;
  const uv = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const nx = Math.abs(nor.getX(i)), ny = Math.abs(nor.getY(i)), nz = Math.abs(nor.getZ(i));
    let u, v;
    if (ny >= nx && ny >= nz) { u = x; v = z; }
    else if (nx >= nz) { u = z; v = y; }
    else { u = x; v = y; }
    uv[i * 2] = u; uv[i * 2 + 1] = v;
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
}

export function trs(x, y, z, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
  return new THREE.Matrix4().compose(
    new THREE.Vector3(x, y, z),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz, 'YXZ')),
    new THREE.Vector3(sx, sy, sz)
  );
}

/**
 * Regroupe toutes les pièces statiques par matériau puis les fusionne :
 * quelques appels de rendu seulement pour toute l'architecture.
 */
export class Batch {
  constructor() { this.buckets = new Map(); }

  add(key, geometry, matrix, worldUV = true) {
    const g = geometry.index ? geometry.toNonIndexed() : geometry.clone();
    if (matrix) g.applyMatrix4(matrix);
    for (const name of Object.keys(g.attributes)) {
      if (name !== 'position' && name !== 'normal' && name !== 'uv') g.deleteAttribute(name);
    }
    if (worldUV || !g.attributes.uv) applyWorldUV(g);
    g.clearGroups();
    g.morphAttributes = {};
    if (!this.buckets.has(key)) this.buckets.set(key, []);
    this.buckets.get(key).push(g);
    return g;
  }

  box(key, w, h, d, matrix) {
    const g = new THREE.BoxGeometry(w, h, d);
    this.add(key, g, matrix);
    g.dispose();
  }

  build(materials, shadowCfg = {}) {
    const meshes = [];
    for (const [key, list] of this.buckets) {
      const merged = mergeGeometries(list, false);
      list.forEach((g) => g.dispose());
      if (!merged) { console.warn('Fusion impossible pour', key); continue; }
      merged.computeBoundingSphere();
      const mesh = new THREE.Mesh(merged, materials[key]);
      const cfg = shadowCfg[key] || {};
      mesh.castShadow = cfg.cast ?? true;
      mesh.receiveShadow = cfg.receive ?? true;
      if (cfg.renderOrder) mesh.renderOrder = cfg.renderOrder;
      mesh.name = 'batch:' + key;
      mesh.matrixAutoUpdate = false;
      meshes.push(mesh);
    }
    this.buckets.clear();
    return meshes;
  }
}
