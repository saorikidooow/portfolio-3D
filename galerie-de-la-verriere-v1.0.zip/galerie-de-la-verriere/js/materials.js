import * as THREE from 'three';
import {
  plasterCanvas, darkWoodCanvas, parquetCanvases, fabricCanvas,
  skyCanvas, glowCanvas, contactShadowCanvas,
} from './textures.js';
import { TEXTURE_OVERRIDES } from './config.js';
import { hexToRgb } from './random.js';

function tex(canvas, renderer, { repeat = 1, srgb = true } = {}) {
  const t = new THREE.CanvasTexture(canvas);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  return t;
}

function applyOverride(material, key, renderer) {
  const o = TEXTURE_OVERRIDES[key];
  if (!o || !o.src) return;
  new THREE.TextureLoader().load(o.src, (t) => {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(1 / o.size, 1 / o.size);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    material.map = t;
    material.needsUpdate = true;
  }, undefined, () => console.warn('Texture introuvable :', o.src));
}

/** Matériaux physiques (PBR) de toute la galerie. */
export function createMaterials(renderer, theme = {}) {
  const plasterC = plasterCanvas(512, hexToRgb(theme.walls, [240, 236, 228]), 1);
  const trimC = plasterCanvas(256, hexToRgb(theme.trim, [244, 241, 235]), 2);
  const woodC = darkWoodCanvas(512, 5, hexToRgb(theme.wood, [70, 44, 27]));
  const floorC = parquetCanvases(3);

  const plasterMap = tex(plasterC, renderer, { repeat: 0.5 });
  const plasterBump = tex(plasterC, renderer, { repeat: 0.5, srgb: false });
  const trimMap = tex(trimC, renderer, { repeat: 1 });
  const woodMap = tex(woodC, renderer, { repeat: 1 });
  const floorMap = tex(floorC.color, renderer, { repeat: 0.25 });
  const floorRough = tex(floorC.rough, renderer, { repeat: 0.25, srgb: false });
  const floorBump = tex(floorC.bump, renderer, { repeat: 0.25, srgb: false });
  const fabricMap = tex(fabricCanvas(), renderer, { repeat: 14 });

  const skyTex = new THREE.CanvasTexture(skyCanvas());
  skyTex.colorSpace = THREE.SRGBColorSpace;
  const glowTex = new THREE.CanvasTexture(glowCanvas());
  glowTex.colorSpace = THREE.SRGBColorSpace;
  const shadowTex = new THREE.CanvasTexture(contactShadowCanvas());

  const m = {
    plaster: new THREE.MeshStandardMaterial({
      map: plasterMap, bumpMap: plasterBump, bumpScale: 0.35, roughness: 0.94, metalness: 0,
    }),
    trim: new THREE.MeshStandardMaterial({ map: trimMap, roughness: 0.62, metalness: 0 }),
    ceiling: new THREE.MeshStandardMaterial({ map: trimMap, roughness: 0.94, metalness: 0 }),
    darkWood: new THREE.MeshStandardMaterial({ map: woodMap, roughness: 0.48, metalness: 0 }),
    floor: new THREE.MeshStandardMaterial({
      color: new THREE.Color(theme.floor || '#ffffff'), map: floorMap, roughnessMap: floorRough, roughness: 1, bumpMap: floorBump, bumpScale: 1.4, metalness: 0,
    }),
    fabric: new THREE.MeshStandardMaterial({ map: fabricMap, roughness: 0.96, metalness: 0 }),
    brass: new THREE.MeshStandardMaterial({ color: 0xb08648, roughness: 0.32, metalness: 1 }),
    line: new THREE.MeshStandardMaterial({ color: 0x8c6c48, roughness: 0.55, metalness: 0.2 }),
    lamp: new THREE.MeshStandardMaterial({
      color: 0xfff7ea, emissive: 0xffe4bd, emissiveIntensity: 1.6, roughness: 0.8,
    }),
    glass: new THREE.MeshStandardMaterial({
      color: 0xeef4fa, roughness: 0.08, metalness: 0, transparent: true, opacity: 0.16,
      depthWrite: false, side: THREE.DoubleSide,
    }),
    marble: new THREE.MeshStandardMaterial({ color: 0xe9e4da, roughness: 0.35, metalness: 0 }),
    sky: new THREE.MeshBasicMaterial({ map: skyTex, color: new THREE.Color(1.35, 1.35, 1.35), fog: false }),
    glow: new THREE.MeshBasicMaterial({
      map: glowTex, transparent: true, opacity: 0.55, depthWrite: false,
      blending: THREE.AdditiveBlending, fog: false,
    }),
    // cadres
    gilt: new THREE.MeshStandardMaterial({ color: new THREE.Color(theme.gilt || '#c49b56'), roughness: 0.3, metalness: 1 }),
    giltDark: new THREE.MeshStandardMaterial({ color: 0x8f6a35, roughness: 0.42, metalness: 1 }),
    frameWood: new THREE.MeshStandardMaterial({ map: woodMap, color: 0xa08470, roughness: 0.42, metalness: 0 }),
    frameBlack: new THREE.MeshStandardMaterial({ color: 0x17130f, roughness: 0.38, metalness: 0 }),
    contactShadow: new THREE.MeshBasicMaterial({
      color: 0x000000, alphaMap: shadowTex, transparent: true, opacity: 0.32, depthWrite: false,
    }),
  };

  applyOverride(m.floor, 'floor', renderer);
  applyOverride(m.plaster, 'plaster', renderer);
  applyOverride(m.darkWood, 'darkWood', renderer);

  m._glowTexture = glowTex;
  return m;
}
