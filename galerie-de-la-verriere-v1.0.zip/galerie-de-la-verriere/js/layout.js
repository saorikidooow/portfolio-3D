/**
 * Dimensions et plan de la galerie (sans Three.js).
 * Partagé par la scène 3D (museum.js) et par l'interface d'administration
 * (plan des murs pour placer les œuvres). Unités : mètres.
 */
export const DIM = {
  W: 8,            // largeur intérieure de la galerie
  L: 42,           // longueur
  T: 0.35,         // épaisseur des murs
  WALL_H: 6.75,
  WAIN_H: 1.15,    // hauteur des soubassements en bois
  CORNICE_Y: 6.0,
  RAIL_Y: 5.5,
  SLOPE_Y0: 6.6,   // naissance du plafond incliné
  SLOPE_Y1: 8.2,   // bord de la verrière
  SKY: 2.3,        // demi-largeur de la verrière
  GLASS_Y: 8.75,
  PIL: [3, 9, 15, 21, 27, 33, 39],
  PIL_BASE: 0.86,
  ENTRY_HW: 1.8, ENTRY_H: 4.2,
  ARCH_HW: 1.2, ARCH_SPRING: 3.0,
  DOOR_U: 6, DOOR_HW: 1.3, DOOR_H: 4.4,
  VEST_HW: 3, VEST_D: 4.6, VEST_H: 5.0,
  BACK_HW: 3, BACK_D: 5.0, BACK_H: 5.4,
};


const PIL_HW = DIM.PIL_BASE / 2;

/**
 * Description 2D de chaque mur accrochable, vue par un visiteur qui fait face au mur.
 *  - length : longueur utile (u va de 0 à length)
 *  - top    : hauteur maximale conseillée pour le haut d'un cadre
 *  - mirror : true si u augmente vers la GAUCHE quand on fait face au mur
 *  - blocks : zones où l'on ne peut rien accrocher (pilastres, portes, arche)
 */
export const WALLS = {
  left: {
    label: 'Mur de gauche', hint: "u = distance depuis l'entrée (0 → 42 m)",
    length: DIM.L, top: DIM.RAIL_Y - 0.05, mirror: false,
    blocks: DIM.PIL.map((p) => ({ u0: p - PIL_HW, u1: p + PIL_HW, y0: 0, y1: DIM.CORNICE_Y, kind: 'pilastre' })),
  },
  right: {
    label: 'Mur de droite', hint: "u = distance depuis l'entrée (0 → 42 m)",
    length: DIM.L, top: DIM.RAIL_Y - 0.05, mirror: true,
    blocks: [
      ...DIM.PIL.map((p) => ({ u0: p - PIL_HW, u1: p + PIL_HW, y0: 0, y1: DIM.CORNICE_Y, kind: 'pilastre' })),
      { u0: DIM.DOOR_U - DIM.DOOR_HW - 0.2, u1: DIM.DOOR_U + DIM.DOOR_HW + 0.2, y0: 0, y1: DIM.DOOR_H + 0.42, kind: 'porte' },
    ],
  },
  end: {
    label: 'Mur du fond (autour de l\'arche)', hint: 'u = de gauche à droite (0 → 8 m)',
    length: DIM.W, top: DIM.CORNICE_Y - 0.4, mirror: false,
    blocks: [{ u0: DIM.W / 2 - DIM.ARCH_HW - 0.2, u1: DIM.W / 2 + DIM.ARCH_HW + 0.2, y0: 0, y1: DIM.ARCH_SPRING + DIM.ARCH_HW + 0.3, kind: 'arche' }],
  },
  back: {
    label: 'Petite salle du fond', hint: 'u = de gauche à droite (0 → 6 m)',
    length: 2 * DIM.BACK_HW, top: DIM.BACK_H - 0.45, mirror: false, blocks: [],
  },
  entrance: {
    label: "Mur d'entrée (côté galerie)", hint: 'u = de gauche à droite (0 → 8 m)',
    length: DIM.W, top: DIM.CORNICE_Y - 0.4, mirror: false,
    blocks: [{ u0: DIM.W / 2 - DIM.ENTRY_HW - 0.2, u1: DIM.W / 2 + DIM.ENTRY_HW + 0.2, y0: 0, y1: DIM.ENTRY_H + 0.42, kind: 'entrée' }],
  },
};

/** Hauteur des soubassements : rien ne doit descendre en dessous. */
export const HANG_MIN_Y = DIM.WAIN_H + 0.1;
