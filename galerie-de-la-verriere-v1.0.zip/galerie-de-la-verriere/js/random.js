/**
 * Outils sans dépendance (aucun import de Three.js) : utilisables par le site
 * ET par l'interface d'administration.
 */

/** Générateur pseudo-aléatoire déterministe (mêmes œuvres à chaque visite). */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, t) => a + (b - a) * t;

/** Bruit de valeur périodique (textures raccordables) + fBm. */
export function makeNoise(seed) {
  const r = mulberry32(seed);
  const V = new Float32Array(65536);
  for (let i = 0; i < V.length; i++) V[i] = r();
  const lat = (x, y, px, py) => {
    x %= px; if (x < 0) x += px;
    y %= py; if (y < 0) y += py;
    return V[((y & 255) << 8) | (x & 255)];
  };
  const noise = (x, y, px = 256, py = 256) => {
    const xi = Math.floor(x), yi = Math.floor(y);
    const fx = x - xi, fy = y - yi;
    const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
    const a = lat(xi, yi, px, py), b = lat(xi + 1, yi, px, py);
    const c = lat(xi, yi + 1, px, py), d = lat(xi + 1, yi + 1, px, py);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
  const fbm = (x, y, oct = 4, px = 8, py = 8) => {
    let s = 0, amp = 0.5, f = 1, n = 0;
    for (let o = 0; o < oct; o++) {
      s += amp * noise(x * f, y * f, px * f, py * f);
      n += amp; amp *= 0.5; f *= 2;
    }
    return s / n;
  };
  return { noise, fbm };
}


export function makeCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

export function hexToRgb(hex, fallback = [255, 255, 255]) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
  if (!m) return fallback;
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
