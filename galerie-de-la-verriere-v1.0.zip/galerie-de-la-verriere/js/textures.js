/**
 * Textures procédurales (Canvas 2D) : aucune image externe n'est nécessaire,
 * mais chacune peut être remplacée par un fichier de assets/textures/ (voir config.js).
 */
import { mulberry32, makeNoise, clamp, makeCanvas } from './random.js';
export { makeCanvas };

/* ---------- Plâtre blanc cassé ---------- */
export function plasterCanvas(size = 512, base = [238, 234, 226], seed = 1) {
  const c = makeCanvas(size, size), ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size), d = img.data;
  const { noise, fbm } = makeNoise(seed);
  const r = mulberry32(seed + 7);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size, v = y / size;
      const n = fbm(u * 6, v * 6, 4, 6, 6);
      const g = noise(u * 96, v * 96, 96, 96);
      const k = 0.96 + (n - 0.5) * 0.07 + (g - 0.5) * 0.028 + (r() - 0.5) * 0.018;
      const i = (y * size + x) * 4;
      d[i] = base[0] * k; d[i + 1] = base[1] * k; d[i + 2] = base[2] * k; d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

/* ---------- Bois sombre (soubassements, portes, cadres) ---------- */
export function darkWoodCanvas(size = 512, seed = 5, base = [70, 44, 27]) {
  const c = makeCanvas(size, size), ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size), d = img.data;
  const { noise, fbm } = makeNoise(seed);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size, v = y / size;
      const warp = fbm(u * 3, v * 12, 4, 3, 12);
      const rings = v * 26 + warp * 5;
      const ring = Math.pow(0.5 + 0.5 * Math.sin(rings * Math.PI * 2), 3);
      const streak = noise(u * 4, v * 210, 4, 210);
      const blot = fbm(u * 2, v * 2, 3, 2, 2);
      const k = 0.78 + ring * 0.22 + (streak - 0.5) * 0.32 + (blot - 0.5) * 0.28;
      const i = (y * size + x) * 4;
      d[i] = base[0] * k; d[i + 1] = base[1] * k; d[i + 2] = base[2] * k; d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

/* ---------- Parquet en bois clair (couleur + rugosité + relief) ---------- */
export function parquetCanvases(seed = 3) {
  const S = 2048, PXM = S / 4, N = 20, pw = S / N; // 4 m × 4 m, lames de 20 cm
  const r = mulberry32(seed);
  const col = makeCanvas(S, S), ctx = col.getContext('2d');
  const RS = 1024, k = RS / S;
  const rough = makeCanvas(RS, RS), rctx = rough.getContext('2d');
  const bump = makeCanvas(RS, RS), bctx = bump.getContext('2d');
  ctx.fillStyle = '#5c4430'; ctx.fillRect(0, 0, S, S);
  rctx.fillStyle = '#fff'; rctx.fillRect(0, 0, RS, RS);
  bctx.fillStyle = '#222'; bctx.fillRect(0, 0, RS, RS);

  for (let i = 0; i < N; i++) {
    const x = i * pw;
    let y = r() * S, covered = 0;
    while (covered < S - 1) {
      let len = (1.1 + r() * 2.1) * PXM;
      if (covered + len > S - 0.6 * PXM) len = S - covered;
      const p = {
        x, y, w: pw, h: len,
        hue: 27 + r() * 6, sat: 20 + r() * 10, lit: 40 + r() * 10,
        rough: 0.48 + r() * 0.26, height: 0.82 + r() * 0.12,
        seed: (r() * 1e9) | 0,
      };
      for (const off of [0, -S]) {
        const q = { ...p, y: p.y + off };
        drawPlank(ctx, q);
        // rugosité
        rctx.fillStyle = `rgb(${(q.rough * 255) | 0},${(q.rough * 255) | 0},${(q.rough * 255) | 0})`;
        rctx.fillRect(q.x * k + 1, q.y * k + 1, q.w * k - 1.5, q.h * k - 1.5);
        // relief : légère irrégularité d'une lame à l'autre, joints creusés
        const hv = (q.height * 255) | 0;
        bctx.fillStyle = `rgb(${hv},${hv},${hv})`;
        bctx.fillRect(q.x * k + 1.2, q.y * k + 1.2, q.w * k - 1.8, q.h * k - 1.8);
      }
      y += len; covered += len;
    }
  }

  // Patine d'ensemble (raccordable)
  const pr = mulberry32(seed + 99);
  for (let n = 0; n < 70; n++) {
    const bx = pr() * S, by = pr() * S, rad = (0.3 + pr() * 1.1) * PXM;
    const light = pr() < 0.55;
    const a = 0.015 + pr() * 0.03;
    for (const ox of [-S, 0, S]) for (const oy of [-S, 0, S]) {
      const g = ctx.createRadialGradient(bx + ox, by + oy, 0, bx + ox, by + oy, rad);
      g.addColorStop(0, light ? `rgba(225,214,195,${a})` : `rgba(40,26,14,${a})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.fillRect(bx + ox - rad, by + oy - rad, rad * 2, rad * 2);
    }
  }
  return { color: col, rough, bump };
}

function drawPlank(ctx, p) {
  const r = mulberry32(p.seed);
  ctx.save();
  ctx.beginPath(); ctx.rect(p.x, p.y, p.w, p.h); ctx.clip();
  ctx.fillStyle = `hsl(${p.hue},${p.sat}%,${p.lit}%)`;
  ctx.fillRect(p.x, p.y, p.w, p.h);
  // variation tonale le long de la lame
  const g = ctx.createLinearGradient(0, p.y, 0, p.y + p.h);
  for (let s = 0; s <= 4; s++) {
    const l = p.lit + (r() - 0.5) * 12;
    g.addColorStop(s / 4, `hsla(${p.hue},${p.sat - 4}%,${l}%,0.55)`);
  }
  ctx.fillStyle = g; ctx.fillRect(p.x, p.y, p.w, p.h);
  // fil du bois
  for (let n = 0; n < 34; n++) {
    const gx = p.x + r() * p.w;
    const dl = (r() - 0.5) * 18 - 5;
    ctx.strokeStyle = `hsla(${p.hue - 3},${p.sat + 6}%,${clamp(p.lit + dl, 10, 90)}%,${0.08 + r() * 0.22})`;
    ctx.lineWidth = 0.6 + r() * 2.4;
    ctx.beginPath(); ctx.moveTo(gx, p.y);
    let cx = gx;
    const segs = 4;
    for (let s = 1; s <= segs; s++) {
      const ny = p.y + (p.h * s) / segs;
      const nx = gx + (r() - 0.5) * p.w * 0.22;
      ctx.quadraticCurveTo(cx + (r() - 0.5) * p.w * 0.3, ny - p.h / segs / 2, nx, ny);
      cx = nx;
    }
    ctx.stroke();
  }
  // usure grisée (aspect patiné de la photo)
  for (let n = 0; n < 4; n++) {
    ctx.fillStyle = `hsla(34,10%,${62 + r() * 18}%,${0.05 + r() * 0.09})`;
    ctx.beginPath();
    ctx.ellipse(p.x + r() * p.w, p.y + r() * p.h, p.w * (0.3 + r() * 0.6), p.h * (0.08 + r() * 0.2), 0, 0, Math.PI * 2);
    ctx.fill();
  }
  // nœud
  if (r() < 0.22) {
    const kx = p.x + p.w * (0.25 + r() * 0.5), ky = p.y + r() * p.h;
    for (let k = 4; k >= 1; k--) {
      ctx.strokeStyle = `hsla(${p.hue - 6},${p.sat + 10}%,${p.lit - 12 - k * 3}%,0.35)`;
      ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.ellipse(kx, ky, k * 3.2, k * 7, 0, 0, Math.PI * 2); ctx.stroke();
    }
  }
  // joints
  ctx.fillStyle = 'rgba(30,19,10,0.78)';
  ctx.fillRect(p.x, p.y, 2.5, p.h);
  ctx.fillRect(p.x, p.y, p.w, 2.5);
  ctx.fillStyle = 'rgba(255,240,220,0.10)';
  ctx.fillRect(p.x + 2.5, p.y, 1.5, p.h);
  ctx.restore();
}

/* ---------- Tissu crème des assises ---------- */
export function fabricCanvas(size = 128) {
  const c = makeCanvas(size, size), ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size), d = img.data;
  const r = mulberry32(11);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const weave = ((x >> 1) + (y >> 1)) % 2 ? 0.96 : 1.02;
    const k = weave + (r() - 0.5) * 0.05;
    const i = (y * size + x) * 4;
    d[i] = 232 * k; d[i + 1] = 224 * k; d[i + 2] = 206 * k; d[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

/* ---------- Ciel vu à travers la verrière ---------- */
export function skyCanvas() {
  const W = 1024, H = 512;
  const c = makeCanvas(W, H), ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, '#c9d9ea'); g.addColorStop(0.5, '#e4ecf4'); g.addColorStop(1, '#c4d5e8');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const img = ctx.getImageData(0, 0, W, H), d = img.data;
  const { fbm } = makeNoise(21);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const n = fbm((x / W) * 6, (y / H) * 3, 5, 6, 3);
    const cl = clamp((n - 0.48) * 3.2, 0, 1);
    const i = (y * W + x) * 4;
    d[i] += (252 - d[i]) * cl; d[i + 1] += (252 - d[i + 1]) * cl; d[i + 2] += (250 - d[i + 2]) * cl;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

/* ---------- Halo lumineux (appliques) ---------- */
export function glowCanvas(size = 128) {
  const c = makeCanvas(size, size), ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255,236,205,1)');
  g.addColorStop(0.25, 'rgba(255,220,170,0.45)');
  g.addColorStop(0.6, 'rgba(255,210,160,0.12)');
  g.addColorStop(1, 'rgba(255,200,150,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, size, size);
  return c;
}

/* ---------- Ombre de contact derrière les cadres ---------- */
export function contactShadowCanvas(size = 256) {
  const c = makeCanvas(size, size), ctx = c.getContext('2d');
  // alphaMap : on lit le canal vert → forme blanche sur fond noir
  const m = size * 0.2;
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, size, size);
  ctx.shadowColor = '#fff';
  ctx.shadowBlur = size * 0.09;
  ctx.fillStyle = '#fff';
  ctx.fillRect(m, m, size - 2 * m, size - 2 * m);
  return c;
}

/* ---------- Texte (cartels, inscription) ---------- */
export function textCanvas(w, h, draw) {
  const c = makeCanvas(w, h), ctx = c.getContext('2d');
  draw(ctx, w, h);
  return c;
}
