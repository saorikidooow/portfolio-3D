/** Écrans et interface HTML (chargement, accueil, pause, survol, fiche d'œuvre). */
import { isSafeUrl } from './content.js';

export class UI {
  constructor() {
    const $ = (id) => document.getElementById(id);
    this.el = {
      loader: $('loader'), bar: $('loader-bar'), status: $('loader-status'), percent: $('loader-percent'),
      welcome: $('welcome'), enter: $('enter-btn'),
      capTitle: $('cap-title'), capArtist: $('cap-artist'), hint: $('controls-hint'), touchHint: $('touch-hint'),
      menu: $('menu-btn'), pause: $('pause'), resume: $('resume-btn'),
      modal: $('artwork-modal'), img: $('modal-image'), index: $('modal-index'), title: $('modal-title'),
      artist: $('modal-artist'), year: $('modal-year'), tech: $('modal-technique'), dims: $('modal-dimensions'),
      desc: $('modal-description'), close: $('modal-close'), back: $('modal-back'),
      link: $('modal-link'), doc: $('modal-document'),
      banner: $('preview-banner'), error: $('error'),
    };
    this.site = {};
    this._hover = null;
    this._hintTimer = null;
  }

  /** Textes, liens et couleurs de l'interface à partir de content/site.json. */
  applyContent(content) {
    const { site, links, theme } = content;
    this.site = site;
    document.querySelectorAll('[data-text]').forEach((n) => {
      const v = site[n.dataset.text];
      if (typeof v === 'string') n.textContent = v;
    });
    document.title = site.name + (site.tagline ? ' — ' + site.tagline : '');
    const meta = document.querySelector('meta[name="description"]');
    if (meta && site.metaDescription) meta.setAttribute('content', site.metaDescription);
    document.querySelectorAll('[data-links]').forEach((ul) => {
      ul.replaceChildren(...links.filter((l) => l.url && isSafeUrl(l.url)).map((l) => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.href = l.url;
        a.textContent = l.label || l.url;
        if (!/^(mailto:|tel:)/i.test(l.url)) { a.target = '_blank'; a.rel = 'noopener'; }
        li.append(a);
        return li;
      }));
    });
    const root = document.documentElement.style;
    root.setProperty('--gold', theme.accent);
    root.setProperty('--ink', theme.ink);
    root.setProperty('--cream', theme.background);
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme.background);
  }

  showPreviewBanner() {
    this.el.banner.hidden = false;
    document.body.classList.add('preview');
  }

  progress(p, text) {
    const pct = Math.round(p * 100);
    this.el.bar.style.width = pct + '%';
    this.el.percent.textContent = pct + ' %';
    if (text) this.el.status.textContent = text;
  }

  show(el, on) { el.classList.toggle('is-visible', on); }
  hideLoader() { this.show(this.el.loader, false); }
  showWelcome(on = true) { this.show(this.el.welcome, on); if (on) setTimeout(() => this.el.enter.focus({ preventScroll: true }), 300); }
  showPause(on = true) { this.show(this.el.pause, on); }

  setTouring(on) { document.body.classList.toggle('touring', on); if (on) this.activity(); }
  setDragMode(on) { document.body.classList.toggle('drag-mode', on); }

  activity() {
    this.el.hint.classList.remove('is-faded');
    clearTimeout(this._hintTimer);
    this._hintTimer = setTimeout(() => {
      this.el.hint.classList.add('is-faded');
      this.el.touchHint.classList.add('is-faded');
    }, 7000);
  }

  setHover(art) {
    if (art === this._hover) return;
    this._hover = art;
    document.body.classList.toggle('hovering', !!art);
    if (art) {
      this.el.capTitle.textContent = art.title;
      this.el.capArtist.textContent = [art.artist, art.year].filter(Boolean).join(' · ');
    }
  }

  openModal(art, total, imageURL, docURL) {
    const e = this.el;
    e.index.textContent = `Œuvre n° ${String(art.index + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`;
    e.title.textContent = art.title;
    e.artist.textContent = art.artist;
    e.year.textContent = art.year;
    e.tech.textContent = art.technique;
    e.dims.textContent = art.dimensions || `${Math.round(art.height * 100)} × ${Math.round(art.width * 100)} cm`;
    document.getElementById('row-year').hidden = !art.year;
    document.getElementById('row-technique').hidden = !art.technique;
    e.desc.textContent = art.description || '';
    const setBtn = (a, url, label) => {
      a.hidden = !url || !isSafeUrl(url);
      if (!a.hidden) { a.href = url; a.textContent = label; }
    };
    setBtn(e.link, art.link.url, art.link.label || this.site.linkLabel || 'Ouvrir le lien');
    setBtn(e.doc, docURL, art.document.label || this.site.documentLabel || 'Consulter le document');
    e.img.alt = [art.title, art.artist].filter(Boolean).join(', ');
    e.img.classList.add('is-loading');
    const preview = art._texture?.image;
    if (preview && preview.toDataURL) e.img.src = preview.toDataURL('image/jpeg', 0.8);
    e.modal.classList.add('is-open');
    e.modal.setAttribute('aria-hidden', 'false');
    setTimeout(() => {
      const url = imageURL(art);
      e.img.onload = () => e.img.classList.remove('is-loading');
      e.img.src = url;
      if (e.img.complete) e.img.classList.remove('is-loading');
      e.back.focus({ preventScroll: true });
    }, 40);
  }

  closeModal() {
    this.el.modal.classList.remove('is-open');
    this.el.modal.setAttribute('aria-hidden', 'true');
  }

  get modalOpen() { return this.el.modal.classList.contains('is-open'); }

  fatal(msg) {
    this.el.error.textContent = msg;
    this.show(this.el.error, true);
    this.hideLoader();
  }
}
