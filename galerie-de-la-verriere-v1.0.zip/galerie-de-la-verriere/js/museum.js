/**
 * Architecture de la galerie : murs, soubassements, pilastres, corniche,
 * plafond à verrière, portes, sièges. Toutes les pièces statiques sont
 * fusionnées par matériau pour limiter les appels de rendu.
 */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { Batch, trs } from './utils.js';
import { textCanvas } from './textures.js';
import { DIM } from './layout.js';

export { DIM };

const UP = new THREE.Vector3(0, 1, 0);

export function makeWall(name, origin, dir, normal, length) {
  const X = new THREE.Vector3().crossVectors(UP, normal).normalize();
  const s = X.dot(dir) >= 0 ? 1 : -1;
  const M = new THREE.Matrix4().makeBasis(X, UP, normal).setPosition(origin);
  return { name, origin, dir, normal, length, s, M };
}

/** Matrice monde d'un point (u le long du mur, y hauteur, d distance devant le mur). */
export function wallMatrix(wall, u, y, d, local) {
  const m = new THREE.Matrix4().makeTranslation(u * wall.s, y, d);
  if (local) m.multiply(local);
  return wall.M.clone().multiply(m);
}

export function wallPoint(wall, u, y, d) {
  return new THREE.Vector3(u * wall.s, y, d).applyMatrix4(wall.M);
}

function subtract(a, b, holes) {
  let segs = [[a, b]];
  for (const [h0, h1] of holes) {
    const next = [];
    for (const [s0, s1] of segs) {
      if (h1 <= s0 || h0 >= s1) { next.push([s0, s1]); continue; }
      if (h0 > s0) next.push([s0, h0]);
      if (h1 < s1) next.push([h1, s1]);
    }
    segs = next;
  }
  return segs.filter(([s0, s1]) => s1 - s0 > 0.05);
}

export function buildMuseum(mats, options = {}) {
  const D = DIM;
  const { W, L, T } = D;
  const b = new Batch();
  const colliders = [];
  const sconces = [];
  const group = new THREE.Group();
  group.name = 'museum';
  const V = (x, y, z) => new THREE.Vector3(x, y, z);

  const walls = {
    left: makeWall('left', V(-W / 2, 0, 0), V(0, 0, -1), V(1, 0, 0), L),
    right: makeWall('right', V(W / 2, 0, 0), V(0, 0, -1), V(-1, 0, 0), L),
    end: makeWall('end', V(-W / 2, 0, -L), V(1, 0, 0), V(0, 0, 1), W),
    entrance: makeWall('entrance', V(W / 2, 0, 0), V(-1, 0, 0), V(0, 0, -1), W),
    entranceOut: makeWall('entranceOut', V(-W / 2, 0, T), V(1, 0, 0), V(0, 0, 1), W),
    endOut: makeWall('endOut', V(W / 2, 0, -L - T), V(-1, 0, 0), V(0, 0, -1), W),
    vestL: makeWall('vestL', V(-D.VEST_HW, 0, T), V(0, 0, 1), V(1, 0, 0), D.VEST_D),
    vestR: makeWall('vestR', V(D.VEST_HW, 0, T), V(0, 0, 1), V(-1, 0, 0), D.VEST_D),
    vestBack: makeWall('vestBack', V(D.VEST_HW, 0, T + D.VEST_D), V(-1, 0, 0), V(0, 0, -1), 2 * D.VEST_HW),
    backL: makeWall('backL', V(-D.BACK_HW, 0, -L - T), V(0, 0, -1), V(1, 0, 0), D.BACK_D),
    backR: makeWall('backR', V(D.BACK_HW, 0, -L - T), V(0, 0, -1), V(-1, 0, 0), D.BACK_D),
    back: makeWall('back', V(-D.BACK_HW, 0, -L - T - D.BACK_D), V(1, 0, 0), V(0, 0, 1), 2 * D.BACK_HW),
  };

  const at = (wall, u, y, d, local) => wallMatrix(wall, u, y, d, local);
  const box = (key, w, h, d, m) => b.box(key, w, h, d, m);

  function wallAABB(wall, u0, u1, d0, d1) {
    const pts = [[u0, d0], [u0, d1], [u1, d0], [u1, d1]].map(([u, d]) => wallPoint(wall, u, 0, d));
    return {
      minX: Math.min(...pts.map((p) => p.x)), maxX: Math.max(...pts.map((p) => p.x)),
      minZ: Math.min(...pts.map((p) => p.z)), maxZ: Math.max(...pts.map((p) => p.z)),
    };
  }

  /* ---------- Murs (dalles extrudées, ouvertures découpées) ---------- */
  function slab(wall, pts, key = 'plaster') {
    const shape = new THREE.Shape();
    pts.forEach(([u, y], i) => (i ? shape.lineTo(u * wall.s, y) : shape.moveTo(u * wall.s, y)));
    const g = new THREE.ExtrudeGeometry(shape, { depth: T, bevelEnabled: false });
    b.add(key, g, wall.M.clone().multiply(new THREE.Matrix4().makeTranslation(0, 0, -T)));
    g.dispose();
  }
  const archPts = (cu, hw, spring) => {
    const pts = [[cu - hw, 0], [cu - hw, spring]];
    const N = 28;
    for (let k = 1; k < N; k++) {
      const a = Math.PI - (Math.PI * k) / N;
      pts.push([cu + hw * Math.cos(a), spring + hw * Math.sin(a)]);
    }
    pts.push([cu + hw, spring], [cu + hw, 0]);
    return pts;
  };
  const rectNotch = (cu, hw, h) => [[cu - hw, 0], [cu - hw, h], [cu + hw, h], [cu + hw, 0]];
  const crossSection = (notch) => [
    [-T, 0], ...notch, [W + T, 0], [W + T, D.WALL_H],
    [W / 2 + D.SKY + 0.12, D.SLOPE_Y1 + 0.16], [W / 2 + D.SKY + 0.12, D.GLASS_Y + 0.08],
    [W / 2 - D.SKY - 0.12, D.GLASS_Y + 0.08], [W / 2 - D.SKY - 0.12, D.SLOPE_Y1 + 0.16],
    [-T, D.WALL_H],
  ];

  slab(walls.left, [[0, 0], [L, 0], [L, D.WALL_H], [0, D.WALL_H]]);
  slab(walls.right, [[0, 0], ...rectNotch(D.DOOR_U, D.DOOR_HW, D.DOOR_H), [L, 0], [L, D.WALL_H], [0, D.WALL_H]]);
  slab(walls.end, crossSection(archPts(W / 2, D.ARCH_HW, D.ARCH_SPRING)));
  slab(walls.entrance, crossSection(rectNotch(W / 2, D.ENTRY_HW, D.ENTRY_H)));

  // vestibule et salle du fond
  const VH = D.VEST_H, BH = D.BACK_H;
  slab(walls.vestL, [[-T, 0], [D.VEST_D + T, 0], [D.VEST_D + T, VH + 0.2], [-T, VH + 0.2]]);
  slab(walls.vestR, [[-T, 0], [D.VEST_D + T, 0], [D.VEST_D + T, VH + 0.2], [-T, VH + 0.2]]);
  slab(walls.vestBack, [[-T, 0], ...rectNotch(D.VEST_HW, 1.1, 3.4), [2 * D.VEST_HW + T, 0], [2 * D.VEST_HW + T, VH + 0.2], [-T, VH + 0.2]]);
  slab(walls.backL, [[-T, 0], [D.BACK_D + T, 0], [D.BACK_D + T, BH + 0.2], [-T, BH + 0.2]]);
  slab(walls.backR, [[-T, 0], [D.BACK_D + T, 0], [D.BACK_D + T, BH + 0.2], [-T, BH + 0.2]]);
  slab(walls.back, [[-T, 0], [2 * D.BACK_HW + T, 0], [2 * D.BACK_HW + T, BH + 0.2], [-T, BH + 0.2]]);

  /* ---------- Sols et plafonds secondaires ---------- */
  const floorPlane = (x0, x1, z0, z1) => {
    const g = new THREE.PlaneGeometry(x1 - x0, z1 - z0);
    b.add('floor', g, trs((x0 + x1) / 2, 0, (z0 + z1) / 2, -Math.PI / 2, 0, 0));
    g.dispose();
  };
  floorPlane(-W / 2, W / 2, -L, 0);
  floorPlane(-D.VEST_HW, D.VEST_HW, 0, T + D.VEST_D);
  floorPlane(-D.BACK_HW, D.BACK_HW, -L - T - D.BACK_D, -L);
  box('marble', 2 * D.ENTRY_HW, 0.012, T, trs(0, 0.006, T / 2));
  box('marble', 2 * D.ARCH_HW, 0.012, T, trs(0, 0.006, -L - T / 2));
  box('ceiling', 2 * D.VEST_HW + 2 * T, 0.25, D.VEST_D + 2 * T, trs(0, VH + 0.125, T + D.VEST_D / 2));
  box('ceiling', 2 * D.BACK_HW + 2 * T, 0.25, D.BACK_D + 2 * T, trs(0, BH + 0.125, -L - T - D.BACK_D / 2));

  /* ---------- Extrusions le long des murs (corniches, plafond) ---------- */
  function extrudeAlong(key, wall, shape, u0, u1, segs = 10) {
    const a0 = Math.min(u0 * wall.s, u1 * wall.s), a1 = Math.max(u0 * wall.s, u1 * wall.s);
    const g = new THREE.ExtrudeGeometry(shape, { depth: a1 - a0, bevelEnabled: false, curveSegments: segs });
    const local = new THREE.Matrix4().makeTranslation(a1, 0, 0).multiply(new THREE.Matrix4().makeRotationY(-Math.PI / 2));
    b.add(key, g, wall.M.clone().multiply(local));
    g.dispose();
  }
  function corniceShape(Y, k = 1) {
    const s = new THREE.Shape();
    s.moveTo(0, Y - 0.08 * k);
    s.lineTo(0.04 * k, Y - 0.08 * k); s.lineTo(0.04 * k, Y - 0.02 * k);
    s.lineTo(0.07 * k, Y - 0.02 * k); s.lineTo(0.07 * k, Y + 0.04 * k);
    s.absarc(0.07 * k, Y + 0.3 * k, 0.26 * k, -Math.PI / 2, 0, false);
    s.lineTo(0.36 * k, Y + 0.3 * k); s.lineTo(0.36 * k, Y + 0.34 * k);
    s.lineTo(0.42 * k, Y + 0.34 * k); s.lineTo(0.42 * k, Y + 0.42 * k);
    s.lineTo(0.46 * k, Y + 0.42 * k); s.lineTo(0.46 * k, Y + 0.48 * k);
    s.lineTo(0, Y + 0.48 * k);
    s.closePath();
    return s;
  }
  const cornice = corniceShape(D.CORNICE_Y);
  for (const w of [walls.left, walls.right]) extrudeAlong('trim', w, cornice, 0, L);
  for (const w of [walls.end, walls.entrance]) extrudeAlong('trim', w, cornice, 0, W);
  const vc = corniceShape(VH - 0.34, 0.7);
  for (const w of [walls.vestL, walls.vestR]) extrudeAlong('trim', w, vc, 0, D.VEST_D);
  extrudeAlong('trim', walls.vestBack, vc, 0, 2 * D.VEST_HW);
  extrudeAlong('trim', walls.entranceOut, vc, W / 2 - D.VEST_HW, W / 2 + D.VEST_HW);
  const bc = corniceShape(BH - 0.34, 0.7);
  for (const w of [walls.backL, walls.backR]) extrudeAlong('trim', w, bc, 0, D.BACK_D);
  extrudeAlong('trim', walls.back, bc, 0, 2 * D.BACK_HW);
  extrudeAlong('trim', walls.endOut, bc, W / 2 - D.BACK_HW, W / 2 + D.BACK_HW);

  // cimaise (rail d'accrochage) le long des grands murs
  for (const w of [walls.left, walls.right]) {
    box('trim', L, 0.05, 0.035, at(w, L / 2, D.RAIL_Y, 0.0175));
    box('trim', L, 0.018, 0.05, at(w, L / 2, D.RAIL_Y + 0.034, 0.025));
  }

  /* ---------- Plafond incliné, nervures et verrière ---------- */
  const DS = W / 2 - D.SKY; // projection horizontale du rampant
  const slopeShape = new THREE.Shape();
  slopeShape.moveTo(0, D.SLOPE_Y0);
  slopeShape.lineTo(DS, D.SLOPE_Y1);
  slopeShape.lineTo(DS, D.SLOPE_Y1 + 0.16);
  slopeShape.lineTo(0, D.SLOPE_Y0 + 0.16);
  slopeShape.closePath();
  const sdir = new THREE.Vector3(0, D.SLOPE_Y1 - D.SLOPE_Y0, DS);
  const slopeLen = sdir.length();
  sdir.normalize();
  const ndown = new THREE.Vector3(0, -sdir.z, sdir.y);
  const XL = new THREE.Vector3(1, 0, 0);

  for (const w of [walls.left, walls.right]) {
    extrudeAlong('ceiling', w, slopeShape, 0, L);
    // nervures transversales
    for (let u = 1; u < L; u += 2) {
      const heavy = D.PIL.includes(u);
      const wr = heavy ? 0.3 : 0.15, dep = heavy ? 0.24 : 0.15;
      const c = new THREE.Vector3(u * w.s, (D.SLOPE_Y0 + D.SLOPE_Y1) / 2, DS / 2).addScaledVector(ndown, dep / 2 - 0.01);
      const basis = new THREE.Matrix4().makeBasis(XL, sdir, ndown).setPosition(c);
      box('trim', wr, slopeLen * 0.985, dep, w.M.clone().multiply(basis));
    }
    // filet longitudinal à mi-rampant
    const mid = new THREE.Vector3(0, D.SLOPE_Y0 + (D.SLOPE_Y1 - D.SLOPE_Y0) * 0.08, DS * 0.08).addScaledVector(ndown, 0.03);
    const mb = new THREE.Matrix4().makeBasis(XL, sdir, ndown).setPosition(mid.x + (L / 2) * w.s, mid.y, mid.z);
    box('trim', L, 0.12, 0.06, w.M.clone().multiply(mb));
  }
  // poutres longitudinales en rive de verrière + jouées de lanterneau
  for (const sx of [-1, 1]) {
    box('trim', 0.28, 0.32, L, trs(sx * (D.SKY + 0.06), D.SLOPE_Y1 - 0.08, -L / 2));
    box('trim', 0.1, D.GLASS_Y - D.SLOPE_Y1 + 0.12, L, trs(sx * (D.SKY + 0.05), (D.SLOPE_Y1 + D.GLASS_Y) / 2, -L / 2));
  }
  // poutres transversales sous la verrière
  for (let u = 1; u < L; u += 2) {
    const heavy = D.PIL.includes(u);
    const dep = heavy ? 0.32 : 0.2, wr = heavy ? 0.3 : 0.15;
    box('trim', 2 * D.SKY + 0.1, dep, wr, trs(0, D.SLOPE_Y1 + 0.1 - dep / 2, -u));
  }
  // verre + petits bois
  {
    const g = new THREE.PlaneGeometry(2 * D.SKY + 0.2, L);
    b.add('glass', g, trs(0, D.GLASS_Y, -L / 2, -Math.PI / 2, 0, 0));
    g.dispose();
  }
  for (const x of [-D.SKY / 2, 0, D.SKY / 2]) box('trim', 0.05, 0.08, L, trs(x, D.GLASS_Y - 0.04, -L / 2));
  for (let u = 0.5; u < L; u += 1) box('trim', 2 * D.SKY, 0.08, 0.05, trs(0, D.GLASS_Y - 0.04, -u));

  /* ---------- Soubassements en bois ---------- */
  function wainscot(wall, u0, u1) {
    const len = u1 - u0;
    if (len < 0.25) return;
    const mid = (u0 + u1) / 2, H = D.WAIN_H;
    box('darkWood', len, H, 0.03, at(wall, mid, H / 2, 0.015));
    box('darkWood', len, 0.16, 0.06, at(wall, mid, 0.08, 0.03));
    box('darkWood', len, 0.025, 0.07, at(wall, mid, 0.172, 0.035));
    box('darkWood', len, 0.07, 0.085, at(wall, mid, H - 0.035, 0.0425));
    box('darkWood', len, 0.035, 0.06, at(wall, mid, H - 0.088, 0.03));
    const n = Math.max(1, Math.round(len / 1.15));
    const st = 0.11, pw = (len - st * (n + 1)) / n;
    if (pw < 0.15) return;
    const py0 = 0.27, py1 = H - 0.17, ph = py1 - py0, pyc = (py0 + py1) / 2;
    const mw = 0.03, md = 0.055;
    for (let i = 0; i < n; i++) {
      const cu = u0 + st + pw / 2 + i * (pw + st);
      box('darkWood', pw - 0.12, ph - 0.12, 0.05, at(wall, cu, pyc, 0.025));
      box('darkWood', pw, mw, md, at(wall, cu, py1 - mw / 2, md / 2));
      box('darkWood', pw, mw, md, at(wall, cu, py0 + mw / 2, md / 2));
      box('darkWood', mw, ph - 2 * mw, md, at(wall, cu - pw / 2 + mw / 2, pyc, md / 2));
      box('darkWood', mw, ph - 2 * mw, md, at(wall, cu + pw / 2 - mw / 2, pyc, md / 2));
    }
  }
  const pilHoles = D.PIL.map((p) => [p - D.PIL_BASE / 2, p + D.PIL_BASE / 2]);
  const doorHole = [D.DOOR_U - D.DOOR_HW - 0.22, D.DOOR_U + D.DOOR_HW + 0.22];
  for (const [a, c] of subtract(0, L, pilHoles)) wainscot(walls.left, a, c);
  for (const [a, c] of subtract(0, L, [...pilHoles, doorHole])) wainscot(walls.right, a, c);
  for (const [a, c] of subtract(0, W, [[W / 2 - D.ARCH_HW - 0.22, W / 2 + D.ARCH_HW + 0.22]])) wainscot(walls.end, a, c);
  for (const [a, c] of subtract(0, W, [[W / 2 - D.ENTRY_HW - 0.22, W / 2 + D.ENTRY_HW + 0.22]])) wainscot(walls.entrance, a, c);
  for (const [a, c] of subtract(W / 2 - D.VEST_HW, W / 2 + D.VEST_HW, [[W / 2 - D.ENTRY_HW - 0.22, W / 2 + D.ENTRY_HW + 0.22]])) wainscot(walls.entranceOut, a, c);
  for (const [a, c] of subtract(W / 2 - D.BACK_HW, W / 2 + D.BACK_HW, [[W / 2 - D.ARCH_HW - 0.22, W / 2 + D.ARCH_HW + 0.22]])) wainscot(walls.endOut, a, c);
  wainscot(walls.vestL, 0, D.VEST_D);
  wainscot(walls.vestR, 0, D.VEST_D);
  for (const [a, c] of subtract(0, 2 * D.VEST_HW, [[D.VEST_HW - 1.1 - 0.22, D.VEST_HW + 1.1 + 0.22]])) wainscot(walls.vestBack, a, c);
  wainscot(walls.backL, 0, D.BACK_D);
  wainscot(walls.backR, 0, D.BACK_D);
  wainscot(walls.back, 0, 2 * D.BACK_HW);

  /* ---------- Pilastres + appliques ---------- */
  function sconce(wall, u, y, d0) {
    box('darkWood', 0.2, 0.44, 0.05, at(wall, u, y, d0 + 0.025));
    box('darkWood', 0.25, 0.05, 0.075, at(wall, u, y + 0.245, d0 + 0.0375));
    box('darkWood', 0.25, 0.04, 0.07, at(wall, u, y - 0.24, d0 + 0.035));
    box('brass', 0.03, 0.03, 0.16, at(wall, u, y - 0.08, d0 + 0.05 + 0.08));
    box('brass', 0.022, 0.11, 0.022, at(wall, u, y - 0.04, d0 + 0.2));
    const shade = new THREE.CylinderGeometry(0.075, 0.095, 0.2, 24, 1, false);
    b.add('lamp', shade, at(wall, u, y + 0.1, d0 + 0.2));
    shade.dispose();
    const glow = new THREE.PlaneGeometry(0.7, 1.6);
    b.add('glow', glow, at(wall, u, y + 0.25, d0 + 0.004), false);
    glow.dispose();
    sconces.push(wallPoint(wall, u, y + 0.1, d0 + 0.2));
  }
  function pilaster(wall, u) {
    const bw = D.PIL_BASE, sw = 0.72, sd = 0.22, H = D.WAIN_H;
    box('trim', bw + 0.04, 0.14, 0.32, at(wall, u, 0.07, 0.16));
    box('trim', bw, H + 0.02, 0.3, at(wall, u, (H + 0.02) / 2, 0.15));
    box('trim', bw + 0.05, 0.06, 0.335, at(wall, u, H + 0.05, 0.1675));
    const y0 = H + 0.08, y1 = D.CORNICE_Y - 0.26;
    box('trim', sw, y1 - y0, sd, at(wall, u, (y0 + y1) / 2, sd / 2));
    // filets incrustés (encadrement fin, comme sur la photo)
    const ix = sw / 2 - 0.1, iy0 = y0 + 0.28, iy1 = y1 - 0.3, lw = 0.02, ld = 0.008;
    box('line', lw, iy1 - iy0, ld, at(wall, u - ix, (iy0 + iy1) / 2, sd + ld / 2));
    box('line', lw, iy1 - iy0, ld, at(wall, u + ix, (iy0 + iy1) / 2, sd + ld / 2));
    box('line', 2 * ix + lw, lw, ld, at(wall, u, iy0, sd + ld / 2));
    box('line', 2 * ix + lw, lw, ld, at(wall, u, iy1, sd + ld / 2));
    // chapiteau mouluré
    box('trim', sw + 0.06, 0.1, sd + 0.04, at(wall, u, y1 + 0.05, (sd + 0.04) / 2));
    box('trim', sw + 0.14, 0.08, sd + 0.08, at(wall, u, y1 + 0.14, (sd + 0.08) / 2));
    box('trim', sw + 0.2, 0.08, sd + 0.12, at(wall, u, y1 + 0.22, (sd + 0.12) / 2));
    sconce(wall, u, 4.55, sd);
    colliders.push(wallAABB(wall, u - 0.47, u + 0.47, 0, 0.36));
  }
  for (const w of [walls.left, walls.right]) for (const u of D.PIL) pilaster(w, u);

  /* ---------- Portes en bois sombre & encadrements ---------- */
  function raisedPanel(wall, u, y, w, h, d) {
    box('darkWood', w - 0.09, h - 0.09, 0.022, at(wall, u, y, d + 0.011));
    const mw = 0.03, md = 0.032;
    box('darkWood', w, mw, md, at(wall, u, y + h / 2 - mw / 2, d + md / 2));
    box('darkWood', w, mw, md, at(wall, u, y - h / 2 + mw / 2, d + md / 2));
    box('darkWood', mw, h - 2 * mw, md, at(wall, u - w / 2 + mw / 2, y, d + md / 2));
    box('darkWood', mw, h - 2 * mw, md, at(wall, u + w / 2 - mw / 2, y, d + md / 2));
  }
  function architrave(wall, u, hw, h, withCap = true) {
    const aw = 0.2;
    box('trim', aw, h + aw, 0.05, at(wall, u - hw - aw / 2, (h + aw) / 2, 0.025));
    box('trim', aw, h + aw, 0.05, at(wall, u + hw + aw / 2, (h + aw) / 2, 0.025));
    box('trim', 2 * hw + 2 * aw, aw, 0.05, at(wall, u, h + aw / 2, 0.025));
    box('trim', 0.03, h + aw - 0.04, 0.065, at(wall, u - hw - aw + 0.015, (h + aw) / 2, 0.0325));
    box('trim', 0.03, h + aw - 0.04, 0.065, at(wall, u + hw + aw - 0.015, (h + aw) / 2, 0.0325));
    if (withCap) {
      box('trim', 2 * hw + 2 * aw + 0.16, 0.07, 0.11, at(wall, u, h + aw + 0.035, 0.055));
      box('trim', 2 * hw + 2 * aw + 0.24, 0.05, 0.14, at(wall, u, h + aw + 0.095, 0.07));
    }
  }
  function doubleDoor(wall, u, hw, h) {
    const dz = -T * 0.55;
    box('darkWood', 0.05, h, T, at(wall, u - hw + 0.025, h / 2, -T / 2));
    box('darkWood', 0.05, h, T, at(wall, u + hw - 0.025, h / 2, -T / 2));
    box('darkWood', 2 * hw, 0.05, T, at(wall, u, h - 0.025, -T / 2));
    const lw = hw - 0.05 - 0.004;
    for (const side of [-1, 1]) {
      const cu = u + side * (lw / 2 + 0.004);
      const lh = h - 0.05;
      box('darkWood', lw, lh, 0.06, at(wall, cu, lh / 2, dz));
      const m = 0.14, gap = 0.13, inner = lh - 2 * m - 2 * gap;
      const hs = [inner * 0.24, inner * 0.46, inner * 0.3];
      let y = m;
      for (const ph of hs) {
        raisedPanel(wall, cu, y + ph / 2, lw - 2 * m, ph, dz + 0.03);
        y += ph + gap;
      }
      box('brass', 0.024, 0.28, 0.03, at(wall, u + side * 0.075, 1.12, dz + 0.06));
      box('brass', 0.05, 0.05, 0.02, at(wall, u + side * 0.075, 1.0, dz + 0.04));
    }
    architrave(wall, u, hw, h);
  }
  doubleDoor(walls.right, D.DOOR_U, D.DOOR_HW, D.DOOR_H);
  doubleDoor(walls.vestBack, D.VEST_HW, 1.1, 3.4);
  architrave(walls.entrance, W / 2, D.ENTRY_HW, D.ENTRY_H);
  architrave(walls.entranceOut, W / 2, D.ENTRY_HW, D.ENTRY_H);

  function archTrim(wall, u) {
    const hw = D.ARCH_HW, sp = D.ARCH_SPRING, aw = 0.2;
    box('trim', aw, sp, 0.05, at(wall, u - hw - aw / 2, sp / 2, 0.025));
    box('trim', aw, sp, 0.05, at(wall, u + hw + aw / 2, sp / 2, 0.025));
    box('trim', aw + 0.08, 0.1, 0.08, at(wall, u - hw - aw / 2, sp - 0.05, 0.04));
    box('trim', aw + 0.08, 0.1, 0.08, at(wall, u + hw + aw / 2, sp - 0.05, 0.04));
    const s = new THREE.Shape();
    s.moveTo(hw + aw, 0);
    s.absarc(0, 0, hw + aw, 0, Math.PI, false);
    s.lineTo(-hw, 0);
    s.absarc(0, 0, hw, Math.PI, 0, true);
    s.closePath();
    const g = new THREE.ExtrudeGeometry(s, { depth: 0.05, bevelEnabled: false, curveSegments: 40 });
    b.add('trim', g, at(wall, u, sp, 0));
    g.dispose();
    box('trim', 0.26, 0.36, 0.09, at(wall, u, sp + hw + 0.12, 0.045));
  }
  archTrim(walls.end, W / 2);
  archTrim(walls.endOut, W / 2);

  /* ---------- Chaises médaillon ---------- */
  function chair(x, z, ry) {
    const base = trs(x, 0, z, 0, ry, 0);
    const add = (key, geo, local) => { b.add(key, geo, base.clone().multiply(local)); geo.dispose(); };
    add('fabric', new RoundedBoxGeometry(0.5, 0.09, 0.46, 3, 0.035), trs(0, 0.475, 0.01));
    add('darkWood', new THREE.BoxGeometry(0.52, 0.06, 0.48), trs(0, 0.41, 0));
    for (const sx of [-1, 1]) {
      add('darkWood', new THREE.CylinderGeometry(0.022, 0.014, 0.38, 12), trs(sx * 0.22, 0.19, 0.2));
      add('darkWood', new THREE.CylinderGeometry(0.02, 0.014, 0.39, 12), trs(sx * 0.21, 0.19, -0.2, -0.08, 0, 0));
      add('darkWood', new THREE.CylinderGeometry(0.016, 0.016, 0.17, 8), trs(sx * 0.1, 0.52, -0.215, -0.1, 0, 0));
    }
    add('darkWood', new THREE.TorusGeometry(0.2, 0.022, 10, 44), trs(0, 0.8, -0.24, -0.12, 0, 0, 1, 1.18, 1));
    add('fabric', new THREE.SphereGeometry(1, 28, 16), trs(0, 0.8, -0.236, -0.12, 0, 0, 0.186, 0.222, 0.032));
    colliders.push({ minX: x - 0.34, maxX: x + 0.34, minZ: z - 0.34, maxZ: z + 0.34 });
  }
  // disposés comme dans la photo : face aux grandes toiles
  chair(2.35, -11.4, -Math.PI / 2); chair(2.35, -12.6, -Math.PI / 2);
  chair(-2.35, -23.4, Math.PI / 2); chair(-2.35, -24.6, Math.PI / 2);
  chair(2.35, -35.4, -Math.PI / 2); chair(2.35, -36.6, -Math.PI / 2);
  chair(-0.75, -44.3, Math.PI); chair(0.75, -44.3, Math.PI);

  /* ---------- Vestibule : suspension ---------- */
  box('brass', 0.02, 0.9, 0.02, trs(0, VH - 0.45, T + D.VEST_D / 2));
  {
    const g = new THREE.SphereGeometry(0.2, 24, 16);
    b.add('lamp', g, trs(0, VH - 1.05, T + D.VEST_D / 2));
    g.dispose();
    sconces.push(new THREE.Vector3(0, VH - 1.05, T + D.VEST_D / 2));
  }
  // salle du fond : plafond lumineux
  box('trim', 3.3, 0.08, 3.3, trs(0, BH - 0.04, -L - T - D.BACK_D / 2));
  {
    const g = new THREE.PlaneGeometry(2.9, 2.9);
    b.add('sky', g, trs(0, BH - 0.085, -L - T - D.BACK_D / 2, Math.PI / 2, 0, 0), false);
    g.dispose();
  }

  /* ---------- Fusion ---------- */
  const meshes = b.build(mats, {
    floor: { cast: false },
    glass: { cast: false, receive: false, renderOrder: 2 },
    glow: { cast: false, receive: false, renderOrder: 3 },
    lamp: { cast: false },
    sky: { cast: false, receive: false },
    marble: { cast: false },
  });
  meshes.forEach((m) => group.add(m));

  // ciel au-dessus de la verrière
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(40, 70), mats.sky);
  sky.rotation.x = Math.PI / 2;
  sky.position.set(0, D.GLASS_Y + 3.5, -L / 2);
  group.add(sky);

  // halos des lampes (un seul appel de rendu)
  const glowGeo = new THREE.BufferGeometry().setFromPoints(sconces);
  const glowPts = new THREE.Points(glowGeo, new THREE.PointsMaterial({
    map: mats._glowTexture, size: 0.75, sizeAttenuation: true, transparent: true, opacity: 0.6,
    depthWrite: false, blending: THREE.AdditiveBlending, color: 0xffe2bb, fog: false,
  }));
  glowPts.renderOrder = 4;
  group.add(glowPts);

  // inscription du vestibule
  group.add(inscription(walls.vestBack, D.VEST_HW, 4.25, options.inscription || 'Galerie'));

  /* ---------- Collisions (boîtes alignées XZ) ---------- */
  const thick = (wall, u0, u1) => colliders.push(wallAABB(wall, u0, u1, -T - 0.1, 0.1));
  thick(walls.left, -T, L + T);
  thick(walls.right, -T, L + T);
  thick(walls.end, -T, W / 2 - D.ARCH_HW);
  thick(walls.end, W / 2 + D.ARCH_HW, W + T);
  thick(walls.entrance, -T, W / 2 - D.ENTRY_HW);
  thick(walls.entrance, W / 2 + D.ENTRY_HW, W + T);
  for (const k of ['vestL', 'vestR']) thick(walls[k], -T, D.VEST_D + T);
  thick(walls.vestBack, -T, 2 * D.VEST_HW + T);
  for (const k of ['backL', 'backR']) thick(walls[k], -T, D.BACK_D + T);
  thick(walls.back, -T, 2 * D.BACK_HW + T);

  return {
    group, colliders, walls,
    vestibuleLight: new THREE.Vector3(0, VH - 1.25, T + D.VEST_D / 2),
    backRoomCenter: new THREE.Vector3(0, BH - 0.1, -L - T - D.BACK_D / 2),
  };
}

function inscription(wall, u, y, label) {
  const c = textCanvas(2048, 200, (ctx, w, h) => {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#6e5435';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const text = String(label).toUpperCase();
    if ('letterSpacing' in ctx) ctx.letterSpacing = '16px';
    let size = 120;
    ctx.font = `500 ${size}px "Cormorant Garamond", Georgia, serif`;
    const tw = ctx.measureText(text).width;
    if (tw > w * 0.92) size = Math.floor(size * (w * 0.92) / tw);
    ctx.font = `500 ${size}px "Cormorant Garamond", Georgia, serif`;
    ctx.fillText(text, w / 2, h / 2 + 6);
  });
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(4.4, 0.43),
    new THREE.MeshStandardMaterial({ map: t, transparent: true, roughness: 0.45, metalness: 0.5 })
  );
  mesh.matrixAutoUpdate = false;
  mesh.matrix.copy(wallMatrix(wall, u, y, 0.006));
  return mesh;
}
