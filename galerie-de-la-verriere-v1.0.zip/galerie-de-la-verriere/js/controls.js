/**
 * Déplacement à la première personne :
 *  - clavier ZQSD / WASD (+ flèches), Maj pour accélérer
 *  - souris en verrouillage du pointeur, ou cliquer-glisser en mode de secours
 *  - tactile : joystick virtuel à gauche, regard à droite, toucher pour sélectionner
 *  - collisions cercle / boîtes alignées
 */
import * as THREE from 'three';
import { MUSEUM } from './config.js';

const KEYMAP = {
  z: 'fwd', w: 'fwd', arrowup: 'fwd',
  s: 'back', arrowdown: 'back',
  q: 'left', a: 'left',
  d: 'right',
  arrowleft: 'turnL', arrowright: 'turnR',
  shift: 'run',
};

export class Controller {
  constructor(camera, dom, colliders) {
    this.camera = camera;
    this.dom = dom;
    this.colliders = colliders;
    this.pos = new THREE.Vector2(0, -1.6); // x, z
    this.vel = new THREE.Vector2();
    this.yaw = 0;
    this.pitch = -0.03;
    this.radius = 0.32;
    this.eye = MUSEUM.eyeHeight;
    this.bobPhase = 0;
    this.bobAmount = 0;
    this.enabled = false;
    this.locked = false;
    this.dragMode = false;
    this.actions = new Set();
    this.codeAction = new Map();
    this.mouseNDC = new THREE.Vector2(0, 0);
    this.mouseInside = false;
    this.joy = new THREE.Vector2();
    this.onPick = null;
    this.onActivity = null;
    this._drag = null;
    this._touches = new Map();
    this._bind();
  }

  _bind() {
    const d = this.dom;
    window.addEventListener('keydown', (e) => {
      if (!this.enabled) return;
      const k = e.key.toLowerCase();
      const a = KEYMAP[k];
      if (!a) return;
      this.codeAction.set(e.code, a);
      this.actions.add(a);
      if (k.startsWith('arrow') || k === ' ') e.preventDefault();
      this.onActivity?.();
    });
    window.addEventListener('keyup', (e) => {
      const a = this.codeAction.get(e.code) || KEYMAP[e.key.toLowerCase()];
      if (a) this.actions.delete(a);
      this.codeAction.delete(e.code);
      if (e.key === 'Shift') this.actions.delete('run');
    });
    window.addEventListener('blur', () => this.clearInput());

    document.addEventListener('mousemove', (e) => {
      if (!this.enabled) return;
      if (this.locked) {
        this._look(e.movementX, e.movementY, MUSEUM.mouseSensitivity);
        this.onActivity?.();
      } else if (this.dragMode) {
        this.mouseNDC.set((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
        if (this._drag) {
          const dx = e.clientX - this._drag.x, dy = e.clientY - this._drag.y;
          this._drag.moved += Math.abs(dx) + Math.abs(dy);
          this._drag.x = e.clientX; this._drag.y = e.clientY;
          this._look(dx, dy, 0.0042);
          if (this._drag.moved > 4) document.body.classList.add('dragging');
        }
      }
    });
    d.addEventListener('mouseenter', () => (this.mouseInside = true));
    d.addEventListener('mouseleave', () => (this.mouseInside = false));
    d.addEventListener('mousedown', (e) => {
      if (!this.enabled || e.button !== 0) return;
      if (this.locked) { this.onPick?.(new THREE.Vector2(0, 0)); return; }
      if (this.dragMode) {
        this.mouseInside = true;
        this._drag = { x: e.clientX, y: e.clientY, moved: 0 };
      }
    });
    window.addEventListener('mouseup', (e) => {
      if (this._drag) {
        if (this._drag.moved < 6 && this.enabled) {
          this.onPick?.(new THREE.Vector2((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1));
        }
        this._drag = null;
        document.body.classList.remove('dragging');
      }
    });

    // tactile
    const joyEl = document.getElementById('joystick');
    const knob = document.getElementById('joystick-knob');
    d.addEventListener('touchstart', (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      for (const t of e.changedTouches) {
        const isJoy = t.clientX < innerWidth * 0.42 && ![...this._touches.values()].some((v) => v.joy);
        this._touches.set(t.identifier, { x: t.clientX, y: t.clientY, ox: t.clientX, oy: t.clientY, t0: performance.now(), joy: isJoy, moved: 0 });
        if (isJoy && joyEl) {
          joyEl.style.left = t.clientX + 'px';
          joyEl.style.top = t.clientY + 'px';
          joyEl.classList.add('is-active');
        }
      }
    }, { passive: false });
    d.addEventListener('touchmove', (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      for (const t of e.changedTouches) {
        const s = this._touches.get(t.identifier);
        if (!s) continue;
        const dx = t.clientX - s.x, dy = t.clientY - s.y;
        s.moved += Math.abs(dx) + Math.abs(dy);
        s.x = t.clientX; s.y = t.clientY;
        if (s.joy) {
          const jx = THREE.MathUtils.clamp((t.clientX - s.ox) / 50, -1, 1);
          const jy = THREE.MathUtils.clamp((t.clientY - s.oy) / 50, -1, 1);
          this.joy.set(jx, -jy);
          if (knob) knob.style.transform = `translate(${jx * 33}px, ${jy * 33}px)`;
        } else this._look(dx, dy, 0.005);
      }
    }, { passive: false });
    const end = (e) => {
      for (const t of e.changedTouches) {
        const s = this._touches.get(t.identifier);
        if (!s) continue;
        if (s.joy) {
          this.joy.set(0, 0);
          joyEl?.classList.remove('is-active');
          if (knob) knob.style.transform = '';
          if (s.moved < 10 && performance.now() - s.t0 < 300) this._tap(t);
        } else if (s.moved < 10 && performance.now() - s.t0 < 300) this._tap(t);
        this._touches.delete(t.identifier);
      }
    };
    d.addEventListener('touchend', end);
    d.addEventListener('touchcancel', end);
  }

  _tap(t) {
    this.onPick?.(new THREE.Vector2((t.clientX / innerWidth) * 2 - 1, -(t.clientY / innerHeight) * 2 + 1));
  }

  _look(dx, dy, sens) {
    this.yaw -= dx * sens;
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * sens, -1.35, 1.35);
  }

  clearInput() {
    this.actions.clear();
    this.codeAction.clear();
    this.joy.set(0, 0);
  }

  /** NDC du pointeur à utiliser pour le survol (centre si verrouillé). */
  pointer() {
    if (this.locked) return new THREE.Vector2(0, 0);
    if (this.dragMode && this.mouseInside && !this._drag) return this.mouseNDC;
    return null;
  }

  setPose(x, z, yaw, pitch = this.pitch) {
    this.pos.set(x, z);
    this.yaw = yaw;
    this.pitch = pitch;
    this.vel.set(0, 0);
    this.apply();
  }

  update(dt) {
    const A = this.actions;
    if (A.has('turnL')) this.yaw += 1.7 * dt;
    if (A.has('turnR')) this.yaw -= 1.7 * dt;
    let f = (A.has('fwd') ? 1 : 0) - (A.has('back') ? 1 : 0) + this.joy.y;
    let s = (A.has('right') ? 1 : 0) - (A.has('left') ? 1 : 0) + this.joy.x;
    const len = Math.hypot(f, s);
    if (len > 1) { f /= len; s /= len; }
    const speed = A.has('run') ? MUSEUM.runSpeed : MUSEUM.walkSpeed;
    const sy = Math.sin(this.yaw), cy = Math.cos(this.yaw);
    const tx = (-sy * f + cy * s) * speed;
    const tz = (-cy * f - sy * s) * speed;
    const k = 1 - Math.exp(-dt * (len > 0.01 ? 7 : 9));
    this.vel.x += (tx - this.vel.x) * k;
    this.vel.y += (tz - this.vel.y) * k;

    this.pos.x += this.vel.x * dt;
    this.pos.y += this.vel.y * dt;
    this._collide();

    const v = this.vel.length();
    this.bobAmount += (Math.min(v / MUSEUM.walkSpeed, 1.4) - this.bobAmount) * Math.min(1, dt * 6);
    this.bobPhase += dt * (5.2 + v * 1.4);
    this.apply();
  }

  apply() {
    const bob = Math.sin(this.bobPhase * 2) * 0.018 * this.bobAmount;
    this.camera.position.set(this.pos.x, this.eye + bob, this.pos.y);
    this.camera.rotation.set(this.pitch, this.yaw, Math.sin(this.bobPhase) * 0.0025 * this.bobAmount, 'YXZ');
  }

  _collide() {
    const r = this.radius, p = this.pos;
    for (let it = 0; it < 3; it++) {
      for (const b of this.colliders) {
        const cx = Math.max(b.minX, Math.min(p.x, b.maxX));
        const cz = Math.max(b.minZ, Math.min(p.y, b.maxZ));
        const dx = p.x - cx, dz = p.y - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 >= r * r) continue;
        if (d2 > 1e-10) {
          const d = Math.sqrt(d2), push = (r - d) / d;
          p.x += dx * push; p.y += dz * push;
        } else {
          // centre à l'intérieur : sortie par le plus petit côté
          const opts = [
            [b.minX - r - p.x, 0], [b.maxX + r - p.x, 0],
            [0, b.minZ - r - p.y], [0, b.maxZ + r - p.y],
          ].sort((a, c) => Math.abs(a[0] + a[1]) - Math.abs(c[0] + c[1]));
          p.x += opts[0][0]; p.y += opts[0][1];
        }
      }
    }
  }
}
