/**
 * Brouillon local de l'interface d'administration (IndexedDB du navigateur).
 * Contient le contenu modifié + les fichiers ajoutés (images, PDF) pas encore publiés.
 * Le site public le lit uniquement en mode aperçu (index.html?apercu).
 */
const DB = 'galerie-admin', STORE = 'kv', KEY = 'draft';

function open() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB indisponible'));
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx(mode, fn) {
  return open().then((db) => new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const req = fn(t.objectStore(STORE));
    t.oncomplete = () => { resolve(req && req.result); db.close(); };
    t.onerror = () => { reject(t.error); db.close(); };
  }));
}

/** @returns {Promise<{content:object, files:Object<string,Blob>, savedAt:number}|undefined>} */
export const loadDraft = () => tx('readonly', (s) => s.get(KEY));
export const saveDraft = (draft) => tx('readwrite', (s) => s.put({ ...draft, savedAt: Date.now() }, KEY));
export const clearDraft = () => tx('readwrite', (s) => s.delete(KEY));
