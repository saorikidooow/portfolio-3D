/**
 * Réglages généraux du musée.
 *
 * Textures : toutes les surfaces sont générées par le code. Pour utiliser vos
 * propres photos de matériaux, déposez-les dans assets/textures/ et indiquez le
 * chemin ci-dessous (ex. 'assets/textures/parquet.jpg'). La taille en mètres
 * indique la surface couverte par une répétition de l'image.
 */
export const TEXTURE_OVERRIDES = {
  floor: { src: null, size: 4 },      // parquet
  plaster: { src: null, size: 2 },    // murs blancs
  darkWood: { src: null, size: 1 },   // soubassements, portes
};

/** Réglages de déplacement (les textes, couleurs et œuvres sont dans content/site.json). */
export const MUSEUM = {
  eyeHeight: 1.65,     // hauteur des yeux du visiteur (m)
  walkSpeed: 2.3,      // m/s
  runSpeed: 4.2,       // m/s (touche Maj)
  mouseSensitivity: 0.0021,
};
