/**
 * Modèle de contenu du site (sans Three.js).
 *
 * Source unique de vérité : content/site.json
 *  - chargé par le site public (main.js)
 *  - édité par l'interface d'administration (admin/)
 *
 * normalizeContent() complète toujours les champs manquants avec les valeurs
 * par défaut : un site.json incomplet ou ancien ne casse jamais le site.
 */
import { loadDraft } from './store.js';

export const CONTENT_URL = 'content/site.json';

export const STYLES = {
  landscape: 'Paysage', seascape: 'Marine', mountains: 'Montagne', night: 'Nocturne',
  portrait: 'Portrait', stilllife: 'Nature morte', abstract: 'Abstrait',
};
export const VISUALS = { image: 'Image (photo de l\'œuvre)', generated: 'Peinture générée', poster: 'Affiche (titre en grand)' };
export const FRAMES = { gilt: 'Doré', wood: 'Bois sombre', black: 'Noir' };
export const LABELS = { right: 'À droite', below: 'En dessous', none: 'Aucun' };
export const CLICK_ACTIONS = {
  details: 'Afficher la fiche de l\'œuvre',
  link: 'Ouvrir directement le lien',
  document: 'Ouvrir directement le document',
};

export const THEME_PRESETS = {
  claire: {
    label: 'Galerie claire (d\'origine)',
    walls: '#f0ece4', trim: '#f4f1eb', wood: '#462c1b', floor: '#ffffff', gilt: '#c49b56',
    accent: '#a5844f', ink: '#2a241d', background: '#f4f0e8', exposure: 1, sunlight: 1,
  },
  nuit: {
    label: 'Bleu nuit et or',
    walls: '#2b3756', trim: '#efe6d2', wood: '#2a2422', floor: '#d9d4cf', gilt: '#d4ac5e',
    accent: '#b8914a', ink: '#1d2438', background: '#eef0f4', exposure: 1.12, sunlight: 0.9,
  },
  sauge: {
    label: 'Vert sauge',
    walls: '#b9c2ae', trim: '#f1efe6', wood: '#3b2c1f', floor: '#f2ede4', gilt: '#c2a065',
    accent: '#7a8a5c', ink: '#262a20', background: '#f1f2ec', exposure: 1.04, sunlight: 1,
  },
  terracotta: {
    label: 'Rouge pompéien',
    walls: '#9c4a3c', trim: '#f2e9dc', wood: '#2f1d14', floor: '#f3e6d8', gilt: '#d2a85a',
    accent: '#9c4a3c', ink: '#2b1d18', background: '#f6efe7', exposure: 1.1, sunlight: 0.95,
  },
};

export const DEFAULT_SITE = {
  name: 'Galerie de la Verrière',
  tagline: 'Portfolio artistique',
  eyebrow: 'Portfolio artistique · Visite immersive',
  welcomeText: 'Bienvenue dans la galerie.',
  enterLabel: 'Entrer dans le musée',
  pauseTitle: 'Visite en pause',
  resumeLabel: 'Reprendre la visite',
  backLabel: 'Retour à la visite',
  hoverHint: "Cliquer pour découvrir l'œuvre",
  linkLabel: 'Ouvrir le lien',
  documentLabel: 'Consulter le document',
  inscription: '',
  metaDescription: '',
};

export function defaultArtwork(overrides = {}) {
  return {
    id: 'oeuvre-' + Math.random().toString(36).slice(2, 8),
    title: 'Nouvelle œuvre', artist: '', year: '', technique: '', dimensions: '', description: '',
    visual: 'generated', image: '', style: 'landscape', seed: Math.floor(Math.random() * 9000) + 1000,
    link: { url: '', label: '' }, document: { url: '', label: '' }, clickAction: 'details',
    wall: 'left', u: 6, y: 2.7, width: 1.6, height: 1.2, frame: 'gilt', label: 'right',
    ...overrides,
  };
}

const num = (v, d) => (Number.isFinite(+v) && v !== '' && v !== null ? +v : d);
const str = (v, d = '') => (typeof v === 'string' ? v : v == null ? d : String(v));
const color = (v, d) => (/^#[0-9a-f]{6}$/i.test(v || '') ? v : d);

export function normalizeArtwork(a = {}, i = 0) {
  const d = defaultArtwork({ id: 'oeuvre-' + (i + 1) });
  const visual = VISUALS[a.visual] ? a.visual : a.image ? 'image' : 'generated';
  let label = a.label;
  if (label === false || label === 'none') label = 'none';
  else if (!LABELS[label]) label = 'right';
  return {
    id: str(a.id, d.id) || d.id,
    title: str(a.title, ''), artist: str(a.artist), year: str(a.year), technique: str(a.technique),
    dimensions: str(a.dimensions), description: str(a.description),
    visual, image: str(a.image),
    style: STYLES[a.style] ? a.style : 'landscape', seed: Math.round(num(a.seed, i * 10 + 1)),
    link: { url: str(a.link?.url), label: str(a.link?.label) },
    document: { url: str(a.document?.url), label: str(a.document?.label) },
    clickAction: CLICK_ACTIONS[a.clickAction] ? a.clickAction : 'details',
    wall: ['left', 'right', 'end', 'back', 'entrance'].includes(a.wall) ? a.wall : 'left',
    u: num(a.u, 6), y: num(a.y, 2.7),
    width: Math.max(0.2, num(a.width, 1.2)), height: Math.max(0.2, num(a.height, 1)),
    frame: FRAMES[a.frame] ? a.frame : 'gilt',
    label,
  };
}

export function normalizeContent(raw = {}) {
  const site = { ...DEFAULT_SITE };
  for (const k of Object.keys(DEFAULT_SITE)) if (raw.site && typeof raw.site[k] === 'string') site[k] = raw.site[k];
  const base = THEME_PRESETS.claire;
  const t = raw.theme || {};
  const theme = {
    preset: str(t.preset, 'claire'),
    walls: color(t.walls, base.walls), trim: color(t.trim, base.trim), wood: color(t.wood, base.wood),
    floor: color(t.floor, base.floor), gilt: color(t.gilt, base.gilt),
    accent: color(t.accent, base.accent), ink: color(t.ink, base.ink), background: color(t.background, base.background),
    exposure: Math.min(2, Math.max(0.4, num(t.exposure, 1))),
    sunlight: Math.min(3, Math.max(0, num(t.sunlight, 1))),
  };
  const links = Array.isArray(raw.links)
    ? raw.links.map((l) => ({ label: str(l?.label), url: str(l?.url) })).filter((l) => l.url || l.label)
    : [];
  const artworks = Array.isArray(raw.artworks) ? raw.artworks.map(normalizeArtwork) : [];
  return { $schema: './site.schema.json', version: 1, site, links, theme, artworks };
}

/** Forme « propre » pour l'enregistrement (supprime les champs internes « _xxx »). */
export function serializeContent(content) {
  return JSON.stringify(content, (k, v) => (k.startsWith('_') ? undefined : v), 2) + '\n';
}

/**
 * Charge le contenu publié, ou le brouillon de l'admin si ?apercu est présent dans l'URL.
 * @returns {{content, files, preview:boolean}}
 */
export async function loadContent({ base = '', preview = false } = {}) {
  if (preview) {
    try {
      const draft = await loadDraft();
      if (draft && draft.content) return { content: normalizeContent(draft.content), files: draft.files || {}, preview: true };
    } catch (e) { console.warn('Brouillon illisible', e); }
  }
  const res = await fetch(base + CONTENT_URL + '?t=' + Date.now(), { cache: 'no-store' });
  if (!res.ok) throw new Error(`Impossible de lire ${CONTENT_URL} (${res.status})`);
  return { content: normalizeContent(await res.json()), files: {}, preview: false };
}

const objectURLs = new Map();
/** Transforme un chemin du contenu en URL utilisable (fichiers du brouillon inclus). */
export function resolveAsset(path, files = {}, base = '') {
  if (!path) return '';
  if (files[path]) {
    if (!objectURLs.has(path)) objectURLs.set(path, URL.createObjectURL(files[path]));
    return objectURLs.get(path);
  }
  if (/^(https?:|data:|blob:|mailto:|tel:)/i.test(path)) return path;
  return base + path.replace(/^\.?\//, '');
}

export function isSafeUrl(url) {
  return /^(https?:|mailto:|tel:)/i.test(url) || (!/^[a-z]+:/i.test(url) && url !== '');
}
