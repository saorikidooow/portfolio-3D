/**
 * Atelier — interface d'administration de la galerie.
 *
 * Fonctionnement :
 *  1. Charge content/site.json (ou le brouillon local s'il existe).
 *  2. Chaque modification est enregistrée automatiquement en brouillon
 *     (IndexedDB du navigateur), avec les images / PDF ajoutés.
 *  3. « Aperçu » ouvre la galerie 3D avec le brouillon (index.html?apercu).
 *  4. « Publier » envoie site.json + nouveaux fichiers sur GitHub en un commit
 *     (ou « Exporter » produit un ZIP à déposer soi-même).
 */
import {
  normalizeContent, serializeContent, defaultArtwork, resolveAsset, CONTENT_URL,
  STYLES, VISUALS, FRAMES, LABELS, CLICK_ACTIONS, THEME_PRESETS, DEFAULT_SITE,
} from '../js/content.js';
import { WALLS, HANG_MIN_Y, DIM } from '../js/layout.js';
import { paintArtwork } from '../js/painter.js';
import { loadDraft, saveDraft, clearDraft } from '../js/store.js';
import { GitHubRepo, guessRepoFromLocation } from '../js/github.js';

const BASE = '../';
const $ = (s, root = document) => root.querySelector(s);

/* ---------- état ---------- */
const S = {
  content: null,      // contenu en cours d'édition (normalisé)
  files: {},          // { 'assets/artworks/x.jpg': Blob } — fichiers pas encore publiés
  baseText: '',       // site.json publié au moment où le brouillon a commencé
  dirty: false,
  tab: 'artworks',
  filter: 'all',
  search: '',
  editing: null,      // index de l'œuvre ouverte
};

/* ---------- utilitaires DOM ---------- */
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'html') el.innerHTML = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const c of children.flat()) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(c));
  return el;
}
function toast(msg, ms = 2600) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), ms);
}
const slug = (s) => (s || 'fichier').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
  .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'fichier';
const parseNum = (v) => parseFloat(String(v).replace(',', '.'));
const round = (v, s = 0.05) => +(Math.round(v / s) * s).toFixed(2);

/** Champ texte / zone de texte lié à obj[key]. */
function textField(label, obj, key, { textarea = false, help = '', type = 'text', placeholder = '', onChange } = {}) {
  const input = textarea
    ? h('textarea', { placeholder })
    : h('input', { type, placeholder, autocomplete: 'off' });
  input.value = obj[key] ?? '';
  input.addEventListener('input', () => { obj[key] = input.value; changed(); onChange?.(); });
  return h('label', { class: 'field' }, h('span', {}, label), input, help && h('small', {}, help));
}
function numField(label, obj, key, { step = 0.05, min, max, help, onChange } = {}) {
  const input = h('input', { type: 'number', inputmode: 'decimal', step, min, max });
  input.value = obj[key];
  input.addEventListener('input', () => {
    const v = parseNum(input.value);
    if (Number.isFinite(v)) { obj[key] = v; changed(); onChange?.(); }
  });
  input._sync = () => { if (document.activeElement !== input) input.value = +(+obj[key]).toFixed(2); };
  return h('label', { class: 'field' }, h('span', {}, label), input, help && h('small', {}, help));
}
function selectField(label, obj, key, options, { help, onChange } = {}) {
  const sel = h('select', {}, Object.entries(options).map(([v, l]) => h('option', { value: v }, l)));
  sel.value = obj[key];
  sel.addEventListener('change', () => { obj[key] = sel.value; changed(); onChange?.(); });
  return h('label', { class: 'field' }, h('span', {}, label), sel, help && h('small', {}, help));
}

/* ---------- enregistrement du brouillon ---------- */
let saveTimer = null;
function changed() {
  S.dirty = true;
  updateStatus();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persist, 400);
}
async function persist() {
  try {
    await saveDraft({ content: JSON.parse(serializeContent(S.content)), files: S.files, baseText: S.baseText });
  } catch (e) { console.error(e); toast("Impossible d'enregistrer le brouillon sur cet appareil."); }
}
function updateStatus(state) {
  const el = $('#status');
  const st = state || (S.dirty ? 'dirty' : 'clean');
  el.dataset.state = st;
  el.textContent = st === 'busy' ? 'Publication…' : st === 'dirty' ? 'Modifications non publiées' : 'À jour';
  $('#btn-publish-top').textContent = S.dirty ? 'Publier ●' : 'Publier';
  $('#site-name').textContent = S.content?.site.name || 'Galerie';
}

/* ---------- configuration GitHub (stockée sur cet appareil) ---------- */
const GH_KEY = 'galerie-admin-github';
function ghSettings() {
  let s = {};
  try { s = JSON.parse(localStorage.getItem(GH_KEY) || '{}'); } catch { /* vide */ }
  const guess = guessRepoFromLocation() || {};
  let token = '';
  try { token = sessionStorage.getItem(GH_KEY + ':token') || localStorage.getItem(GH_KEY + ':token') || ''; } catch { /* vide */ }
  return { owner: s.owner || guess.owner || '', repo: s.repo || guess.repo || '', branch: s.branch || 'main', remember: !!s.remember, apiBase: s.apiBase, token };
}
function saveGhSettings(s) {
  try {
    localStorage.setItem(GH_KEY, JSON.stringify({ owner: s.owner, repo: s.repo, branch: s.branch, remember: s.remember, apiBase: s.apiBase }));
    localStorage.removeItem(GH_KEY + ':token');
    sessionStorage.removeItem(GH_KEY + ':token');
    if (s.token) (s.remember ? localStorage : sessionStorage).setItem(GH_KEY + ':token', s.token);
  } catch { /* stockage indisponible */ }
}
function ghRepo() {
  const s = ghSettings();
  if (!s.owner || !s.repo || !s.token) return null;
  return new GitHubRepo({ owner: s.owner, repo: s.repo, branch: s.branch, token: s.token, ...(s.apiBase ? { apiBase: s.apiBase } : {}) });
}

/* ---------- chargement ---------- */
async function fetchPublished() {
  const repo = ghRepo();
  if (repo) {
    try { return await repo.readText(CONTENT_URL); } catch (e) { console.warn('Lecture GitHub impossible, version du site utilisée', e); }
  }
  const res = await fetch(BASE + CONTENT_URL + '?t=' + Date.now(), { cache: 'no-store' });
  if (!res.ok) throw new Error('content/site.json introuvable');
  return res.text();
}

async function init() {
  let draft = null;
  try { draft = await loadDraft(); } catch { /* pas de brouillon */ }
  if (draft?.content) {
    S.content = normalizeContent(draft.content);
    S.files = draft.files || {};
    S.baseText = draft.baseText || '';
    S.dirty = true;
    showDraftBanner(draft.savedAt);
  } else {
    const text = await fetchPublished();
    S.baseText = text;
    S.content = normalizeContent(JSON.parse(text));
  }
  updateStatus();
  bindChrome();
  render();
}

function showDraftBanner(savedAt) {
  const b = $('#draft-banner');
  const when = savedAt ? new Date(savedAt).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : '';
  b.replaceChildren(
    h('span', {}, `Brouillon en cours${when ? ' (enregistré le ' + when + ')' : ''} : vos modifications ne sont pas encore en ligne.`),
    h('button', { class: 'btn small', type: 'button', onclick: () => switchTab('publish') }, 'Publier'),
  );
  b.hidden = false;
}

function bindChrome() {
  document.querySelectorAll('#tabs button').forEach((b) => b.addEventListener('click', () => switchTab(b.dataset.tab)));
  $('#btn-preview').addEventListener('click', openPreview);
  $('#btn-publish-top').addEventListener('click', () => switchTab('publish'));
  document.querySelectorAll('[data-close-sheet]').forEach((b) => b.addEventListener('click', closeEditor));
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#sheet').hidden) closeEditor(); });
  window.addEventListener('beforeunload', () => { clearTimeout(saveTimer); persist(); });
}

async function openPreview() {
  const win = window.open('', '_blank');
  clearTimeout(saveTimer);
  await persist();
  if (win) win.location = BASE + 'index.html?apercu';
  else location.href = BASE + 'index.html?apercu';
}

function switchTab(tab) {
  S.tab = tab;
  document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('is-active', b.dataset.tab === tab));
  render();
  window.scrollTo({ top: 0 });
}

function render() {
  const main = $('#main');
  const view = { artworks: viewArtworks, texts: viewTexts, colors: viewColors, links: viewLinks, publish: viewPublish, help: viewHelp }[S.tab];
  main.replaceChildren(...[].concat(view()));
}

/* ---------- vignettes ---------- */
const thumbCache = new Map();
function thumbURL(art) {
  if (art.visual === 'image' && art.image) return resolveAsset(art.image, S.files, BASE);
  const theme = S.content.theme;
  const key = [art.visual, art.style, art.seed, art.width, art.height, art.title, art.artist, art.year, art.link.url, art.document.url, theme.background, theme.ink, theme.accent].join('|');
  if (!thumbCache.has(key)) {
    const c = paintArtwork({ ...art, _poster: { paper: theme.background, ink: theme.ink, accent: theme.accent } }, 260);
    thumbCache.set(key, c.toDataURL('image/jpeg', 0.82));
  }
  return thumbCache.get(key);
}
function thumb(art) {
  const img = h('img', { alt: '', loading: 'lazy' });
  img.src = thumbURL(art);
  img.onerror = () => { img.replaceWith(h('span', { class: 'badge warn' }, 'Image introuvable')); };
  return h('div', { class: 'art-thumb' }, img);
}

/* ---------- vérification de l'emplacement ---------- */
function frameBox(a) {
  const m = 0.12; // cadre + marge
  return { u0: a.u - a.width / 2 - m, u1: a.u + a.width / 2 + m, y0: a.y - a.height / 2 - m, y1: a.y + a.height / 2 + m };
}
const overlap = (a, b) => a.u0 < b.u1 && a.u1 > b.u0 && a.y0 < b.y1 && a.y1 > b.y0;
function placementWarnings(art) {
  const w = WALLS[art.wall];
  const box = frameBox(art);
  const out = [];
  if (box.u0 < 0.05 || box.u1 > w.length - 0.05) out.push("L'œuvre dépasse du mur sur le côté : ajustez la position u ou la largeur.");
  if (box.y0 < HANG_MIN_Y - 0.05) out.push('Le bas du cadre touche le soubassement en bois : remontez l\'œuvre (y) ou réduisez sa hauteur.');
  if (box.y1 > w.top + 0.12) out.push("Le haut du cadre dépasse la zone d'accrochage : descendez l'œuvre ou réduisez sa hauteur.");
  for (const b of w.blocks) if (overlap(box, b)) { out.push(`L'œuvre chevauche un élément d'architecture (${b.kind}).`); break; }
  S.content.artworks.forEach((o) => {
    if (o !== art && o.wall === art.wall && overlap(frameBox(o), { ...box, u0: box.u0 + 0.08, u1: box.u1 - 0.08, y0: box.y0 + 0.08, y1: box.y1 - 0.08 })) {
      out.push(`Chevauche « ${o.title || 'sans titre'} ».`);
    }
  });
  return out;
}

/* ================= Onglet Œuvres ================= */
function viewArtworks() {
  const arts = S.content.artworks;
  const filterSel = h('select', { 'aria-label': 'Filtrer par mur' },
    h('option', { value: 'all' }, `Tous les murs (${arts.length})`),
    Object.entries(WALLS).map(([k, w]) => h('option', { value: k }, `${w.label} (${arts.filter((a) => a.wall === k).length})`)));
  filterSel.value = S.filter;
  filterSel.addEventListener('change', () => { S.filter = filterSel.value; render(); });
  const search = h('input', { type: 'search', placeholder: 'Rechercher un titre, un artiste…', 'aria-label': 'Rechercher' });
  search.value = S.search;
  search.addEventListener('input', () => { S.search = search.value; renderGrid(); });

  const grid = h('div', { class: 'art-grid' });
  function renderGrid() {
    const q = S.search.trim().toLowerCase();
    const cards = arts.map((a, i) => ({ a, i }))
      .filter(({ a }) => (S.filter === 'all' || a.wall === S.filter) && (!q || (a.title + ' ' + a.artist).toLowerCase().includes(q)))
      .map(({ a, i }) => {
        const warn = placementWarnings(a).length;
        return h('button', { type: 'button', class: 'art-card', onclick: () => openEditor(i) },
          thumb(a),
          h('div', { class: 'art-meta' },
            h('strong', {}, a.title || 'Sans titre'),
            h('span', {}, [a.artist, a.year].filter(Boolean).join(' · ') || '—'),
            h('div', { class: 'badges' },
              h('span', { class: 'badge' }, WALLS[a.wall].label.replace(/ \(.*\)/, '')),
              a.link.url && h('span', { class: 'badge' }, 'Lien'),
              a.document.url && h('span', { class: 'badge' }, 'Document'),
              warn > 0 ? h('span', { class: 'badge warn' }, 'À vérifier') : null)));
      });
    grid.replaceChildren(h('button', { type: 'button', class: 'art-card add-card', onclick: addArtwork }, '+ Ajouter une œuvre'), ...cards);
  }
  renderGrid();
  return [
    h('h1', { class: 'section' }, 'Œuvres'),
    h('p', { class: 'lead' }, "Touchez une œuvre pour modifier son image, ses textes, un lien, un document ou sa place sur les murs."),
    h('div', { class: 'toolbar' }, filterSel, search),
    grid,
  ];
}

function addArtwork() {
  const wall = S.filter !== 'all' ? S.filter : 'left';
  const art = defaultArtwork({ wall });
  // cherche une place libre sur le mur
  const w = WALLS[wall];
  for (let u = 1; u < w.length; u += 0.5) {
    Object.assign(art, { u, y: 2.6 });
    if (!placementWarnings(art).length) break;
  }
  S.content.artworks.push(art);
  changed();
  render();
  openEditor(S.content.artworks.length - 1);
}

/* ---------- éditeur d'une œuvre ---------- */
function openEditor(index) {
  S.editing = index;
  const art = S.content.artworks[index];
  const body = $('#sheet-body');
  $('#sheet-title').textContent = art.title || 'Œuvre';
  const refreshThumb = () => {
    previewSlot.replaceChildren(thumb(art));
    $('#sheet-title').textContent = art.title || 'Œuvre';
  };

  // 1. Informations
  const info = h('div', { class: 'card' },
    h('h3', {}, 'Informations'),
    textField('Titre', art, 'title', { onChange: refreshThumb }),
    h('div', { class: 'grid2' },
      textField('Artiste', art, 'artist', { onChange: refreshThumb }),
      textField('Année', art, 'year', { onChange: refreshThumb })),
    h('div', { class: 'grid2' },
      textField('Technique', art, 'technique', { placeholder: 'Huile sur toile' }),
      textField('Dimensions', art, 'dimensions', { placeholder: 'Calculées automatiquement si vide' })),
    textField('Description', art, 'description', { textarea: true, help: 'Affichée dans la fiche quand on clique sur l\'œuvre.' }));

  // 2. Visuel
  const previewSlot = h('div', {});
  const visualOpts = h('div', {});
  const seg = h('div', { class: 'seg', role: 'radiogroup' }, Object.entries(VISUALS).map(([v, l]) => {
    const input = h('input', { type: 'radio', name: 'visual', value: v });
    input.checked = art.visual === v;
    input.addEventListener('change', () => { art.visual = v; changed(); renderVisualOpts(); refreshThumb(); });
    return h('label', {}, input, l.replace(/ \(.*\)/, ''));
  }));
  function renderVisualOpts() {
    if (art.visual === 'image') {
      const file = h('input', { type: 'file', accept: 'image/*' });
      file.addEventListener('change', async () => {
        const f = file.files[0];
        if (!f) return;
        toast('Préparation de l\'image…');
        try {
          const { blob, width, height } = await prepareImage(f);
          const path = `assets/artworks/${slug(art.title || art.id)}-${Date.now().toString(36)}.jpg`;
          S.files[path] = blob;
          art.image = path;
          // adapte la hauteur du cadre aux proportions de l'image
          art.height = round(art.width * (height / width), 0.01);
          changed(); renderVisualOpts(); refreshThumb(); syncPlacement();
          toast('Image ajoutée. Les proportions du cadre ont été ajustées.');
        } catch (e) { console.error(e); toast("Cette image n'a pas pu être lue."); }
      });
      visualOpts.replaceChildren(
        h('div', { class: 'row' }, h('span', { class: 'btn file-btn' }, '📷 Choisir une image…', file)),
        h('small', { class: 'help' }, 'Depuis la galerie photo ou l\'appareil photo. L\'image est automatiquement optimisée (2000 px max).'),
        textField('… ou adresse de l\'image', art, 'image', { help: 'Chemin dans le projet (assets/artworks/…) ou adresse https://. Les images hébergées ailleurs peuvent être bloquées par leur site : préférez l\'ajout de fichier.', onChange: refreshThumb }),
        h('button', { type: 'button', class: 'btn small', onclick: fitToImage }, 'Ajuster le cadre aux proportions de l\'image'));
    } else if (art.visual === 'generated') {
      visualOpts.replaceChildren(
        h('div', { class: 'grid2' },
          selectField('Genre de peinture', art, 'style', STYLES, { onChange: refreshThumb }),
          numField('Variante (nombre)', art, 'seed', { step: 1, onChange: refreshThumb })),
        h('button', { type: 'button', class: 'btn small', onclick: () => { art.seed = Math.floor(Math.random() * 9000) + 1; changed(); renderVisualOpts(); refreshThumb(); } }, '🎲 Autre variante'));
    } else {
      visualOpts.replaceChildren(h('p', { class: 'help' }, "Le titre, l'artiste et l'année sont affichés en grand, aux couleurs du thème. Idéal pour présenter un document, un lien, un texte ou un projet sans image."));
    }
  }
  async function fitToImage() {
    try {
      const img = new Image();
      img.src = resolveAsset(art.image, S.files, BASE);
      await img.decode();
      art.height = round(art.width * (img.naturalHeight / img.naturalWidth), 0.01);
      changed(); syncPlacement(); toast('Cadre ajusté.');
    } catch { toast("Impossible de lire l'image."); }
  }
  renderVisualOpts();
  previewSlot.append(thumb(art));
  const visual = h('div', { class: 'card' }, h('h3', {}, 'Visuel'),
    h('div', { class: 'preview-box' }, previewSlot, h('p', { class: 'help' }, 'Aperçu de ce qui sera accroché au mur.')),
    seg, visualOpts);

  // 3. Lien & document
  const docFile = h('input', { type: 'file', accept: '.pdf,application/pdf,.doc,.docx,.ppt,.pptx,.txt' });
  const docUrlField = textField('Adresse du document', art.document, 'url', { help: 'Chemin dans le projet (assets/documents/…) ou adresse https://.' });
  docFile.addEventListener('change', () => {
    const f = docFile.files[0];
    if (!f) return;
    if (f.size > 25 * 1024 * 1024) { toast('Fichier trop lourd (25 Mo maximum).'); return; }
    const ext = (f.name.split('.').pop() || 'pdf').toLowerCase();
    const path = `assets/documents/${slug(f.name.replace(/\.[^.]+$/, ''))}-${Date.now().toString(36)}.${ext}`;
    S.files[path] = f;
    art.document.url = path;
    if (!art.document.label) art.document.label = '';
    docUrlField.querySelector('input').value = path;
    changed(); refreshThumb();
    toast('Document ajouté.');
  });
  const links = h('div', { class: 'card' }, h('h3', {}, 'Lien et document (facultatifs)'),
    h('p', { class: 'help' }, "Ajoutez un lien (site, vidéo, boutique…) et/ou un document (PDF…). Des boutons apparaîtront dans la fiche de l'œuvre."),
    h('div', { class: 'grid2' },
      textField('Adresse du lien', art.link, 'url', { type: 'url', placeholder: 'https://…', onChange: refreshThumb }),
      textField('Texte du bouton', art.link, 'label', { placeholder: 'Ouvrir le lien' })),
    h('div', { class: 'row' }, h('span', { class: 'btn file-btn' }, '📄 Ajouter un document…', docFile)),
    docUrlField,
    textField('Texte du bouton du document', art.document, 'label', { placeholder: 'Consulter le document' }),
    selectField('Quand on clique sur l\'œuvre dans la galerie', art, 'clickAction', CLICK_ACTIONS,
      { help: 'Pour « remplacer » un tableau par un lien ou un document, choisissez l\'ouverture directe (et éventuellement le visuel « Affiche »).' }));

  // 4. Emplacement
  const warnList = h('ul', { class: 'warnings' });
  const mapSlot = h('div', {});
  const nums = [
    numField('Position u (m)', art, 'u', { onChange: () => syncPlacement('u') }),
    numField('Hauteur du centre y (m)', art, 'y', { onChange: () => syncPlacement('y') }),
    numField('Largeur (m)', art, 'width', { min: 0.2, onChange: () => syncPlacement('w') }),
    numField('Hauteur (m)', art, 'height', { min: 0.2, onChange: () => syncPlacement('h') }),
  ];
  const wallHint = h('small', { class: 'map-help' });
  function syncPlacement() {
    nums.forEach((f) => f.querySelector('input')._sync());
    mapSlot.replaceChildren(wallMap(art, (i) => { closeEditor(); openEditor(i); },
      () => { nums.forEach((f) => f.querySelector('input')._sync()); updateWarnings(); },
      () => syncPlacement()));
    wallHint.textContent = WALLS[art.wall].hint + ". Faites glisser l'œuvre sur le plan pour la déplacer.";
    updateWarnings();
  }
  function updateWarnings() {
    const w = placementWarnings(art);
    warnList.replaceChildren(...w.map((t) => h('li', {}, '⚠ ' + t)));
    mapSlot.querySelector('.current')?.classList.toggle('bad', w.length > 0);
  }
  const place = h('div', { class: 'card' }, h('h3', {}, 'Emplacement dans la galerie'),
    selectField('Mur', art, 'wall', Object.fromEntries(Object.entries(WALLS).map(([k, w]) => [k, w.label])), { onChange: () => {
      const w = WALLS[art.wall];
      art.u = Math.min(Math.max(art.u, art.width / 2 + 0.2), w.length - art.width / 2 - 0.2);
      syncPlacement();
    } }),
    mapSlot, wallHint, warnList,
    h('div', { class: 'grid4' }, nums),
    h('div', { class: 'grid2' },
      selectField('Cadre', art, 'frame', FRAMES),
      selectField('Cartel (petite étiquette)', art, 'label', LABELS)));

  // 5. Actions
  const actions = h('div', { class: 'card' }, h('div', { class: 'row' },
    h('button', { type: 'button', class: 'btn', onclick: () => {
      const copy = JSON.parse(JSON.stringify(art));
      copy.id = art.id + '-copie-' + Date.now().toString(36).slice(-3);
      copy.title = art.title + ' (copie)';
      copy.u = Math.min(art.u + art.width + 0.4, WALLS[art.wall].length - art.width / 2 - 0.1);
      S.content.artworks.splice(index + 1, 0, copy);
      changed(); render(); openEditor(index + 1); toast('Œuvre dupliquée.');
    } }, 'Dupliquer'),
    h('button', { type: 'button', class: 'btn danger', onclick: () => {
      if (!confirm(`Retirer « ${art.title || 'cette œuvre'} » de la galerie ?`)) return;
      S.content.artworks.splice(index, 1);
      changed(); closeEditor(); render(); toast('Œuvre retirée.');
    } }, 'Retirer de la galerie'),
    h('button', { type: 'button', class: 'btn primary', onclick: closeEditor, style: 'margin-left:auto' }, 'Terminé')));

  body.replaceChildren(info, visual, links, place, actions);
  syncPlacement();
  $('#sheet').hidden = false;
  document.body.style.overflow = 'hidden';
  body.scrollTop = 0;
}

function closeEditor() {
  $('#sheet').hidden = true;
  document.body.style.overflow = '';
  S.editing = null;
  if (S.tab === 'artworks') render();
}

/** Plan SVG du mur, avec déplacement de l'œuvre au doigt ou à la souris. */
function wallMap(art, onSelectOther, onMove, onEnd) {
  const w = WALLS[art.wall];
  const H = art.wall === 'back' ? DIM.BACK_H : DIM.CORNICE_Y + 0.4;
  const pad = 0.3;
  const X = (u) => (w.mirror ? w.length - u : u);
  const Y = (y) => H - y;
  const NS = 'http://www.w3.org/2000/svg';
  const el = (tag, attrs, text) => {
    const n = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    if (text) n.textContent = text;
    return n;
  };
  // fenêtre de 14 m maximum centrée sur l'œuvre (lisible sur téléphone)
  const win = Math.min(w.length, 14);
  const v0 = Math.min(Math.max(art.u - win / 2, 0), w.length - win);
  const vx = w.mirror ? w.length - v0 - win : v0;
  const svg = el('svg', { class: 'wallmap', viewBox: `${vx - pad} ${-pad} ${win + 2 * pad} ${H + 2 * pad}`, role: 'img', 'aria-label': 'Plan du mur' });
  svg.append(el('rect', { class: 'wall', x: 0, y: 0, width: w.length, height: H }));
  svg.append(el('rect', { class: 'wain', x: 0, y: Y(DIM.WAIN_H), width: w.length, height: DIM.WAIN_H }));
  svg.append(el('line', { class: 'limit', x1: 0, x2: w.length, y1: Y(w.top), y2: Y(w.top) }));
  for (const b of w.blocks) {
    const x0 = Math.min(X(b.u0), X(b.u1));
    svg.append(el('rect', { class: 'block', x: x0, y: Y(b.y1), width: Math.abs(b.u1 - b.u0), height: b.y1 - b.y0 }));
    if (b.kind !== 'pilastre') svg.append(el('text', { class: 'block-label', x: x0 + 0.1, y: Y(b.y1) + 0.35 }, b.kind));
  }
  const step = win > 10 ? 2 : 1;
  for (let u = 0; u <= w.length + 0.01; u += step) svg.append(el('text', { class: 'scale', x: X(u) - 0.1, y: H + 0.25 }, `${u}`));
  const rectFor = (a) => ({ x: X(a.u) - a.width / 2, y: Y(a.y + a.height / 2), width: a.width, height: a.height });
  S.content.artworks.forEach((o, i) => {
    if (o === art || o.wall !== art.wall) return;
    const r = el('rect', { class: 'other', ...rectFor(o) });
    r.append(el('title', {}, o.title));
    r.addEventListener('click', () => onSelectOther(i));
    svg.append(r);
  });
  const cur = el('rect', { class: 'current', ...rectFor(art) });
  svg.append(cur);

  let drag = null;
  const toWall = (ev) => {
    const pt = svg.createSVGPoint();
    pt.x = ev.clientX; pt.y = ev.clientY;
    const p = pt.matrixTransform(svg.getScreenCTM().inverse());
    return { u: w.mirror ? w.length - p.x : p.x, y: H - p.y };
  };
  cur.addEventListener('pointerdown', (ev) => {
    ev.preventDefault();
    cur.setPointerCapture(ev.pointerId);
    const p = toWall(ev);
    drag = { du: art.u - p.u, dy: art.y - p.y };
  });
  cur.addEventListener('pointermove', (ev) => {
    if (!drag) return;
    const p = toWall(ev);
    art.u = round(Math.min(Math.max(p.u + drag.du, art.width / 2), w.length - art.width / 2));
    art.y = round(Math.min(Math.max(p.y + drag.dy, art.height / 2), H - art.height / 2));
    const r = rectFor(art);
    cur.setAttribute('x', r.x); cur.setAttribute('y', r.y);
    onMove?.();
  });
  const end = () => { if (drag) { drag = null; changed(); onMove?.(); onEnd?.(); } };
  cur.addEventListener('pointerup', end);
  cur.addEventListener('pointercancel', end);
  return svg;
}

/** Redimensionne une image (2000 px max) et la convertit en JPEG. */
async function prepareImage(file) {
  const bitmap = await createImageBitmap(file).catch(async () => {
    const img = new Image();
    img.src = URL.createObjectURL(file);
    await img.decode();
    return img;
  });
  const sw = bitmap.width, sh = bitmap.height;
  const k = Math.min(1, 2000 / Math.max(sw, sh));
  const c = document.createElement('canvas');
  c.width = Math.round(sw * k); c.height = Math.round(sh * k);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(bitmap, 0, 0, c.width, c.height);
  const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.88));
  return { blob, width: c.width, height: c.height };
}

/* ================= Onglet Textes ================= */
const TEXT_FIELDS = [
  ['name', 'Nom de la galerie', "Titre principal, onglet du navigateur et inscription de l'entrée."],
  ['tagline', 'Sous-titre court', "Affiché pendant le chargement et dans l'onglet du navigateur."],
  ['eyebrow', 'Petite ligne au-dessus du titre (accueil)'],
  ['welcomeText', "Texte d'accueil", '', true],
  ['enterLabel', "Bouton d'entrée"],
  ['inscription', "Inscription gravée dans l'entrée", 'Laisser vide pour reprendre le nom de la galerie.'],
  ['hoverHint', "Indication au survol d'une œuvre"],
  ['backLabel', 'Bouton pour fermer une fiche'],
  ['linkLabel', 'Texte par défaut des boutons de lien'],
  ['documentLabel', 'Texte par défaut des boutons de document'],
  ['pauseTitle', 'Titre de l\'écran de pause'],
  ['resumeLabel', 'Bouton pour reprendre la visite'],
  ['metaDescription', 'Description pour les moteurs de recherche', 'Une ou deux phrases.', true],
];
function viewTexts() {
  const site = S.content.site;
  return [
    h('h1', { class: 'section' }, 'Textes'),
    h('p', { class: 'lead' }, 'Tous les textes visibles par les visiteurs. Les modifications sont enregistrées automatiquement.'),
    h('div', { class: 'card' }, TEXT_FIELDS.map(([k, label, help, area]) =>
      textField(label, site, k, { textarea: !!area, help, placeholder: DEFAULT_SITE[k], onChange: k === 'name' ? updateStatus : null }))),
  ];
}

/* ================= Onglet Couleurs ================= */
const COLOR_FIELDS = [
  ['walls', 'Murs', 'Couleur des grands murs.'],
  ['trim', 'Moulures et plafond', 'Pilastres, corniches, nervures, encadrements.'],
  ['wood', 'Bois', 'Soubassements, portes, chaises.'],
  ['floor', 'Teinte du parquet', 'Blanc = couleur naturelle du bois.'],
  ['gilt', 'Cadres dorés'],
  ['accent', "Couleur d'accent de l'interface", 'Boutons, filets, petits titres.'],
  ['ink', 'Texte'],
  ['background', "Fond des écrans d'accueil", 'Sert aussi de papier pour les affiches.'],
];
function viewColors() {
  const t = S.content.theme;
  const presets = h('div', { class: 'presets' }, Object.entries(THEME_PRESETS).map(([k, p]) =>
    h('button', { type: 'button', class: 'preset' + (t.preset === k ? ' is-active' : ''), onclick: () => {
      Object.assign(t, { ...p, preset: k });
      delete t.label;
      changed(); render(); toast(`Thème « ${p.label} » appliqué.`);
    } }, h('div', { class: 'swatches' }, ['walls', 'trim', 'wood', 'gilt', 'accent'].map((c) => h('i', { style: `background:${p[c]}` }))), p.label)));
  const rows = COLOR_FIELDS.map(([k, label, help]) => {
    const input = h('input', { type: 'color', value: t[k] });
    input.addEventListener('input', () => { t[k] = input.value; t.preset = 'perso'; changed(); });
    return h('label', { class: 'color-row' }, input, h('div', {}, h('strong', {}, label), help && h('small', {}, help)));
  });
  const range = (key, label, min, max, help) => {
    const out = h('output', {}, (+t[key]).toFixed(2));
    const input = h('input', { type: 'range', min, max, step: 0.05, value: t[key] });
    input.addEventListener('input', () => { t[key] = +input.value; out.textContent = (+input.value).toFixed(2); changed(); });
    return h('label', { class: 'field' }, h('span', {}, label, ' : ', out), input, h('small', {}, help));
  };
  return [
    h('h1', { class: 'section' }, 'Couleurs et lumière'),
    h('p', { class: 'lead' }, "Choisissez une ambiance toute prête, puis ajustez si besoin. Utilisez « Aperçu » pour voir le résultat en 3D."),
    h('div', { class: 'card' }, h('h3', {}, 'Ambiances'), presets),
    h('div', { class: 'card' }, h('h3', {}, 'Couleurs'), rows),
    h('div', { class: 'card' }, h('h3', {}, 'Lumière'),
      range('exposure', 'Luminosité générale', 0.6, 1.6, '1 = réglage d\'origine.'),
      range('sunlight', 'Rayons de soleil', 0, 2, '0 = pas de soleil direct, 1 = réglage d\'origine.')),
  ];
}

/* ================= Onglet Liens ================= */
function viewLinks() {
  const links = S.content.links;
  const list = h('div', {});
  const renderList = () => {
    list.replaceChildren(...links.map((l, i) => h('div', { class: 'link-row' },
      (() => { const f = h('input', { placeholder: 'Texte (ex. Instagram)', 'aria-label': 'Texte du lien' }); f.value = l.label; f.addEventListener('input', () => { l.label = f.value; changed(); }); return f; })(),
      (() => { const f = h('input', { type: 'url', placeholder: 'https://… ou mailto:…', 'aria-label': 'Adresse' }); f.value = l.url; f.addEventListener('input', () => { l.url = f.value.trim(); changed(); }); return f; })(),
      h('button', { type: 'button', class: 'btn small danger', 'aria-label': 'Supprimer', onclick: () => { links.splice(i, 1); changed(); renderList(); } }, '✕'))),
    links.length ? '' : h('p', { class: 'help' }, 'Aucun lien pour le moment.'));
  };
  renderList();
  return [
    h('h1', { class: 'section' }, 'Liens du portfolio'),
    h('p', { class: 'lead' }, "Site personnel, réseaux sociaux, contact… Ils apparaissent sur l'écran d'accueil et dans le menu de la visite. Pour un e-mail : mailto:adresse@exemple.fr"),
    h('div', { class: 'card' }, list,
      h('button', { type: 'button', class: 'btn', onclick: () => { links.push({ label: '', url: '' }); changed(); renderList(); } }, '+ Ajouter un lien')),
  ];
}

/* ================= Onglet Publier ================= */
function pendingFiles() { return Object.keys(S.files).filter((p) => usedPaths().has(p)); }
function usedPaths() {
  const s = new Set();
  S.content.artworks.forEach((a) => { if (a.image) s.add(a.image); if (a.document.url) s.add(a.document.url); });
  return s;
}

function viewPublish() {
  const gh = ghSettings();
  const log = h('div', { class: 'log' });
  const say = (msg, cls = '') => { log.className = 'log ' + cls; log.textContent = msg; };
  const f = {
    owner: h('input', { placeholder: 'ex. marie-dupont', autocapitalize: 'off', autocomplete: 'off' }),
    repo: h('input', { placeholder: 'ex. galerie', autocapitalize: 'off', autocomplete: 'off' }),
    branch: h('input', { placeholder: 'main', autocapitalize: 'off' }),
    token: h('input', { type: 'password', placeholder: 'github_pat_…', autocomplete: 'off', autocapitalize: 'off' }),
    remember: h('input', { type: 'checkbox' }),
  };
  f.owner.value = gh.owner; f.repo.value = gh.repo; f.branch.value = gh.branch; f.token.value = gh.token; f.remember.checked = gh.remember;
  const read = () => ({ owner: f.owner.value.trim(), repo: f.repo.value.trim(), branch: f.branch.value.trim() || 'main', token: f.token.value.trim(), remember: f.remember.checked, apiBase: gh.apiBase });
  Object.values(f).forEach((i) => i.addEventListener('change', () => saveGhSettings(read())));

  const pend = pendingFiles();
  const message = h('input', {});
  message.value = 'Mise à jour du contenu depuis l\'administration';

  async function test() {
    saveGhSettings(read());
    const repo = ghRepo();
    if (!repo) return say('Renseignez le propriétaire, le dépôt et le jeton.', 'err-text');
    say('Vérification…');
    try {
      const r = await repo.check();
      say(`Connexion réussie au dépôt ${r.fullName}.${r.canPush ? '' : "\n⚠ Ce jeton ne semble pas avoir le droit d'écrire."}${r.pagesUrl ? `\nSite publié : ${r.pagesUrl}` : "\nGitHub Pages n'est pas encore activé (voir l'aide)."}`, r.canPush ? 'ok-text' : 'err-text');
    } catch (e) { say(e.message, 'err-text'); }
  }

  async function publish() {
    saveGhSettings(read());
    const repo = ghRepo();
    if (!repo) return say('Renseignez la connexion GitHub ci-dessus, ou utilisez « Exporter ».', 'err-text');
    const text = serializeContent(S.content);
    try {
      updateStatus('busy');
      say('Vérification de la version en ligne…');
      let remote = '';
      try { remote = await repo.readText(CONTENT_URL); } catch (e) { if (e.status !== 404) throw e; }
      if (S.baseText && remote && remote.trim() !== S.baseText.trim() && remote.trim() !== text.trim()) {
        if (!confirm('Le contenu en ligne a été modifié ailleurs depuis le début de ce brouillon (autre appareil ou autre personne). Publier quand même et remplacer cette version ?')) {
          updateStatus(); return say('Publication annulée.');
        }
      }
      const files = [{ path: CONTENT_URL, content: text }, ...pendingFiles().map((p) => ({ path: p, content: S.files[p] }))];
      const res = await repo.commitFiles(files, message.value || 'Mise à jour du contenu', (s) => say(s));
      S.files = {};
      S.baseText = text;
      S.dirty = false;
      await clearDraft();
      $('#draft-banner').hidden = true;
      updateStatus();
      const r = await repo.check().catch(() => ({}));
      say(`✓ Publié (${files.length} fichier${files.length > 1 ? 's' : ''}).\nLe site en ligne sera à jour d'ici 1 à 2 minutes${r.pagesUrl ? ' : ' + r.pagesUrl : ''}.\nCommit : ${res.url || res.sha}`, 'ok-text');
      toast('Publié !');
    } catch (e) {
      console.error(e);
      updateStatus();
      say('La publication a échoué : ' + e.message + '\nVotre brouillon est conservé sur cet appareil.', 'err-text');
    }
  }

  async function exportZip() {
    if (!window.JSZip) return say('Module ZIP indisponible (vendor/jszip.min.js).', 'err-text');
    const zip = new window.JSZip();
    zip.file(CONTENT_URL, serializeContent(S.content));
    for (const p of pendingFiles()) zip.file(p, S.files[p]);
    zip.file('A-LIRE.txt', "Copiez ces dossiers à la racine du projet en remplaçant les fichiers existants,\npuis publiez (voir docs/DEPLOIEMENT-GITHUB-PAGES.md).\n");
    const blob = await zip.generateAsync({ type: 'blob' });
    download(blob, `contenu-galerie-${new Date().toISOString().slice(0, 10)}.zip`);
    say(`ZIP téléchargé : content/site.json${pend.length ? ` + ${pend.length} fichier(s) ajouté(s)` : ''}.`, 'ok-text');
  }

  const importInput = h('input', { type: 'file', accept: '.json,application/json' });
  importInput.addEventListener('change', async () => {
    const file = importInput.files[0];
    if (!file) return;
    try {
      S.content = normalizeContent(JSON.parse(await file.text()));
      changed(); updateStatus(); say(`Contenu importé depuis ${file.name} (${S.content.artworks.length} œuvres). Pensez à publier.`, 'ok-text');
    } catch { say("Ce fichier n'est pas un site.json valide.", 'err-text'); }
  });

  async function discard() {
    if (!confirm('Abandonner toutes les modifications non publiées et revenir à la version en ligne ?')) return;
    await clearDraft();
    S.files = {};
    const text = await fetchPublished();
    S.baseText = text;
    S.content = normalizeContent(JSON.parse(text));
    S.dirty = false;
    $('#draft-banner').hidden = true;
    thumbCache.clear();
    updateStatus(); render(); toast('Brouillon abandonné.');
  }

  return [
    h('h1', { class: 'section' }, 'Publier'),
    h('p', { class: 'lead' }, S.dirty
      ? `Vous avez des modifications non publiées${pend.length ? ` et ${pend.length} fichier(s) ajouté(s)` : ''}. Elles sont enregistrées sur cet appareil uniquement.`
      : 'Tout est à jour.'),
    h('div', { class: 'card' },
      h('h3', {}, '1. Publier en ligne (GitHub Pages)'),
      h('p', { class: 'help' }, "Envoie vos modifications sur GitHub ; le site se met à jour tout seul en 1 à 2 minutes. La connexion n'est à saisir qu'une fois par appareil."),
      h('div', { class: 'grid2' },
        h('label', { class: 'field' }, h('span', {}, 'Propriétaire (compte GitHub)'), f.owner),
        h('label', { class: 'field' }, h('span', {}, 'Nom du dépôt'), f.repo)),
      h('label', { class: 'field' }, h('span', {}, 'Branche'), f.branch),
      h('label', { class: 'field' }, h('span', {}, "Jeton d'accès GitHub"), f.token,
        h('small', {}, 'Jeton « fine-grained » limité à ce dépôt, permission Contents : Read and write. Il reste sur cet appareil et n\'est envoyé qu\'à GitHub. Voir l\'onglet Aide.')),
      h('label', { class: 'check' }, f.remember, 'Se souvenir du jeton sur cet appareil'),
      h('label', { class: 'field' }, h('span', {}, 'Description de la modification'), message),
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'btn', onclick: test }, 'Tester la connexion'),
        h('button', { type: 'button', class: 'btn primary', onclick: publish }, 'Publier maintenant')),
      h('p', {}), log),
    h('div', { class: 'card' },
      h('h3', {}, '2. Sans connexion GitHub'),
      h('p', { class: 'help' }, "Téléchargez vos modifications (site.json + images et documents ajoutés) pour les déposer vous-même sur GitHub ou les transmettre."),
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'btn', onclick: exportZip }, 'Exporter (ZIP)'),
        h('button', { type: 'button', class: 'btn', onclick: () => download(new Blob([serializeContent(S.content)], { type: 'application/json' }), 'site.json') }, 'Télécharger site.json'),
        h('span', { class: 'btn file-btn' }, 'Importer un site.json…', importInput))),
    h('div', { class: 'card' },
      h('h3', {}, '3. Recommencer'),
      h('button', { type: 'button', class: 'btn danger', onclick: discard }, 'Abandonner le brouillon')),
    h('div', { class: 'card' },
      h('h3', {}, 'Déconnexion'),
      h('p', { class: 'help' }, "Efface le jeton enregistré sur cet appareil (à faire sur un appareil partagé)."),
      h('button', { type: 'button', class: 'btn', onclick: () => { saveGhSettings({ ...read(), token: '' }); f.token.value = ''; toast('Jeton effacé de cet appareil.'); } }, 'Oublier le jeton')),
  ];
}

function download(blob, name) {
  const a = h('a', { href: URL.createObjectURL(blob), download: name });
  document.body.append(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}

/* ================= Onglet Aide ================= */
function viewHelp() {
  return [
    h('h1', { class: 'section' }, 'Aide'),
    h('div', { class: 'card' }, h('h3', {}, 'Le principe'),
      h('ol', { class: 'steps' },
        h('li', {}, 'Modifiez les œuvres, textes, couleurs et liens : tout est enregistré automatiquement sur cet appareil (brouillon).'),
        h('li', {}, '« Aperçu » ouvre la galerie 3D avec vos modifications, sans les mettre en ligne.'),
        h('li', {}, '« Publier » met le site à jour pour tout le monde (1 à 2 minutes).'))),
    h('div', { class: 'card' }, h('h3', {}, 'Créer le jeton GitHub (une seule fois)'),
      h('ol', { class: 'steps' },
        h('li', {}, 'Sur github.com : photo de profil → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token.'),
        h('li', {}, 'Repository access : « Only select repositories » → choisissez le dépôt du site.'),
        h('li', {}, 'Permissions → Repository permissions → Contents : « Read and write ».'),
        h('li', {}, 'Générez, copiez le jeton et collez-le dans l\'onglet Publier. Ne le communiquez à personne.')),
      h('p', { class: 'help' }, 'Le jeton a une date d\'expiration : quand il expire, créez-en un nouveau de la même manière.')),
    h('div', { class: 'card' }, h('h3', {}, 'Remplacer un tableau par un lien ou un document'),
      h('ol', { class: 'steps' },
        h('li', {}, 'Ouvrez l\'œuvre, section « Lien et document » : saisissez l\'adresse ou ajoutez un PDF.'),
        h('li', {}, 'Dans « Quand on clique sur l\'œuvre », choisissez l\'ouverture directe.'),
        h('li', {}, 'Section « Visuel » : gardez une image, ou choisissez « Affiche » pour afficher le titre en grand.'))),
    h('div', { class: 'card' }, h('h3', {}, 'Documentation complète'),
      h('p', { class: 'help' }, 'Dans le dossier du projet : docs/GUIDE-PROPRIETAIRE.md (guide simple), docs/TECHNIQUE.md, docs/DEPLOIEMENT-GITHUB-PAGES.md et AI_CONTEXT.md (pour confier le projet à une IA).'),
      h('div', { class: 'row' },
        h('a', { class: 'btn', href: BASE + 'docs/GUIDE-PROPRIETAIRE.md', target: '_blank', rel: 'noopener' }, 'Ouvrir le guide'),
        h('a', { class: 'btn', href: BASE, target: '_blank', rel: 'noopener' }, 'Voir le site publié'))),
  ];
}

init().catch((e) => {
  console.error(e);
  $('#main').replaceChildren(h('div', { class: 'card' },
    h('h3', {}, 'Chargement impossible'),
    h('p', {}, location.protocol === 'file:'
      ? "L'administration doit être ouverte via un serveur (double-cliquez sur demarrer-mac.command ou demarrer-windows.bat) ou depuis le site en ligne."
      : 'Le fichier content/site.json est introuvable ou invalide : ' + e.message)));
});

// accès pour les tests automatisés
window.__admin = { S, render, openEditor, switchTab, persist };
