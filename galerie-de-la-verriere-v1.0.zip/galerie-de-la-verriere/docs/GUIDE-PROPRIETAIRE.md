# Guide du propriétaire — gérer sa galerie sans toucher au code

Ce guide explique, pas à pas, comment modifier votre galerie : œuvres, textes,
couleurs, liens, documents… depuis un ordinateur **ou depuis votre téléphone**.

---

## 1. Les deux adresses à retenir

Une fois le site en ligne (voir `DEPLOIEMENT-GITHUB-PAGES.md`) :

| | Adresse |
| --- | --- |
| **La galerie** (pour vos visiteurs) | `https://VOTRE-COMPTE.github.io/VOTRE-DEPOT/` |
| **L'Atelier** (votre administration) | `https://VOTRE-COMPTE.github.io/VOTRE-DEPOT/admin/` |

> Astuce téléphone : ouvrez l'adresse de l'Atelier puis « Partager → Sur l'écran
> d'accueil » (iPhone) ou « ⋮ → Ajouter à l'écran d'accueil » (Android) pour l'avoir
> comme une application.

Sur votre ordinateur, sans Internet : double-cliquez sur **`demarrer-mac.command`**
(Mac) ou **`demarrer-windows.bat`** (Windows), puis allez sur
`http://localhost:8765/admin/`. (Sur Mac, la première fois : clic droit → Ouvrir.)

---

## 2. Le principe en 3 temps

1. **Modifier** dans l'Atelier : tout est enregistré automatiquement **sur l'appareil
   que vous utilisez** (c'est un « brouillon »). Le bouton en haut affiche
   « Publier ● » tant que des modifications ne sont pas en ligne.
2. **Vérifier** avec **Aperçu** : la galerie 3D s'ouvre avec vos modifications,
   un bandeau indique « Aperçu du brouillon — non publié ».
3. **Publier** : onglet **Publier → Publier maintenant**. Le site est à jour pour tout le
   monde en 1 à 2 minutes.

> Le brouillon reste sur l'appareil où vous l'avez fait. Commencez et publiez depuis le
> même appareil (téléphone **ou** ordinateur).

---

## 3. Première connexion à GitHub (une seule fois par appareil)

L'Atelier publie directement sur GitHub grâce à un **jeton d'accès** (une sorte de mot de
passe limité à votre site).

1. Connectez-vous sur <https://github.com>.
2. Photo de profil (en haut à droite) → **Settings** → tout en bas **Developer settings**
   → **Personal access tokens** → **Fine-grained tokens** → **Generate new token**.
3. Donnez un nom (ex. « Atelier galerie ») et une durée (ex. 1 an).
4. **Repository access** : *Only select repositories* → choisissez le dépôt du site.
5. **Permissions → Repository permissions → Contents** : *Read and write*.
6. **Generate token**, puis copiez le jeton (il commence par `github_pat_`).
7. Dans l'Atelier, onglet **Publier** : propriétaire (votre nom de compte GitHub), nom du
   dépôt (souvent déjà rempli), branche `main`, collez le jeton, cochez « Se souvenir du
   jeton sur cet appareil » si l'appareil est personnel → **Tester la connexion**.

🔒 Ne communiquez jamais ce jeton. Sur un appareil partagé, ne cochez pas « Se souvenir »
et utilisez « Oublier le jeton » à la fin. Quand le jeton expire, recréez-en un.

---

## 4. Modifier une œuvre

Onglet **Œuvres** → touchez l'œuvre. La fiche se découpe en sections :

- **Informations** : titre, artiste, année, technique, dimensions, description
  (affichée quand un visiteur clique sur l'œuvre).
- **Visuel** :
  - **Image** → *Choisir une image…* (galerie photo ou appareil photo). L'image est
    optimisée automatiquement et **la hauteur du cadre s'adapte** à ses proportions.
  - **Peinture générée** → un tableau « de démonstration » ; *Autre variante* pour en
    changer.
  - **Affiche** → le titre écrit en grand, idéal pour un document ou un lien.
- **Lien et document** (facultatif) : une adresse internet et/ou un document (PDF…).
  Des boutons apparaissent dans la fiche de l'œuvre.
- **Emplacement** : choisissez le mur, puis **faites glisser l'œuvre sur le plan**
  (doigt ou souris). Les autres œuvres sont en gris ; un message ⚠ prévient si l'œuvre
  chevauche quelque chose ou dépasse. Les cases *Largeur / Hauteur* règlent la taille
  (en mètres).
- **Cadre** : doré, bois sombre ou noir. **Cartel** : la petite étiquette à côté.

Boutons en bas : **Dupliquer**, **Retirer de la galerie**, **Terminé**.
Pour ajouter une œuvre : carte **+ Ajouter une œuvre** (en haut de la liste).

### Remplacer un tableau par un lien ou un document

1. Ouvrez l'œuvre → **Lien et document** : collez l'adresse, ou *Ajouter un document…*.
2. **Quand on clique sur l'œuvre** → *Ouvrir directement le lien* (ou *le document*).
3. **Visuel** : gardez une image, ou choisissez **Affiche**.

Résultat : un clic sur ce tableau dans la galerie ouvre directement votre lien ou votre PDF.

---

## 5. Textes, couleurs, liens

- **Textes** : nom de la galerie, texte d'accueil, libellés des boutons, inscription
  gravée à l'entrée, description pour Google…
- **Couleurs** : choisissez une **ambiance** (Galerie claire, Bleu nuit et or, Vert sauge,
  Rouge pompéien), puis ajustez chaque couleur si besoin (murs, moulures, bois, parquet,
  cadres dorés, interface) ainsi que la **luminosité** et les **rayons de soleil**.
  Utilisez **Aperçu** pour juger du rendu en 3D.
- **Liens** : Instagram, site, boutique, e-mail (`mailto:vous@exemple.fr`)… Ils
  s'affichent sur l'écran d'accueil et dans le menu ☰ de la visite.

---

## 6. Sans connexion GitHub

Onglet **Publier → Sans connexion GitHub** :

- **Exporter (ZIP)** : télécharge `content/site.json` et les images/documents ajoutés.
  Pour les mettre en ligne : sur github.com, ouvrez le dépôt → **Add file → Upload files**
  → glissez les dossiers `content` et `assets` du ZIP → **Commit changes**.
- **Télécharger site.json** / **Importer un site.json** : sauvegarder ou restaurer tout le
  contenu (pratique pour passer d'un appareil à l'autre).

**Abandonner le brouillon** revient à la version actuellement en ligne.

---

## 7. Problèmes fréquents

| Problème | Solution |
| --- | --- |
| « Jeton refusé » | Jeton mal copié ou expiré : recréez-le (section 3). |
| « Accès refusé » | Le jeton n'a pas la permission *Contents : Read and write* sur ce dépôt. |
| Le site ne change pas après publication | Attendez 2 minutes, puis rechargez (sur téléphone : fermer et rouvrir l'onglet). |
| « Le contenu en ligne a été modifié ailleurs » | Une autre publication a eu lieu depuis un autre appareil. Annulez, cliquez *Abandonner le brouillon* pour repartir de la version en ligne, puis refaites vos changements — ou confirmez pour écraser. |
| Une image n'apparaît pas | Préférez *Choisir une image…* plutôt qu'une adresse d'un autre site (souvent bloquée). |
| La galerie est lente | Elle réduit automatiquement sa qualité. Fermez les autres onglets. |
| Page blanche en ouvrant `index.html` sur l'ordinateur | Utilisez `demarrer-mac.command` / `demarrer-windows.bat`. |

Besoin d'une évolution (nouvelle salle, vidéo, musique…) ? Donnez le dossier complet à une
IA en lui demandant de lire d'abord **`AI_CONTEXT.md`**.
