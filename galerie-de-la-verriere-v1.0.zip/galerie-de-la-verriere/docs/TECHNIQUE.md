# Documentation technique

Public : développeurs et IA. Pour une vue synthétique et les règles à respecter, lire
d'abord `../AI_CONTEXT.md`.

## Sommaire

1. Architecture
2. Installation et lancement
3. Configuration
4. Fonctionnement du site public
5. Interface d'administration
6. Personnalisation avancée
7. Déploiement
8. Maintenance
9. Résolution des problèmes
10. Dépendances et licences

---

## 1. Architecture

Site **statique** en HTML5 / CSS3 / JavaScript ES2020 (modules natifs), rendu 3D avec
**Three.js 0.169.0** (copié dans `vendor/three/`). Aucune étape de build.

```
                ┌──────────────── content/site.json ────────────────┐
                │      (textes, liens, thème, œuvres — source unique) │
                └───────▲─────────────────────────────▲──────────────┘
                        │ fetch                       │ commit (API GitHub)
  index.html + main.js ─┘                             └─ admin/ (Atelier)
        │                                                   │
        │  ?apercu  ◄── IndexedDB « galerie-admin » ◄───────┘ brouillon + fichiers
        ▼
   Three.js : museum.js (architecture) · paintings.js (œuvres) · materials.js · controls.js
```

### Modules

| Fichier | Responsabilité | Exports principaux |
| --- | --- | --- |
| `main.js` | Orchestration, lumières, post-traitement, boucle, états, interactions | — |
| `js/content.js` | Modèle de contenu, valeurs par défaut, chargement, résolution des fichiers | `normalizeContent`, `serializeContent`, `loadContent`, `resolveAsset`, `THEME_PRESETS`, `STYLES`… |
| `js/layout.js` | Dimensions et plan des murs (sans Three.js) | `DIM`, `WALLS`, `HANG_MIN_Y` |
| `js/museum.js` | Géométrie de la galerie, portes, chaises, colliders | `buildMuseum`, `makeWall`, `wallMatrix`, `wallPoint` |
| `js/paintings.js` | Toiles, cadres extrudés, cartels, ombres de contact | `hangArtworks`, `artworkImageURL` |
| `js/painter.js` | Peintures procédurales et affiches (Canvas 2D) | `paintArtwork` |
| `js/materials.js` / `js/textures.js` | Matériaux PBR / textures procédurales | `createMaterials` |
| `js/controls.js` | Première personne, collisions cercle/boîtes | `Controller` |
| `js/ui.js` | DOM : textes, liens, fiche, survol | `UI` |
| `js/store.js` | Brouillon IndexedDB | `loadDraft`, `saveDraft`, `clearDraft` |
| `js/github.js` | API GitHub (Git Data) | `GitHubRepo`, `guessRepoFromLocation` |
| `admin/admin.js` | Interface d'administration | — |

### Scène 3D

- Galerie de 8 × 42 m, murs de 6,75 m, plafond en rampants à nervures, verrière à petits bois
  (y = 8,75 m), vestibule (z > 0) et petite salle au fond derrière l'arche (z < −42,35).
- Repère : visiteur à l'entrée en (0, 1,65, −1,6) regardant −z. Chaque mur est décrit par
  `makeWall(origine, direction, normale, longueur)` ; `wallMatrix(mur, u, y, d)` donne la
  matrice d'un point à `u` m le long du mur, `y` m de haut, `d` m devant le mur.
- Les pièces statiques sont fusionnées par matériau (`Batch`). UV « monde » en mètres
  (`applyWorldUV`) → densité de texture constante.
- Lumières : hémisphérique (ambiance), directionnelle (soleil, ombres PCF 4096², calculées
  une fois), `RectAreaLight` sous la verrière, lumière de la petite salle, ponctuelle du
  vestibule ; reflets par capture `CubeCamera` + PMREM ; tone mapping « Neutral ».
- Post-traitement (qualité haute) : `GTAOPass` (occlusion ambiante) + `OutputPass`.
- Collisions : liste de boîtes XZ (`colliders`) ; le visiteur est un cercle de 0,32 m.

### États de l'application (main.js)

`loading` → `welcome` → `touring` ⇄ `paused` ; `touring` → `modal` → `touring|paused`.
Verrouillage du pointeur sur ordinateur ; à défaut (ou au tactile) « mode glisser »
(`controller.dragMode`).

---

## 2. Installation et lancement

Prérequis : un navigateur récent (Chrome, Edge, Firefox, Safari 16+). Pour un serveur
local : Python 3 (préinstallé sur Mac), ou n'importe quel serveur statique.

```bash
python3 -m http.server 8765
# Galerie : http://localhost:8765/    Atelier : http://localhost:8765/admin/
```

Raccourcis : `demarrer-mac.command`, `demarrer-windows.bat` (double-clic).
Alternatives : `npx serve .`, extension « Live Server » de VS Code.

⚠ `file://` n'est pas supporté (les modules ES exigent HTTP).

Vérification : `node tools/check.mjs` (Node 18+, aucune installation).

---

## 3. Configuration

| Où | Quoi |
| --- | --- |
| `content/site.json` | Tout le contenu (voir `content/site.schema.json`). Éditable via l'Atelier. |
| `js/config.js` → `MUSEUM` | Hauteur des yeux, vitesses de marche, sensibilité de la souris. |
| `js/config.js` → `TEXTURE_OVERRIDES` | Photos de matériaux (parquet, plâtre, bois) à la place des textures procédurales. |
| `js/layout.js` → `DIM` | Dimensions de l'architecture. |
| `main.js` → `QUALITY` | Niveaux de qualité (résolution, GTAO, taille des ombres). |
| `js/content.js` → `THEME_PRESETS` | Ambiances de couleurs proposées dans l'Atelier. |

---

## 4. Fonctionnement du site public

1. Lecture du contenu (`loadContent`) ; `?apercu` → brouillon de l'Atelier.
2. Textes injectés dans les éléments `data-text="clé"` ; liens dans `[data-links]` ;
   couleurs d'interface via les variables CSS `--gold`, `--ink`, `--cream`.
3. Construction : matériaux (teintes du thème) → architecture → œuvres (image chargée avec
   recadrage « cover », sinon peinture générée ou affiche) → lumières → reflets.
4. Interaction : raycast (centre de l'écran si pointeur verrouillé, sinon position de la
   souris/du doigt) limité à 9 m et aux faces avant ; `clickAction` :
   `details` (fiche), `link` ou `document` (ouverture dans un nouvel onglet).
5. Mobile : joystick virtuel (moitié gauche), regard (moitié droite), toucher = sélection ;
   bouton ☰ (menu/pause) ; champ de vision horizontal ≥ 72° en portrait ; qualité basse.

---

## 5. Interface d'administration (`admin/`)

- Page statique, **sans Three.js** (n'importe que `content.js`, `layout.js`, `painter.js`,
  `store.js`, `github.js`).
- Onglets : Œuvres (liste, recherche, filtre par mur, éditeur), Textes, Couleurs, Liens,
  Publier, Aide. Barre d'onglets en bas sur mobile, en haut au-delà de 900 px.
- Éditeur d'œuvre : informations, visuel (image / générée / affiche), lien & document,
  `clickAction`, mur + plan SVG déplaçable (fenêtre de 14 m, pointeurs souris/tactile),
  dimensions, cadre, cartel ; contrôles de placement (`placementWarnings`).
- Images : redimensionnées à 2000 px max et converties en JPEG 88 % dans le navigateur ;
  chemin `assets/artworks/<slug>-<base36>.jpg`. Documents : ≤ 25 Mo,
  `assets/documents/<slug>-<base36>.<ext>`.
- Brouillon : IndexedDB `galerie-admin` → store `kv` → clé `draft`
  `{ content, files: {chemin: Blob}, baseText, savedAt }`, sauvegardé 400 ms après chaque
  modification. Le site le lit en mode `?apercu`.
- Publication (`js/github.js`) : `GET ref` → `GET commit` → `POST blobs` (un par fichier)
  → `POST trees` (avec `base_tree`) → `POST commits` → `PATCH ref`. Un seul commit.
  Paramètres stockés dans `localStorage['galerie-admin-github']`, jeton dans
  `sessionStorage` ou `localStorage` (« se souvenir »). Paramètre caché `apiBase` (tests).
- Sans GitHub : export ZIP (JSZip) de `content/site.json` + fichiers ajoutés ; import d'un
  `site.json`.
- Sécurité : la page est publique mais inoffensive sans jeton ; le jeton fine-grained doit
  être limité au dépôt et à la permission *Contents: Read and write*. `noindex` sur l'admin.

---

## 6. Personnalisation avancée

Voir les recettes de `AI_CONTEXT.md` § 6. Points d'attention :

- toute donnée éditable doit passer par `site.json` + `normalizeContent` ;
- après ajout d'objets 3D statiques, utiliser le `Batch` et des clés de matériau existantes ;
- les nouvelles textures doivent être raccordables (bruit périodique `makeNoise`) ;
- tester en 375 × 812 (mobile) et en bureau.

---

## 7. Déploiement

Voir `DEPLOIEMENT-GITHUB-PAGES.md`. Résumé : dépôt public, Pages « Deploy from a branch »
`main` / root, `.nojekyll` présent. Chaque push (ou publication depuis l'Atelier)
redéploie en 1–2 minutes.

---

## 8. Maintenance

- **Avant chaque envoi** : `node tools/check.mjs`.
- **Jeton expiré** : en recréer un (le site continue de fonctionner, seule la publication
  depuis l'Atelier échoue).
- **Fichiers orphelins** : les images remplacées restent dans `assets/artworks/` (la
  publication ne supprime rien). Nettoyage manuel possible : supprimer les fichiers que
  `content/site.json` ne cite plus, puis commit.
- **Poids** : garder le dépôt sous ~500 Mo (limite conseillée par GitHub Pages : 1 Go).
- **Mise à jour de Three.js** : remplacer `vendor/three/` par la même arborescence
  (`build/three.module.js` + modules `examples/jsm` utilisés et leurs dépendances), puis
  tout retester (APIs sensibles : `GTAOPass`, `RectAreaLightUniformsLib`,
  `NeutralToneMapping`, `scene.environmentIntensity`, `renderer.compileAsync`).
- **Sauvegarde** : le dépôt GitHub *est* la sauvegarde (historique complet). L'Atelier
  permet aussi de télécharger `site.json`.

---

## 9. Résolution des problèmes

| Symptôme | Cause probable | Solution |
| --- | --- | --- |
| Page blanche, erreur de module | Ouverture en `file://` | Utiliser un serveur local |
| « Le chargement de la galerie a échoué » | `content/site.json` invalide ou absent | `node tools/check.mjs` ; valider le JSON |
| 404 sur un fichier en ligne, OK en local | Casse différente (Mac insensible, Pages sensible) | `node tools/check.mjs` signale la casse |
| Site en ligne non mis à jour | Cache / déploiement en cours | Onglet *Actions* du dépôt ; rechargement forcé |
| Image d'œuvre remplacée par une peinture | Fichier introuvable ou URL externe bloquée (CORS) | Console du navigateur ; déposer l'image dans `assets/artworks/` |
| Publication : 401 / 403 / 404 | Jeton invalide / permission manquante / dépôt ou branche erronés | Recréer le jeton fine-grained (Contents RW, dépôt ciblé) |
| Publication : 409 | Dépôt vide | Faire un premier envoi (option A ou B du déploiement) |
| `git push` refusé | L'Atelier a commité entre-temps | `git pull --rebase` puis `git push` |
| Galerie lente | GPU modeste | Qualité adaptative automatique ; `__galerie.setQuality(0)` en console |
| Souris non capturée | Navigateur/iframe sans Pointer Lock | Mode glisser automatique |

Débogage : `window.__galerie` (scène, caméra, contrôleur, contenu) et `window.__admin`.

---

## 10. Dépendances et licences

| Dépendance | Version | Emplacement | Licence |
| --- | --- | --- | --- |
| Three.js | 0.169.0 | `vendor/three/` | MIT (`vendor/three/LICENSE`) |
| JSZip | 3.10.1 | `vendor/jszip.min.js` | MIT ou GPLv3 (`vendor/JSZIP-LICENSE.md`) |
| Cormorant Garamond, Jost | — | Google Fonts (en ligne) | SIL Open Font License |

Le code propre au projet n'a pas encore de licence déclarée : c'est au propriétaire de la
choisir (ex. MIT pour un partage libre, ou « tous droits réservés »). Les œuvres et artistes
d'exemple sont **fictifs** et générés par le code ; les images ajoutées restent la propriété
de leurs auteurs.
