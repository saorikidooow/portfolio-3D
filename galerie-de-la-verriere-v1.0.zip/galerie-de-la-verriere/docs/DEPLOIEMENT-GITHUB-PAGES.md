# Mise en ligne sur GitHub Pages

GitHub Pages héberge gratuitement des sites statiques. Ce projet n'a besoin d'aucune
compilation : les fichiers du dépôt **sont** le site.

Résultat : `https://VOTRE-COMPTE.github.io/NOM-DU-DEPOT/` (galerie) et
`…/NOM-DU-DEPOT/admin/` (Atelier).

---

## Option A — sans ligne de commande (navigateur uniquement)

1. Créez un compte sur <https://github.com> si nécessaire.
2. **New repository** (bouton « + » en haut à droite) :
   - nom : par exemple `galerie` ;
   - **Public** (requis pour GitHub Pages sur un compte gratuit) ;
   - ne cochez rien d'autre → **Create repository**.
3. Sur la page du dépôt vide : lien **uploading an existing file**.
4. Décompressez l'archive sur votre ordinateur, ouvrez le dossier, **sélectionnez tout son
   contenu** (y compris `.nojekyll` : sur Mac, `Cmd + Maj + .` affiche les fichiers cachés)
   et glissez-le dans la page. Attendez la fin de l'envoi → **Commit changes**.
   - Vérifiez que `index.html` est **à la racine** du dépôt (et non dans un sous-dossier).
5. **Settings → Pages** :
   - *Source* : **Deploy from a branch** ;
   - *Branch* : **main** et dossier **/ (root)** → **Save**.
6. Patientez 1 à 2 minutes : l'adresse du site s'affiche en haut de la page *Pages*.
7. Ouvrez `…/admin/`, onglet **Publier**, pour connecter l'Atelier (voir
   `GUIDE-PROPRIETAIRE.md`, section 3).

> Si le fichier `.nojekyll` n'a pas été envoyé : **Add file → Create new file**, nommez-le
> `.nojekyll`, laissez-le vide, **Commit**.

---

## Option B — avec Git (recommandé pour les développeurs et les IA)

### Première mise en ligne

```bash
cd chemin/vers/le-dossier-du-projet
git init -b main
git add -A
git commit -m "Première version de la galerie"
git remote add origin https://github.com/VOTRE-COMPTE/NOM-DU-DEPOT.git
git push -u origin main
```

Puis **Settings → Pages → Deploy from a branch → main / (root)**.

(L'authentification Git se fait avec votre compte GitHub : GitHub Desktop, `gh auth login`
ou un jeton à la place du mot de passe.)

### Cycle de mise à jour

```bash
git pull                        # 1. récupérer d'abord les publications faites via l'Atelier
# 2. modifier les fichiers
node tools/check.mjs            # 3. vérifier (doit finir par « ✓ Aucune erreur »)
python3 -m http.server 8765     # 4. tester sur http://localhost:8765 (Ctrl+C pour arrêter)
git add -A                      # 5. préparer
git commit -m "Ajoute la série Printemps"   # 6. enregistrer avec un message clair
git push                        # 7. envoyer : le site se met à jour en 1 à 2 minutes
```

Suivre le déploiement : onglet **Actions** du dépôt (« pages build and deployment »).

### Si `git push` est refusé (« rejected », « fetch first »)

L'Atelier a publié entre-temps. Faites :

```bash
git pull --rebase
# en cas de conflit sur content/site.json : garder la version la plus récente du contenu,
# puis :
git add content/site.json && git rebase --continue
git push
```

---

## Nom de domaine personnalisé (facultatif)

**Settings → Pages → Custom domain** : saisissez `www.exemple.fr`, puis chez votre
registraire, créez un enregistrement `CNAME` `www` → `VOTRE-COMPTE.github.io`.
Cochez **Enforce HTTPS** une fois disponible. Tous les chemins du site sont relatifs :
rien d'autre à modifier.

---

## Ce qui rend le projet compatible GitHub Pages

- site statique, aucune compilation, aucune dépendance à installer ;
- bibliothèques dans `vendor/` (pas de CDN), chemins relatifs, casse respectée ;
- fichier `.nojekyll` (fichiers servis tels quels) ;
- l'Atelier utilise l'API officielle de GitHub depuis le navigateur (pas de serveur) ;
- `node tools/check.mjs` vérifie liens, casse et contenu avant chaque envoi.

## Autres hébergeurs

Le dossier fonctionne aussi tel quel sur Netlify, Cloudflare Pages, OVH, o2switch… (tout
hébergement de fichiers statiques). La publication directe depuis l'Atelier nécessite en
revanche GitHub ; ailleurs, utilisez **Exporter (ZIP)** puis déposez les fichiers.
