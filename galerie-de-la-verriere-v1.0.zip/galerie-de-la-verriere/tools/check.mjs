#!/usr/bin/env node
/**
 * Vérification du projet avant publication (aucune dépendance à installer).
 *
 *   node tools/check.mjs
 *
 * Contrôle :
 *  1. que tous les fichiers indispensables sont présents ;
 *  2. que chaque import / lien relatif (HTML, JS, CSS) pointe vers un fichier
 *     existant AVEC LA MÊME CASSE (GitHub Pages est sensible aux majuscules) ;
 *  3. que content/site.json est valide et que les images / documents cités existent ;
 *  4. les chevauchements et débordements d'œuvres sur les murs (avertissements).
 * Code de sortie 1 en cas d'erreur bloquante.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const errors = [], warnings = [];
const rel = (p) => path.relative(ROOT, p).split(path.sep).join('/');

function existsExact(abs) {
  if (!abs.startsWith(ROOT)) return fs.existsSync(abs);
  const parts = path.relative(ROOT, abs).split(path.sep);
  let cur = ROOT;
  for (const part of parts) {
    if (part === '' || part === '.') continue;
    if (!fs.existsSync(cur) || !fs.statSync(cur).isDirectory()) return false;
    if (!fs.readdirSync(cur).includes(part)) return false;
    cur = path.join(cur, part);
  }
  return true;
}

/* 1. Fichiers indispensables */
const REQUIRED = [
  'index.html', 'style.css', 'main.js', '.nojekyll',
  'content/site.json', 'admin/index.html', 'admin/admin.js', 'admin/admin.css',
  'vendor/three/build/three.module.js', 'vendor/jszip.min.js',
  'js/content.js', 'js/layout.js', 'js/museum.js', 'js/paintings.js', 'js/painter.js',
  'js/materials.js', 'js/textures.js', 'js/controls.js', 'js/ui.js', 'js/utils.js', 'js/random.js',
  'js/store.js', 'js/github.js', 'js/config.js',
  'AI_CONTEXT.md', 'README.md', 'docs/TECHNIQUE.md', 'docs/GUIDE-PROPRIETAIRE.md', 'docs/DEPLOIEMENT-GITHUB-PAGES.md',
];
for (const f of REQUIRED) if (!existsExact(path.join(ROOT, f))) errors.push(`Fichier manquant : ${f}`);

/* 2. Références relatives */
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['.git', 'node_modules', 'livraison', '.claude'].includes(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else out.push(p);
  }
  return out;
}
const files = walk(ROOT);
const importMaps = new Map(); // fichier html → { prefixe: cible }
const isExternal = (s) => /^(https?:|data:|blob:|mailto:|tel:|#|\/\/)/i.test(s) || s.startsWith('three') || s === '';

for (const f of files.filter((p) => p.endsWith('.html'))) {
  const html = fs.readFileSync(f, 'utf8');
  const map = /<script type="importmap">([\s\S]*?)<\/script>/.exec(html);
  if (map) {
    try {
      const imports = JSON.parse(map[1]).imports || {};
      for (const target of Object.values(imports)) {
        const abs = path.resolve(path.dirname(f), target);
        if (!existsExact(abs)) errors.push(`${rel(f)} : la carte d'import pointe vers ${target} (introuvable)`);
      }
    } catch { errors.push(`${rel(f)} : carte d'import JSON invalide`); }
  }
  for (const m of html.matchAll(/\s(?:src|href)="([^"]+)"/g)) {
    const ref = m[1].split(/[?#]/)[0];
    if (isExternal(m[1]) || !ref) continue;
    const abs = path.resolve(path.dirname(f), ref);
    const target = ref.endsWith('/') ? path.join(abs, 'index.html') : abs;
    if (!existsExact(target)) errors.push(`${rel(f)} : lien vers « ${m[1]} » introuvable`);
  }
}
for (const f of files.filter((p) => p.endsWith('.js') && !rel(p).startsWith('vendor/'))) {
  const js = fs.readFileSync(f, 'utf8');
  for (const m of js.matchAll(/(?:import|export)\s[^'"]*?from\s+['"]([^'"]+)['"]|import\(\s*['"]([^'"]+)['"]\s*\)/g)) {
    const spec = m[1] || m[2];
    if (isExternal(spec)) continue;
    const abs = path.resolve(path.dirname(f), spec.split('?')[0]);
    if (!existsExact(abs)) errors.push(`${rel(f)} : import « ${spec} » introuvable (vérifiez la casse)`);
  }
}
for (const f of files.filter((p) => p.endsWith('.css'))) {
  const css = fs.readFileSync(f, 'utf8');
  for (const m of css.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)/g)) {
    if (isExternal(m[1])) continue;
    if (!existsExact(path.resolve(path.dirname(f), m[1]))) errors.push(`${rel(f)} : url(${m[1]}) introuvable`);
  }
}

/* 3. Contenu */
let content = null;
try {
  const raw = JSON.parse(fs.readFileSync(path.join(ROOT, 'content/site.json'), 'utf8'));
  const { normalizeContent } = await import(pathToFileURL(path.join(ROOT, 'js/content.js')).href);
  content = normalizeContent(raw);
  if (!Array.isArray(raw.artworks)) errors.push('content/site.json : la liste « artworks » est absente');
  const ids = new Set();
  content.artworks.forEach((a, i) => {
    const name = `Œuvre ${i + 1} « ${a.title || 'sans titre'} »`;
    if (ids.has(a.id)) errors.push(`${name} : identifiant « ${a.id} » en double`);
    ids.add(a.id);
    if (!a.title) warnings.push(`${name} : pas de titre`);
    const local = (p) => p && !/^(https?:|data:|mailto:|tel:)/i.test(p);
    if (a.visual === 'image') {
      if (!a.image) warnings.push(`${name} : visuel « image » sans image (une peinture générée sera affichée)`);
      else if (local(a.image) && !existsExact(path.join(ROOT, a.image))) errors.push(`${name} : image introuvable ${a.image}`);
    }
    if (local(a.document.url) && !existsExact(path.join(ROOT, a.document.url))) errors.push(`${name} : document introuvable ${a.document.url}`);
    if (a.clickAction === 'link' && !a.link.url) warnings.push(`${name} : ouverture directe d'un lien, mais aucun lien`);
    if (a.clickAction === 'document' && !a.document.url) warnings.push(`${name} : ouverture directe d'un document, mais aucun document`);
  });
} catch (e) {
  errors.push(`content/site.json illisible : ${e.message}`);
}

/* 4. Placement */
if (content) {
  const { WALLS, HANG_MIN_Y } = await import(pathToFileURL(path.join(ROOT, 'js/layout.js')).href);
  const box = (a) => ({ u0: a.u - a.width / 2 - 0.12, u1: a.u + a.width / 2 + 0.12, y0: a.y - a.height / 2 - 0.12, y1: a.y + a.height / 2 + 0.12 });
  const hit = (a, b) => a.u0 < b.u1 && a.u1 > b.u0 && a.y0 < b.y1 && a.y1 > b.y0;
  content.artworks.forEach((a, i) => {
    const w = WALLS[a.wall], b = box(a), name = `« ${a.title} »`;
    if (b.u0 < 0 || b.u1 > w.length) warnings.push(`${name} dépasse du ${w.label.toLowerCase()}`);
    if (b.y0 < HANG_MIN_Y - 0.05) warnings.push(`${name} descend sur le soubassement`);
    if (b.y1 > w.top + 0.12) warnings.push(`${name} monte trop haut`);
    if (w.blocks.some((k) => hit(b, k))) warnings.push(`${name} chevauche un élément d'architecture`);
    content.artworks.slice(i + 1).forEach((o) => {
      if (o.wall === a.wall && hit({ u0: b.u0 + 0.08, u1: b.u1 - 0.08, y0: b.y0 + 0.08, y1: b.y1 - 0.08 }, box(o))) warnings.push(`${name} chevauche « ${o.title} »`);
    });
  });
}

/* Rapport */
const size = files.reduce((s, f) => s + fs.statSync(f).size, 0);
console.log(`Projet : ${files.length} fichiers, ${(size / 1048576).toFixed(1)} Mo`);
if (content) console.log(`Contenu : ${content.artworks.length} œuvres, ${content.links.length} lien(s), thème « ${content.theme.preset} »`);
warnings.forEach((w) => console.log('  ⚠ ' + w));
errors.forEach((e) => console.log('  ✗ ' + e));
console.log(errors.length ? `\n✗ ${errors.length} erreur(s) à corriger.` : `\n✓ Aucune erreur${warnings.length ? ` (${warnings.length} avertissement(s))` : ''}.`);
process.exit(errors.length ? 1 : 0);
